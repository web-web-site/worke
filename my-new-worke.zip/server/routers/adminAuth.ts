import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { getAdminUserByUsername } from "../db";
import bcrypt from "bcryptjs";
import { SignJWT } from "jose";
import { ENV } from "../_core/env";
import { TRPCError } from "@trpc/server";

export const adminAuthRouter = router({
  login: publicProcedure
    .input(z.object({ username: z.string(), password: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const user = await getAdminUserByUsername(input.username);
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
      }

      const isValid = await bcrypt.compare(input.password, user.passwordHash);
      if (!isValid) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
      }

      if (!ENV.cookieSecret) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Server configuration error" });
      }

      const secret = new TextEncoder().encode(ENV.cookieSecret);
      const token = await new SignJWT({ username: user.username })
        .setProtectedHeader({ alg: "HS256" })
        .setIssuedAt()
        .setExpirationTime("24h")
        .sign(secret);

      ctx.res.cookie("admin_session", token, {
        httpOnly: true,
        secure: ENV.isProduction,
        sameSite: "lax",
        path: "/",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      });

      return { success: true };
    }),

  logout: publicProcedure.mutation(({ ctx }) => {
    ctx.res.clearCookie("admin_session", { path: "/" });
    return { success: true };
  }),

  me: publicProcedure.query(({ ctx }) => {
    return ctx.adminSession ?? null;
  }),
});
