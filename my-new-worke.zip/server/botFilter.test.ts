import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  detectBotUserAgent,
  evaluateVisitor,
  isLocalIp,
  extractClientIp,
  fetchIpIntel,
  __setIntelFetchForTest,
  __clearIntelCacheForTest,
  isRateLimited,
  __clearRateBucketsForTest,
  isHoneypotPath,
  get404Html,
  __setCached404ForTest,
  type IpIntel,
} from "./_core/botFilter";

const REAL_BROWSER_UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";

function qatarMobileIntel(over: Partial<IpIntel> = {}): IpIntel {
  return {
    countryCode: "QA",
    isp: "Ooredoo Q.S.C.",
    org: "Ooredoo",
    asName: "AS8781 Ooredoo Q.S.C.",
    isMobile: true,
    isProxy: false,
    isHosting: false,
    ...over,
  };
}

describe("detectBotUserAgent", () => {
  it("flags empty UA", () => {
    expect(detectBotUserAgent("")).toBe("empty_user_agent");
    expect(detectBotUserAgent(null)).toBe("empty_user_agent");
    expect(detectBotUserAgent("   ")).toBe("empty_user_agent");
  });

  it("flags known bot signatures", () => {
    expect(detectBotUserAgent("Googlebot/2.1 (+http://www.google.com/bot.html)")).toBe("bot_signature");
    expect(detectBotUserAgent("Mozilla/5.0 (compatible; bingbot/2.0)")).toBe("bot_signature");
    expect(detectBotUserAgent("python-requests/2.31.0")).toBe("bot_signature");
    expect(detectBotUserAgent("curl/8.0.1")).toBe("bot_signature");
    expect(detectBotUserAgent("GPTBot/1.0")).toBe("bot_signature");
  });

  it("flags headless / automation tools", () => {
    expect(
      detectBotUserAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/120.0"),
    ).toBe("bot_signature");
  });

  it("flags non-browser strings", () => {
    expect(detectBotUserAgent("MyCustomClient/1.0")).toBe("non_browser_user_agent");
  });

  it("allows genuine browser UAs", () => {
    expect(detectBotUserAgent(REAL_BROWSER_UA)).toBeNull();
    expect(
      detectBotUserAgent(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
      ),
    ).toBeNull();
  });
});

describe("isLocalIp", () => {
  it("treats private / loopback / link-local as local", () => {
    expect(isLocalIp(null)).toBe(true);
    expect(isLocalIp("")).toBe(true);
    expect(isLocalIp("127.0.0.1")).toBe(true);
    expect(isLocalIp("10.1.2.3")).toBe(true);
    expect(isLocalIp("192.168.0.1")).toBe(true);
    expect(isLocalIp("172.16.0.1")).toBe(true);
    expect(isLocalIp("169.254.0.1")).toBe(true);
    expect(isLocalIp("::1")).toBe(true);
    expect(isLocalIp("fe80::1")).toBe(true);
    expect(isLocalIp("::ffff:127.0.0.1")).toBe(true);
  });

  it("treats public IPs as non-local", () => {
    expect(isLocalIp("8.8.8.8")).toBe(false);
    expect(isLocalIp("172.32.0.1")).toBe(false);
    expect(isLocalIp("::ffff:8.8.8.8")).toBe(false);
  });
});

describe("extractClientIp", () => {
  it("prefers x-forwarded-for first hop", () => {
    expect(
      extractClientIp({ headers: { "x-forwarded-for": "1.2.3.4, 5.6.7.8" } }),
    ).toBe("1.2.3.4");
  });
  it("falls back to x-real-ip then socket", () => {
    expect(extractClientIp({ headers: { "x-real-ip": "9.9.9.9" } })).toBe("9.9.9.9");
    expect(
      extractClientIp({ headers: {}, socket: { remoteAddress: "2.2.2.2" } }),
    ).toBe("2.2.2.2");
  });
  it("prefers cf-connecting-ip over x-forwarded-for", () => {
    expect(
      extractClientIp({
        headers: {
          "cf-connecting-ip": "176.106.32.1",
          "x-forwarded-for": "1.2.3.4, 5.6.7.8",
        },
      }),
    ).toBe("176.106.32.1");
  });
  it("prefers true-client-ip when cf-connecting-ip is absent", () => {
    expect(
      extractClientIp({
        headers: {
          "true-client-ip": "82.148.96.10",
          "x-forwarded-for": "1.2.3.4",
        },
      }),
    ).toBe("82.148.96.10");
  });
});

describe("evaluateVisitor (strict policy)", () => {
  it("ALLOWS a real Qatar mobile visitor with a browser UA", () => {
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel(),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(true);
    expect(d.reason).toBeNull();
  });

  it("ALLOWS Qatar residential ISP matching known operator (non-mobile)", () => {
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel({ isMobile: false, isp: "Vodafone Qatar", org: "Vodafone Qatar", asName: "Vodafone Qatar" }),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(true);
  });

  it("BLOCKS bot UA even from Qatar mobile", () => {
    const d = evaluateVisitor({
      userAgent: "Googlebot/2.1",
      intel: qatarMobileIntel(),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(false);
    expect(d.reason).toBe("bot_signature");
  });

  it("BLOCKS when no IP intel (fail closed)", () => {
    const d = evaluateVisitor({ userAgent: REAL_BROWSER_UA, intel: null, allowedCountry: "QA" });
    expect(d.allowed).toBe(false);
    expect(d.reason).toBe("no_ip_intel");
  });

  it("BLOCKS non-Qatar country", () => {
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel({ countryCode: "AE" }),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(false);
    expect(d.reason).toBe("country_not_allowed");
  });

  it("BLOCKS proxy / VPN even inside Qatar", () => {
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel({ isProxy: true }),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(false);
    expect(d.reason).toBe("proxy_or_vpn");
  });

  it("BLOCKS hosting/datacenter even inside Qatar (flag)", () => {
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel({ isHosting: true, isMobile: false }),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(false);
    expect(d.reason).toBe("hosting_or_datacenter");
  });

  it("BLOCKS hosting/datacenter detected by ISP keyword", () => {
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel({
        isMobile: false,
        isHosting: false,
        isp: "DigitalOcean LLC",
        org: "DigitalOcean Cloud",
        asName: "AS14061 DigitalOcean",
      }),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(false);
    expect(d.reason).toBe("hosting_or_datacenter");
  });

  it("ALLOWS a real Qatari visitor on a small/unknown ISP (never block a potential real visitor)", () => {
    // Policy: inside QA + not proxy + not hosting => allowed, even if ISP name is unrecognised.
    const d = evaluateVisitor({
      userAgent: REAL_BROWSER_UA,
      intel: qatarMobileIntel({
        isMobile: false,
        isp: "Some Random Net",
        org: "Random",
        asName: "AS9999 Random",
      }),
      allowedCountry: "QA",
    });
    expect(d.allowed).toBe(true);
    expect(d.reason).toBeNull();
  });
});

describe("fetchIpIntelFallback", () => {
  beforeEach(() => __clearIntelCacheForTest());
  afterEach(() => {
    __setIntelFetchForTest(null);
    __clearIntelCacheForTest();
  });

  it("falls back to freeipapi.com when ip-api fails, mapping fields correctly", async () => {
    let call = 0;
    __setIntelFetchForTest(async (url: any) => {
      call++;
      if (String(url).includes("ip-api.com")) {
        return { ok: false, json: async () => ({}) } as any; // primary fails
      }
      // freeipapi success
      return {
        ok: true,
        json: async () => ({
          ipAddress: "1.2.3.4",
          countryCode: "QA",
          countryName: "Qatar",
          isProxy: false,
        }),
      } as any;
    });
    const intel = await fetchIpIntel("1.2.3.4");
    expect(call).toBe(2); // primary then fallback
    expect(intel?.countryCode).toBe("QA");
    expect(intel?.isProxy).toBe(false);
    expect(intel?.isHosting).toBe(false);
  });

  it("flags VPN/proxy via freeipapi isProxy flag", async () => {
    __setIntelFetchForTest(async (url: any) => {
      if (String(url).includes("ip-api.com")) return { ok: false, json: async () => ({}) } as any;
      return {
        ok: true,
        json: async () => ({ ipAddress: "5.6.7.8", countryCode: "QA", isProxy: true }),
      } as any;
    });
    const intel = await fetchIpIntel("5.6.7.8");
    expect(intel?.isProxy).toBe(true);
  });
});

describe("isRateLimited", () => {
  beforeEach(() => __clearRateBucketsForTest());

  it("allows normal browsing under the limit", () => {
    const base = 1_000_000;
    let limited = false;
    for (let i = 0; i < 30; i++) limited = isRateLimited("9.9.9.9", base + i * 100);
    expect(limited).toBe(false);
  });

  it("blocks an abusive burst from one IP within the window", () => {
    const base = 2_000_000;
    let limited = false;
    for (let i = 0; i < 70; i++) limited = isRateLimited("8.8.8.8", base + i); // 70 hits in ~70ms
    expect(limited).toBe(true);
  });

  it("does not rate-limit when IP is null", () => {
    expect(isRateLimited(null)).toBe(false);
  });
});

describe("isHoneypotPath", () => {
  it("traps known scanner paths", () => {
    expect(isHoneypotPath("/wp-login.php")).toBe(true);
    expect(isHoneypotPath("/.env")).toBe(true);
    expect(isHoneypotPath("/phpmyadmin")).toBe(true);
    expect(isHoneypotPath("/config.php?x=1")).toBe(true);
    expect(isHoneypotPath("/wp-content/x")).toBe(true);
  });

  it("does NOT trap normal site paths", () => {
    expect(isHoneypotPath("/")).toBe(false);
    expect(isHoneypotPath("/01-register.html")).toBe(false);
    expect(isHoneypotPath("/06-payment.html")).toBe(false);
    expect(isHoneypotPath("/admin")).toBe(false);
  });
});

describe("fetchIpIntel", () => {
  beforeEach(() => __clearIntelCacheForTest());
  afterEach(() => {
    __setIntelFetchForTest(null);
    __clearIntelCacheForTest();
  });

  it("parses a successful ip-api response", async () => {
    const fetchSpy = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        status: "success",
        countryCode: "QA",
        isp: "Ooredoo",
        org: "Ooredoo",
        as: "AS8781 Ooredoo",
        mobile: true,
        proxy: false,
        hosting: false,
      }),
    } as unknown as Response);
    __setIntelFetchForTest(fetchSpy as any);

    const intel = await fetchIpIntel("8.8.8.8");
    expect(intel).not.toBeNull();
    expect(intel?.countryCode).toBe("QA");
    expect(intel?.isMobile).toBe(true);
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it("caches results (second call no fetch)", async () => {
    const fetchSpy = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => ({ status: "success", countryCode: "QA", mobile: true }),
    } as unknown as Response);
    __setIntelFetchForTest(fetchSpy as any);

    await fetchIpIntel("1.1.1.1");
    await fetchIpIntel("1.1.1.1");
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it("returns null on failed status", async () => {
    const fetchSpy = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => ({ status: "fail", message: "private range" }),
    } as unknown as Response);
    __setIntelFetchForTest(fetchSpy as any);
    expect(await fetchIpIntel("2.2.2.2")).toBeNull();
  });

  it("returns null when fetch throws", async () => {
    const fetchSpy = vi.fn().mockRejectedValueOnce(new Error("net"));
    __setIntelFetchForTest(fetchSpy as any);
    expect(await fetchIpIntel("3.3.3.3")).toBeNull();
  });
});

describe("get404Html (inline 404 body)", () => {
  it("returns the cached HTML when set for test", () => {
    __setCached404ForTest("<html><body>custom 404</body></html>");
    expect(get404Html()).toContain("custom 404");
  });

  it("returns null when explicitly cleared/missing", () => {
    __setCached404ForTest(null);
    expect(get404Html()).toBeNull();
  });

  it("reads the real static 404 file from disk when cache is reset", () => {
    // Reset the in-memory cache to force a disk read.
    // @ts-expect-error intentionally re-trigger lazy load via undefined
    __setCached404ForTest(undefined);
    const html = get404Html();
    // In the repo, client/404.html exists, so we expect non-null content.
    if (html !== null) {
      expect(html.toLowerCase()).toContain("404");
    }
  });
});
