import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { jwtVerify } from "jose";
import { ENV } from "./env";
import * as cookie from "cookie";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  adminSession: { username: string } | null;
  regId: number | null;
  fingerprint: string | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;
  let adminSession: { username: string } | null = null;

  // 1. Try Manus OAuth
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }

  // 2. Try Admin Password Session (JWT in cookie)
  try {
    const cookies = cookie.parse(opts.req.headers.cookie || "");
    const token = cookies["admin_session"];
    if (token && ENV.cookieSecret) {
      const secret = new TextEncoder().encode(ENV.cookieSecret);
      const { payload } = await jwtVerify(token, secret);
      if (payload && typeof payload.username === "string") {
        adminSession = { username: payload.username };
      }
    }
  } catch (error) {
    adminSession = null;
  }

  // Read regId from cookies (set by visitorCookieMiddleware)
  const cookies = cookie.parse(opts.req.headers.cookie || "");
  const regIdRaw = opts.req.cookies?.regId || cookies["regId"];
  const regId = regIdRaw && /^\d+$/.test(regIdRaw) ? parseInt(regIdRaw, 10) : null;

  // Read fingerprint from headers
  const fingerprint = (opts.req.headers['x-visitor-fingerprint'] as string) || null;

  return {
    req: opts.req,
    res: opts.res,
    user,
    adminSession,
    regId,
    fingerprint,
  };
}
