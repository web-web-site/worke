import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { initSocketIO, setSnapshotFetcher, getVisitorPresence } from "./socketChannel";
import { getAllVisitorsAggregated, getStats } from "../db";
import { lookupGeoBatch } from "./geoip";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import cookieParser from "cookie-parser";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  server.keepAliveTimeout = 65000;
  server.headersTimeout = 66000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.use(cookieParser());
  
  app.set("trust proxy", true);

  // Security headers
  app.disable("x-powered-by");
  app.use((_req, res, next) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-Content-Type-Options", "nosniff");
    next();
  });

  registerStorageProxy(app);
  registerOAuthRoutes(app);
  initSocketIO(server);
  // Inject full data fetcher — Socket sends complete snapshots (no HTTP round-trip needed)
  setSnapshotFetcher(async () => {
    const [rawVisitors, stats] = await Promise.all([
      getAllVisitorsAggregated(200, "active", 0),
      getStats(),
    ]);
    const ips = rawVisitors.map((v: any) => v.registration.ipAddress as string | null);
    const geoMap = await lookupGeoBatch(ips);
    const visitors = rawVisitors.map((v: any) => {
      const ip = v.registration.ipAddress as string | null;
      const geo = ip ? (geoMap.get(ip) ?? null) : null;
      return {
        ...v,
        presence: v.registration.fingerprint
          ? getVisitorPresence(v.registration.fingerprint)
          : { online: false, currentPage: null, lastSeenAt: null },
        geo,
      };
    });
    return { visitors, stats };
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
