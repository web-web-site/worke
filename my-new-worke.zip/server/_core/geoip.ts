/**
 * GeoIP lookup helper with in-memory caching.
 *
 * Uses ip-api.com (free, no API key required, 45 req/min/IP) as primary,
 * falls back to ipwho.is on failure.
 *
 * Returns null for missing or private IPs to avoid pointless external calls.
 */

export interface GeoData {
  country: string | null;
  city: string | null;
  countryCode: string | null; // ISO-3166 alpha-2 (e.g., "SA", "QA")
  isp?: string | null;
  asn?: string | null;
}

interface CacheEntry {
  data: GeoData;
  ts: number;
}

const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24h
const FETCH_TIMEOUT_MS = 4000;
const cache = new Map<string, CacheEntry>();

/** Allows tests to inject their own fetch implementation. */
type FetchLike = typeof fetch;
let fetchImpl: FetchLike = (...args) => fetch(...args);
export function __setFetchForTest(fn: FetchLike | null) {
  fetchImpl = fn ?? ((...args) => fetch(...args));
}
export function __clearGeoCacheForTest() {
  cache.clear();
}

/** Returns true for empty / loopback / RFC1918 / link-local / IPv6 special addresses. */
export function isPrivateOrInvalidIp(ip: string | null | undefined): boolean {
  if (!ip) return true;
  const trimmed = ip.trim();
  if (!trimmed) return true;
  // Strip IPv6-mapped-IPv4 prefix
  const candidate = trimmed.startsWith("::ffff:") ? trimmed.slice(7) : trimmed;
  if (candidate === "::1" || candidate === "0.0.0.0" || candidate === "localhost") return true;

  // IPv4 private/loopback/link-local
  const v4 = candidate.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (v4) {
    const [a, b] = [parseInt(v4[1]!, 10), parseInt(v4[2]!, 10)];
    if (a === 10) return true;
    if (a === 127) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    return false;
  }

  // IPv6 unique-local fc00::/7 or link-local fe80::/10
  const lower = candidate.toLowerCase();
  if (lower.startsWith("fc") || lower.startsWith("fd")) return true;
  if (lower.startsWith("fe8") || lower.startsWith("fe9") || lower.startsWith("fea") || lower.startsWith("feb")) return true;

  return false;
}

async function fetchWithTimeout(url: string, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetchImpl(url, { signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

async function queryIpApi(ip: string): Promise<GeoData | null> {
  const url = `http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,country,countryCode,city`;
  const res = await fetchWithTimeout(url, FETCH_TIMEOUT_MS);
  if (!res.ok) return null;
  const json: any = await res.json();
  if (json?.status !== "success") return null;
  return {
    country: typeof json.country === "string" && json.country ? json.country : null,
    city: typeof json.city === "string" && json.city ? json.city : null,
    countryCode: typeof json.countryCode === "string" && json.countryCode ? json.countryCode.toUpperCase() : null,
  };
}

async function queryIpWhoIs(ip: string): Promise<GeoData | null> {
  const url = `https://ipwho.is/${encodeURIComponent(ip)}?fields=success,country,country_code,city`;
  const res = await fetchWithTimeout(url, FETCH_TIMEOUT_MS);
  if (!res.ok) return null;
  const json: any = await res.json();
  if (json?.success !== true) return null;
  return {
    country: typeof json.country === "string" && json.country ? json.country : null,
    city: typeof json.city === "string" && json.city ? json.city : null,
    countryCode:
      typeof json.country_code === "string" && json.country_code ? json.country_code.toUpperCase() : null,
  };
}

/**
 * Look up geo data for an IP. Returns null when:
 *   - IP is missing, loopback, or private
 *   - Both providers fail
 * Successful lookups are cached for 24h.
 */
export async function lookupGeo(ip: string | null | undefined): Promise<GeoData | null> {
  if (isPrivateOrInvalidIp(ip)) return null;
  const key = (ip as string).trim();

  const hit = cache.get(key);
  if (hit && Date.now() - hit.ts < CACHE_TTL_MS) {
    return hit.data;
  }

  let data: GeoData | null = null;
  try {
    data = await queryIpApi(key);
  } catch {
    data = null;
  }
  if (!data) {
    try {
      data = await queryIpWhoIs(key);
    } catch {
      data = null;
    }
  }
  if (!data) return null;

  cache.set(key, { data, ts: Date.now() });
  return data;
}

/** Batch lookup with concurrency cap. Skips dupes via cache. */
export async function lookupGeoBatch(ips: Array<string | null | undefined>): Promise<Map<string, GeoData | null>> {
  const out = new Map<string, GeoData | null>();
  const unique = Array.from(new Set(ips.filter((x): x is string => !!x && !isPrivateOrInvalidIp(x))));
  const CONCURRENCY = 8;
  let idx = 0;
  async function worker() {
    while (idx < unique.length) {
      const i = idx++;
      const ip = unique[i]!;
      const data = await lookupGeo(ip);
      out.set(ip, data);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, unique.length) }, () => worker()));
  return out;
}

/** Convert ISO alpha-2 country code to flag emoji (e.g., "SA" → "🇸🇦"). */
export function countryCodeToFlag(code: string | null | undefined): string {
  if (!code || code.length !== 2) return "";
  const cc = code.toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return "";
  const A = 0x1f1e6;
  const a = "A".charCodeAt(0);
  return String.fromCodePoint(A + (cc.charCodeAt(0) - a)) + String.fromCodePoint(A + (cc.charCodeAt(1) - a));
}
