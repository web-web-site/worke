import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import { nanoid } from "nanoid";
import path from "path";
import { createServer as createViteServer } from "vite";
import viteConfig from "../../vite.config";

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    server: serverOptions,
    appType: "custom",
  });

  const clientRootForStatic = path.resolve(import.meta.dirname, "../..", "client");
  // Serve the static 404 page directly from disk (it is plain HTML, not a React route).
  app.get("/404.html", (_req, res, next) => {
    const f = path.resolve(clientRootForStatic, "404.html");
    if (fs.existsSync(f)) return res.status(404).type("html").sendFile(f);
    next();
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientRoot = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
      );

      // Routes that should be served by the React SPA (admin.html with #root)
      const reactSpaPaths = ["/admin", "/404"];
      const isReactRoute =
        reactSpaPaths.some((p) => url === p || url.startsWith(p + "/")) ||
        url === "/admin/";

      let templateName = isReactRoute ? "admin.html" : "index.html";
      
      // If it's a direct request to an HTML file, try to serve that specific file
      if (!isReactRoute && url.endsWith('.html')) {
        const requestedFile = url.split('?')[0].replace(/^\//, '');
        const requestedPath = path.resolve(clientRoot, requestedFile);
        if (fs.existsSync(requestedPath)) {
          templateName = requestedFile;
        }
      }
      
      const clientTemplate = path.resolve(clientRoot, templateName);

      // always reload the template from disk in case it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`,
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath =
    process.env.NODE_ENV === "development"
      ? path.resolve(import.meta.dirname, "../..", "dist", "public")
      : path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`,
    );
  }

  // Serve the static 404 page with a real 404 status (before the SPA fallbacks).
  app.get("/404.html", (_req, res, next) => {
    const f = path.resolve(distPath, "404.html");
    if (fs.existsSync(f)) return res.status(404).type("html").sendFile(f);
    next();
  });

  app.use(express.static(distPath));

  // Serve admin.html for the React admin SPA routes
  app.get(["/admin", "/admin/*", "/404"], (_req, res) => {
    res.sendFile(path.resolve(distPath, "admin.html"));
  });

  // fall through to index.html (legacy site) for any other unmatched route
  app.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
