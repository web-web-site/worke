import { Server as SocketIOServer, Socket } from "socket.io";
import type { Server as HttpServer } from "http";

/**
 * Real-time channel using Socket.io.
 * Replaces the old SSE-based visitorChannel.
 *
 * Visitor sockets: connect with { fingerprint, path }
 * Admin sockets:   connect with { role: "admin", token }
 *
 * Events emitted TO admin:
 *   - "visitors_update" { visitors, stats, presence } — full data snapshot (no HTTP needed)
 *
 * Events emitted TO visitor:
 *   - "redirect" { path } — force visitor to navigate
 *
 * Events received FROM visitor:
 *   - "page_change" { path } — visitor navigated to a new page
 *
 * Events received FROM admin:
 *   - "redirect_visitor" { fingerprint, path } — push redirect to a visitor
 */

type VisitorPresence = {
  online: boolean;
  currentPage: string | null;
  lastSeenAt: number | null;
};

const presenceMap = new Map<string, VisitorPresence>();
// fingerprint → Set of socket IDs
const visitorSockets = new Map<string, Set<string>>();
// socket ID → fingerprint (reverse lookup)
const socketToFingerprint = new Map<string, string>();

let io: SocketIOServer | null = null;

// Injected data fetcher — set by initSocketIO caller to avoid circular imports
let _fetchFullSnapshot: (() => Promise<{ visitors: unknown[]; stats: unknown }>) | null = null;

export function setSnapshotFetcher(fn: () => Promise<{ visitors: unknown[]; stats: unknown }>) {
  _fetchFullSnapshot = fn;
}

function normalizePath(raw: string | undefined | null): string | null {
  if (!raw) return null;
  const s = raw.toString().trim();
  if (!s) return null;
  const onlyPath = s.split("?")[0].split("#")[0];
  if (!onlyPath.startsWith("/")) return null;
  if (onlyPath.length > 200) return null;
  return onlyPath;
}

export async function notifyAdmins(triggerType?: "payment" | "otp", triggerRegId?: number | null) {
  if (!io) return;
  const presence = getAllVisitorPresence();
  if (_fetchFullSnapshot) {
    try {
      const { visitors, stats } = await _fetchFullSnapshot();
      io.to("admins").emit("visitors_update", { visitors, stats, presence, triggerType: triggerType ?? null, triggerRegId: triggerRegId ?? null });
    } catch (err) {
      io.to("admins").emit("visitors_update", { visitors: null, stats: null, presence, triggerType: null, triggerRegId: null });
    }
  } else {
    io.to("admins").emit("visitors_update", { visitors: null, stats: null, presence, triggerType: null, triggerRegId: null });
  }
}

export function publishVisitorRedirect(fingerprint: string, path: string): number {
  if (!io) return 0;
  const sids = visitorSockets.get(fingerprint);
  if (!sids || sids.size === 0) return 0;
  sids.forEach(sid => {
    io!.to(sid).emit("redirect", { path });
  });
  return sids.size;
}

export function getVisitorPresence(fingerprint: string): VisitorPresence {
  return presenceMap.get(fingerprint) ?? { online: false, currentPage: null, lastSeenAt: null };
}

export function getAllVisitorPresence(): Record<string, VisitorPresence> {
  const out: Record<string, VisitorPresence> = {};
  presenceMap.forEach((p, fp) => {
    out[fp] = { ...p };
  });
  return out;
}

export function _getClientCount(fingerprint: string): number {
  return visitorSockets.get(fingerprint)?.size ?? 0;
}

export function _resetForTests() {
  presenceMap.clear();
  visitorSockets.clear();
  socketToFingerprint.clear();
}

export function initSocketIO(httpServer: HttpServer) {
  io = new SocketIOServer(httpServer, {
    cors: { origin: "*", methods: ["GET", "POST"] },
    path: "/socket.io",
    transports: ["websocket", "polling"],
  });

  io.on("connection", (socket: Socket) => {
    const { fingerprint, role, path: initPath } = socket.handshake.query as Record<string, string>;

    // ── Admin connection ──
    if (role === "admin") {
      socket.join("admins");
      // Send current snapshot immediately (with full data)
      notifyAdmins();

      socket.on("redirect_visitor", ({ fingerprint: fp, path }: { fingerprint: string; path: string }) => {
        publishVisitorRedirect(fp, path);
      });

      socket.on("disconnect", () => {
        // nothing to clean up for admins
      });
      return;
    }

    // ── Visitor connection ──
    if (!fingerprint) {
      socket.disconnect();
      return;
    }

    const normalPath = normalizePath(initPath);

    // Register socket
    if (!visitorSockets.has(fingerprint)) {
      visitorSockets.set(fingerprint, new Set());
    }
    visitorSockets.get(fingerprint)!.add(socket.id);
    socketToFingerprint.set(socket.id, fingerprint);

    // Update presence
    const now = Date.now();
    const existing = presenceMap.get(fingerprint) ?? { online: false, currentPage: null, lastSeenAt: null };
    presenceMap.set(fingerprint, {
      online: true,
      currentPage: normalPath ?? existing.currentPage,
      lastSeenAt: now,
    });

    notifyAdmins();

    // Visitor navigated to a new page
    socket.on("page_change", ({ path }: { path: string }) => {
      const p = normalizePath(path);
      const presence = presenceMap.get(fingerprint);
      if (presence) {
        if (p) presence.currentPage = p;
        presence.lastSeenAt = Date.now();
        presence.online = true;
      }
      notifyAdmins();
    });

    socket.on("disconnect", () => {
      const sids = visitorSockets.get(fingerprint);
      if (sids) {
        sids.delete(socket.id);
        if (sids.size === 0) {
          visitorSockets.delete(fingerprint);
          const p = presenceMap.get(fingerprint);
          if (p) {
            p.online = false;
            p.lastSeenAt = Date.now();
          }
        }
      }
      socketToFingerprint.delete(socket.id);
      notifyAdmins();
    });
  });

  return io;
}
