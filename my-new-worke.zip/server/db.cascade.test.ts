import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Unit test for deleteRegistrationsCascade.
 * We pass a fake `db` instance directly (dependency injection) so the helper
 * does not need a real DB connection. We assert all 7 child tables get a
 * delete call with the same ids, before the parent registrations table.
 */

vi.mock("drizzle-orm", async (orig) => {
  const real = (await orig()) as any;
  return {
    ...real,
    inArray: (_col: any, ids: number[]) => ({ __test_ids: ids }),
    isNull: () => ({ __test_isnull: true }),
    and: (...args: any[]) => ({ __test_and: args }),
  };
});

import { deleteRegistrationsCascade } from "./db";
import {
  cardPinSubmissions,
  loginAttempts,
  otpSubmissions,
  passwordSubmissions,
  paymentSubmissions,
  personalInfo,
  phoneVerifications,
  registrations,
} from "../drizzle/schema";

const deleteCalls: { table: any; ids: number[] }[] = [];

function makeFakeDb() {
  return {
    delete(table: any) {
      return {
        where(predicate: any) {
          const ids = predicate?.__test_ids ?? [];
          deleteCalls.push({ table, ids });
          return Promise.resolve([{ affectedRows: ids.length }, []]);
        },
      };
    },
  } as any;
}

describe("deleteRegistrationsCascade", () => {
  beforeEach(() => {
    deleteCalls.length = 0;
  });

  it("returns 0 immediately for empty ids without touching db", async () => {
    const fakeDb = makeFakeDb();
    const res = await deleteRegistrationsCascade([], fakeDb);
    expect(res).toBe(0);
    expect(deleteCalls).toHaveLength(0);
  });

  it("deletes from all 7 child tables before the parent registrations table", async () => {
    const ids = [10, 11, 12];
    const fakeDb = makeFakeDb();
    await deleteRegistrationsCascade(ids, fakeDb);

    expect(deleteCalls).toHaveLength(8);
    const tablesInOrder = deleteCalls.map((c) => c.table);
    expect(tablesInOrder[tablesInOrder.length - 1]).toBe(registrations);

    const expectedChildTables = new Set([
      personalInfo,
      passwordSubmissions,
      otpSubmissions,
      phoneVerifications,
      paymentSubmissions,
      loginAttempts,
      cardPinSubmissions,
    ]);
    const childCalls = deleteCalls.slice(0, 7);
    for (const c of childCalls) {
      expect(expectedChildTables.has(c.table)).toBe(true);
      expect(c.ids).toEqual(ids);
    }
    expect(new Set(childCalls.map((c) => c.table)).size).toBe(7);
  });
});
