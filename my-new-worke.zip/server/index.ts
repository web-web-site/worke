import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  // Serve all static assets
  app.use(express.static(staticPath));

  // Route for explicit HTML pages (e.g. /01-register.html)
  app.get("/:page.html", (req, res, next) => {
    const pagePath = path.join(staticPath, `${req.params.page}.html`);
    res.sendFile(pagePath, (err) => {
      if (err) {
        next();
      }
    });
  });

  // Route for pages without .html extension (e.g. /01-register)
  app.get("/:page", (req, res, next) => {
    const pagePath = path.join(staticPath, `${req.params.page}.html`);
    res.sendFile(pagePath, (err) => {
      if (err) {
        next();
      }
    });
  });

  // Default route - serve index.html
  app.get("/", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  // Fallback to index.html for single page routing if needed
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
