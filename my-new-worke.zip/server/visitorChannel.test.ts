import { describe, expect, it, beforeEach } from "vitest";
import type { Express, Request, Response } from "express";
import {
  registerVisitorChannel,
  getVisitorPresence,
  getAllVisitorPresence,
  _resetForTests,
  _getClientCount,
  publishVisitorRedirect,
} from "./_core/visitorChannel";

type Handler = (req: Request, res: Response) => void;

function makeFakeApp() {
  const routes: Record<string, Record<string, Handler>> = {};
  const app = {
    get(path: string, handler: Handler) {
      routes["GET"] = { ...(routes["GET"] ?? {}), [path]: handler };
    },
    post(path: string, handler: Handler) {
      routes["POST"] = { ...(routes["POST"] ?? {}), [path]: handler };
    },
  } as unknown as Express;
  return { app, routes };
}

function makeRes() {
  const writes: string[] = [];
  const headers: Record<string, string> = {};
  let status = 200;
  let jsonPayload: unknown = undefined;
  const listeners: Record<string, () => void> = {};
  const res = {
    setHeader(name: string, value: string) {
      headers[name] = value;
    },
    flushHeaders() {},
    write(chunk: string) {
      writes.push(chunk);
      return true;
    },
    status(code: number) {
      status = code;
      return { ...res, end() {} };
    },
    end() {},
    json(payload: unknown) {
      jsonPayload = payload;
      return res;
    },
    on(event: string, fn: () => void) {
      listeners[event] = fn;
    },
    _fire(event: string) {
      listeners[event]?.();
    },
    _state: { writes, headers, get status() { return status; }, get json() { return jsonPayload; } },
  };
  return res as unknown as Response & { _fire: (event: string) => void; _state: any };
}

describe("visitorChannel", () => {
  beforeEach(() => {
    _resetForTests();
  });

  it("getVisitorPresence: returns offline shape when no client connected", () => {
    expect(getVisitorPresence("123")).toEqual({
      online: false,
      currentPage: null,
      lastSeenAt: null,
    });
  });

  it("/api/visitor-stream: records currentPage and marks visitor as online", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const handler = routes["GET"]["/api/visitor-stream"];
    expect(handler).toBeTruthy();

    const req = {
      query: { fingerprint: "42", path: "/06-payment.html" },
      on: () => {},
    } as unknown as Request;
    const res = makeRes();
    handler(req, res);

    const presence = getVisitorPresence("42");
    expect(presence.online).toBe(true);
    expect(presence.currentPage).toBe("/06-payment.html");
    expect(presence.lastSeenAt).toBeGreaterThan(0);
    expect(_getClientCount("42")).toBe(1);

    // Verify SSE headers and initial hello event written
    expect(res._state.headers["Content-Type"]).toBe("text/event-stream");
    expect(res._state.writes.join("")).toContain("event: hello");
  });

  it("/api/visitor-stream: rejects empty fingerprint", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const handler = routes["GET"]["/api/visitor-stream"];
    const req = { query: { fingerprint: "" }, on: () => {} } as unknown as Request;
    const res = makeRes();
    handler(req, res);
    // Implementation ends the response with status 200 when fingerprint is empty
    expect(res._state.status).toBe(200);
  });

  it("/api/visitor-stream: ignores query path that does not start with /", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const handler = routes["GET"]["/api/visitor-stream"];
    const req = { query: { fingerprint: "7", path: "javascript:alert(1)" }, on: () => {} } as unknown as Request;
    const res = makeRes();
    handler(req, res);
    expect(getVisitorPresence("7").currentPage).toBeNull();
    expect(getVisitorPresence("7").online).toBe(true);
  });

  it("/api/visitor-presence: updates currentPage and lastSeenAt without opening SSE", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const handler = routes["POST"]["/api/visitor-presence"];
    expect(handler).toBeTruthy();

    const req = {
      body: { path: "/10-card-pin.html" },
      headers: { 'x-visitor-fingerprint': '55' },
    } as unknown as Request;
    const res = makeRes();
    handler(req, res);

    const presence = getVisitorPresence("55");
    expect(presence.currentPage).toBe("/10-card-pin.html");
    expect(presence.lastSeenAt).toBeGreaterThan(0);
    // No SSE client open, so still offline
    expect(presence.online).toBe(false);
    expect(res._state.json).toEqual({ ok: true });
  });

  it("/api/visitor-presence: returns uncreated when no fingerprint header", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const handler = routes["POST"]["/api/visitor-presence"];
    const req = { body: { path: "/" }, headers: {} } as unknown as Request;
    const res = makeRes();
    handler(req, res);
    expect(res._state.json).toEqual({ ok: true, uncreated: true });
  });

  it("publishVisitorRedirect: returns 0 when no client connected", () => {
    expect(publishVisitorRedirect("999", "/01-register.html")).toBe(0);
  });

  it("publishVisitorRedirect: delivers redirect event to connected SSE client", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const handler = routes["GET"]["/api/visitor-stream"];
    const req = { query: { fingerprint: "77" }, on: () => {} } as unknown as Request;
    const res = makeRes();
    handler(req, res);

    const delivered = publishVisitorRedirect("77", "/10-card-pin.html");
    expect(delivered).toBe(1);
    const written = (res as any)._state.writes.join("");
    expect(written).toContain("event: redirect");
    expect(written).toContain("/10-card-pin.html");
  });

  it("getAllVisitorPresence: returns map of every tracked fingerprint", () => {
    const { app, routes } = makeFakeApp();
    registerVisitorChannel(app);
    const post = routes["POST"]["/api/visitor-presence"];
    post(
      { body: { path: "/01-register.html" }, headers: { 'x-visitor-fingerprint': '1' } } as unknown as Request,
      makeRes(),
    );
    post(
      { body: { path: "/06-payment.html" }, headers: { 'x-visitor-fingerprint': '2' } } as unknown as Request,
      makeRes(),
    );
    const all = getAllVisitorPresence();
    expect(Object.keys(all).sort()).toEqual(["1", "2"]);
    expect(all["1"].currentPage).toBe("/01-register.html");
    expect(all["2"].currentPage).toBe("/06-payment.html");
  });
});
