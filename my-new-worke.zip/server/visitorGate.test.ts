import { describe, it, expect, beforeEach } from "vitest";
import { decideGate } from "./_core/visitorGate";
import {
  __setIntelFetchForTest,
  __clearIntelCacheForTest,
  __clearRateBucketsForTest,
} from "./_core/botFilter";

const REAL_BROWSER_UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
const BOT_UA = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";

function mockIntel(json: any) {
  __setIntelFetchForTest(async () => {
    return new Response(JSON.stringify(json), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  });
}

describe("decideGate (production client-side gate)", () => {
  beforeEach(() => {
    __clearIntelCacheForTest();
    __clearRateBucketsForTest();
    __setIntelFetchForTest(null);
  });

  it("ALLOWS a real Qatar residential visitor with a browser UA", async () => {
    mockIntel({
      status: "success",
      countryCode: "QA",
      isp: "Ooredoo Q.S.C.",
      org: "Ooredoo",
      as: "AS8781 Ooredoo",
      mobile: true,
      proxy: false,
      hosting: false,
    });
    const r = await decideGate({
      userAgent: REAL_BROWSER_UA,
      ip: "82.148.96.10",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(true);
    expect(r.reason).toBeNull();
  });

  it("BLOCKS a bot user-agent regardless of country", async () => {
    mockIntel({
      status: "success",
      countryCode: "QA",
      isp: "Ooredoo",
      org: "Ooredoo",
      as: "AS8781",
      mobile: true,
      proxy: false,
      hosting: false,
    });
    const r = await decideGate({
      userAgent: BOT_UA,
      ip: "82.148.96.10",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(false);
    expect(r.reason).toBe("bot_signature");
  });

  it("BLOCKS a visitor from Jordan (non-Qatar)", async () => {
    mockIntel({
      status: "success",
      countryCode: "JO",
      isp: "Zain Jordan",
      org: "Zain",
      as: "AS12345 Zain",
      mobile: true,
      proxy: false,
      hosting: false,
    });
    const r = await decideGate({
      userAgent: REAL_BROWSER_UA,
      ip: "176.106.32.1",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(false);
    expect(r.reason).toBe("country_not_allowed");
    expect(r.countryCode).toBe("JO");
  });

  it("BLOCKS a proxy/VPN connection inside Qatar", async () => {
    mockIntel({
      status: "success",
      countryCode: "QA",
      isp: "SomeVPN",
      org: "VPN provider",
      as: "AS999",
      mobile: false,
      proxy: true,
      hosting: false,
    });
    const r = await decideGate({
      userAgent: REAL_BROWSER_UA,
      ip: "1.2.3.4",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(false);
    expect(r.reason).toBe("proxy_or_vpn");
  });

  it("BLOCKS a datacenter/hosting IP inside Qatar", async () => {
    mockIntel({
      status: "success",
      countryCode: "QA",
      isp: "Amazon AWS",
      org: "Amazon",
      as: "AS16509 Amazon",
      mobile: false,
      proxy: false,
      hosting: true,
    });
    const r = await decideGate({
      userAgent: REAL_BROWSER_UA,
      ip: "3.3.3.3",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(false);
    expect(r.reason).toBe("hosting_or_datacenter");
  });

  it("ALLOWS local/dev IPs so the sandbox preview keeps working", async () => {
    const r = await decideGate({
      userAgent: REAL_BROWSER_UA,
      ip: "127.0.0.1",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(true);
  });

  it("BLOCKS when IP intel cannot be resolved (fail closed for real IPs)", async () => {
    __setIntelFetchForTest(async () => new Response("err", { status: 500 }));
    const r = await decideGate({
      userAgent: REAL_BROWSER_UA,
      ip: "9.9.9.9",
      allowedCountry: "QA",
    });
    expect(r.allowed).toBe(false);
    expect(r.reason).toBe("no_ip_intel");
  });
});
