import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { insertChatMessage, getChatMessages, markMessagesAsRead } from "./db";

describe("Chat System", () => {
  const testRegistrationId = 999999;

  beforeAll(async () => {
    // Clean up any existing test messages
    const db = await (await import("./db")).getDb();
    if (db) {
      try {
        await db.delete((await import("../drizzle/schema")).chatMessages).where(
          (await import("drizzle-orm")).eq(
            (await import("../drizzle/schema")).chatMessages.registrationId,
            testRegistrationId
          )
        );
      } catch (e) {
        // Table might not exist yet
      }
    }
  });

  afterAll(async () => {
    // Clean up test data
    const db = await (await import("./db")).getDb();
    if (db) {
      try {
        await db.delete((await import("../drizzle/schema")).chatMessages).where(
          (await import("drizzle-orm")).eq(
            (await import("../drizzle/schema")).chatMessages.registrationId,
            testRegistrationId
          )
        );
      } catch (e) {
        // Ignore cleanup errors
      }
    }
  });

  it("should insert a visitor message", async () => {
    const result = await insertChatMessage({
      registrationId: testRegistrationId,
      sender: "visitor",
      message: "مرحبا، هل يمكنك مساعدتي؟",
    });
    expect(result).toBeDefined();
    expect(typeof result).toBe("number");
  });

  it("should insert an admin message", async () => {
    const result = await insertChatMessage({
      registrationId: testRegistrationId,
      sender: "admin",
      message: "مرحبا! كيف يمكنني مساعدتك؟",
    });
    expect(result).toBeDefined();
    expect(typeof result).toBe("number");
  });

  it("should retrieve all messages for a registration", async () => {
    // Insert two messages
    await insertChatMessage({
      registrationId: testRegistrationId,
      sender: "visitor",
      message: "رسالة 1",
    });
    await insertChatMessage({
      registrationId: testRegistrationId,
      sender: "admin",
      message: "رد 1",
    });

    const messages = await getChatMessages(testRegistrationId);
    expect(messages).toBeDefined();
    expect(Array.isArray(messages)).toBe(true);
    expect(messages.length).toBeGreaterThanOrEqual(2);
  });

  it("should mark messages as read", async () => {
    // Insert a message
    await insertChatMessage({
      registrationId: testRegistrationId,
      sender: "admin",
      message: "رسالة لم تُقرأ",
    });

    // Mark as read
    const success = await markMessagesAsRead(testRegistrationId, "admin");
    expect(success).toBe(true);

    // Verify messages are marked as read
    const messages = await getChatMessages(testRegistrationId);
    const adminMessages = messages.filter((m) => m.sender === "admin");
    expect(adminMessages.every((m) => m.isRead === true || m.isRead === 1)).toBe(true);
  });

  it("should handle empty registration ID gracefully", async () => {
    const messages = await getChatMessages(0);
    expect(Array.isArray(messages)).toBe(true);
  });
});
