import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  lookupGeo,
  lookupGeoBatch,
  isPrivateOrInvalidIp,
  countryCodeToFlag,
  __setFetchForTest,
  __clearGeoCacheForTest,
} from "./_core/geoip";

function mockJson(payload: unknown, ok = true): Response {
  return {
    ok,
    json: async () => payload,
  } as unknown as Response;
}

describe("geoip.isPrivateOrInvalidIp", () => {
  it("treats empty / null / whitespace as private", () => {
    expect(isPrivateOrInvalidIp(null)).toBe(true);
    expect(isPrivateOrInvalidIp(undefined)).toBe(true);
    expect(isPrivateOrInvalidIp("")).toBe(true);
    expect(isPrivateOrInvalidIp("   ")).toBe(true);
  });

  it("treats RFC1918 IPv4 ranges as private", () => {
    expect(isPrivateOrInvalidIp("10.0.0.1")).toBe(true);
    expect(isPrivateOrInvalidIp("172.16.5.4")).toBe(true);
    expect(isPrivateOrInvalidIp("172.31.255.1")).toBe(true);
    expect(isPrivateOrInvalidIp("192.168.1.1")).toBe(true);
    expect(isPrivateOrInvalidIp("127.0.0.1")).toBe(true);
    expect(isPrivateOrInvalidIp("169.254.1.1")).toBe(true);
  });

  it("treats public IPv4 as public", () => {
    expect(isPrivateOrInvalidIp("8.8.8.8")).toBe(false);
    expect(isPrivateOrInvalidIp("172.15.0.1")).toBe(false); // outside 16-31
    expect(isPrivateOrInvalidIp("172.32.0.1")).toBe(false);
  });

  it("treats IPv6 link-local and unique-local as private", () => {
    expect(isPrivateOrInvalidIp("::1")).toBe(true);
    expect(isPrivateOrInvalidIp("fe80::1")).toBe(true);
    expect(isPrivateOrInvalidIp("fd12:3456::1")).toBe(true);
  });

  it("strips ::ffff: prefix when checking IPv4-mapped IPv6", () => {
    expect(isPrivateOrInvalidIp("::ffff:127.0.0.1")).toBe(true);
    expect(isPrivateOrInvalidIp("::ffff:8.8.8.8")).toBe(false);
  });
});

describe("geoip.countryCodeToFlag", () => {
  it("returns flag emoji for valid alpha-2 codes", () => {
    expect(countryCodeToFlag("SA")).toBe("🇸🇦");
    expect(countryCodeToFlag("qa")).toBe("🇶🇦");
    expect(countryCodeToFlag("US")).toBe("🇺🇸");
  });

  it("returns empty string for invalid input", () => {
    expect(countryCodeToFlag(null)).toBe("");
    expect(countryCodeToFlag("")).toBe("");
    expect(countryCodeToFlag("X")).toBe("");
    expect(countryCodeToFlag("XYZ")).toBe("");
    expect(countryCodeToFlag("12")).toBe("");
  });
});

describe("geoip.lookupGeo", () => {
  beforeEach(() => {
    __clearGeoCacheForTest();
  });
  afterEach(() => {
    __setFetchForTest(null);
    __clearGeoCacheForTest();
  });

  it("returns null for private IPs without calling fetch", async () => {
    const fetchSpy = vi.fn();
    __setFetchForTest(fetchSpy as any);
    const result = await lookupGeo("192.168.1.1");
    expect(result).toBeNull();
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("returns null for null/empty IP", async () => {
    const fetchSpy = vi.fn();
    __setFetchForTest(fetchSpy as any);
    expect(await lookupGeo(null)).toBeNull();
    expect(await lookupGeo("")).toBeNull();
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("returns geo data on successful ip-api response", async () => {
    const fetchSpy = vi.fn().mockResolvedValueOnce(
      mockJson({
        status: "success",
        country: "Saudi Arabia",
        countryCode: "SA",
        city: "Riyadh",
      }),
    );
    __setFetchForTest(fetchSpy as any);
    const result = await lookupGeo("8.8.8.8");
    expect(result).toEqual({
      country: "Saudi Arabia",
      city: "Riyadh",
      countryCode: "SA",
    });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it("falls back to ipwho.is when ip-api fails", async () => {
    const fetchSpy = vi
      .fn()
      .mockResolvedValueOnce(mockJson({ status: "fail" }))
      .mockResolvedValueOnce(
        mockJson({
          success: true,
          country: "Qatar",
          country_code: "QA",
          city: "Doha",
        }),
      );
    __setFetchForTest(fetchSpy as any);
    const result = await lookupGeo("8.8.4.4");
    expect(result).toEqual({
      country: "Qatar",
      city: "Doha",
      countryCode: "QA",
    });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
  });

  it("returns null when both providers fail", async () => {
    const fetchSpy = vi
      .fn()
      .mockResolvedValueOnce(mockJson({ status: "fail" }))
      .mockResolvedValueOnce(mockJson({ success: false }));
    __setFetchForTest(fetchSpy as any);
    expect(await lookupGeo("1.2.3.4")).toBeNull();
  });

  it("caches successful lookups (second call does not fetch)", async () => {
    const fetchSpy = vi.fn().mockResolvedValueOnce(
      mockJson({
        status: "success",
        country: "United States",
        countryCode: "US",
        city: "Mountain View",
      }),
    );
    __setFetchForTest(fetchSpy as any);

    const r1 = await lookupGeo("8.8.8.8");
    const r2 = await lookupGeo("8.8.8.8");
    expect(r1).toEqual(r2);
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it("survives fetch throwing an error", async () => {
    const fetchSpy = vi.fn().mockRejectedValueOnce(new Error("network down"));
    __setFetchForTest(fetchSpy as any);
    const result = await lookupGeo("8.8.8.8");
    expect(result).toBeNull();
  });
});

describe("geoip.lookupGeoBatch", () => {
  beforeEach(() => {
    __clearGeoCacheForTest();
  });
  afterEach(() => {
    __setFetchForTest(null);
    __clearGeoCacheForTest();
  });

  it("looks up unique IPs once and skips private ones", async () => {
    const fetchSpy = vi.fn().mockResolvedValue(
      mockJson({
        status: "success",
        country: "Egypt",
        countryCode: "EG",
        city: "Cairo",
      }),
    );
    __setFetchForTest(fetchSpy as any);

    const result = await lookupGeoBatch([
      "8.8.8.8",
      "8.8.8.8", // dup
      "192.168.1.1", // private, skipped
      null,
      "",
    ]);
    expect(result.size).toBe(1);
    expect(result.get("8.8.8.8")?.country).toBe("Egypt");
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it("returns empty map when given only private/empty IPs", async () => {
    const fetchSpy = vi.fn();
    __setFetchForTest(fetchSpy as any);
    const result = await lookupGeoBatch(["192.168.1.1", "127.0.0.1", null]);
    expect(result.size).toBe(0);
    expect(fetchSpy).not.toHaveBeenCalled();
  });
});
