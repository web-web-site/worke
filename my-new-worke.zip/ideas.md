# النافذة الواحدة - Single Window

## Replication Task

This is a direct deployment of an existing static website (النافذة الواحدة - Single Window) - a Qatar government services portal. The site is being deployed as-is without any design modifications.

## Reference

The ground-truth spec is the uploaded zip file containing the complete static website with:
- Arabic RTL layout
- Bootstrap 5.2.3 RTL
- Swiper carousel
- Custom CSS with government branding (blue/gold color scheme)
- Multiple HTML pages for registration, login, payment flows
- jQuery-based interactions

## Approach

Deploy the static files exactly as provided, maintaining all existing styling, functionality, and structure.
