
document.addEventListener('DOMContentLoaded', function() {
  // تبديل التابات
  document.querySelectorAll('[data-bs-toggle="tab"]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var target = this.getAttribute('data-bs-target');
      document.querySelectorAll('.tab-pane').forEach(function(p){ p.classList.remove('show','active'); });
      document.querySelectorAll('[data-bs-toggle="tab"]').forEach(function(b){ b.classList.remove('active'); });
      this.classList.add('active');
      var pane = document.querySelector(target);
      if(pane){ pane.classList.add('show','active'); }
    });
  });

  // Swiper
  if(typeof Swiper !== 'undefined'){
    new Swiper('.swiper-container', {
      loop: true,
      autoplay: { delay: 4500, disableOnInteraction: false },
      pagination: { el: '.swiper-pagination', clickable: true },
      navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
      dir: 'rtl'
    });
  }

  // القائمة الجانبية
  function openSidebar(){ document.querySelector('.aside-bar').classList.add('open-side-bar'); document.querySelector('.overlay-bg').style.display='block'; }
  function closeSidebar(){ document.querySelector('.aside-bar').classList.remove('open-side-bar'); document.querySelector('.overlay-bg').style.display='none'; }
  document.querySelectorAll('.navbar-toggler-sidebar').forEach(function(btn){ btn.addEventListener('click', openSidebar); });
  document.querySelector('.overlay-bg').addEventListener('click', closeSidebar);
  document.querySelector('.close-side-bar').addEventListener('click', function(e){ e.preventDefault(); closeSidebar(); });
});
