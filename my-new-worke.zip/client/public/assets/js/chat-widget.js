/*
 * ويدجت الدعم الفني (Chat Widget) - نسخة متكاملة مع API
 * يتصل بـ /api/trpc/chat.* لإرسال واستقبال الرسائل الحقيقية من/إلى الداشبورد
 */
(function () {
  "use strict";

  if (window.__sw_chat_widget_loaded) return;
  window.__sw_chat_widget_loaded = true;

  var AGENT_NAME = "الدعم الفني";
  var LOGO_SRC = "images/single-window.svg";
  var POLL_INTERVAL_ACTIVE = 3000; // ms - when chat panel is open
  var POLL_INTERVAL_IDLE = 15000; // ms - when chat panel is closed
  var pollTimer = null;
  var currentPollInterval = POLL_INTERVAL_IDLE;
  var lastMessageCount = 0;

  // ─── tRPC helpers ───────────────────────────────────────────────────────────

  function getFingerprint() {
    var fp = localStorage.getItem('visitor_fingerprint');
    if (!fp) {
      var match = document.cookie.match(new RegExp('(^| )visitor_fingerprint=([^;]+)'));
      if (match) fp = match[2];
    }
    return fp || window.visitorFingerprint;
  }

  function trpcGet(procedure, inputObj) {
    var input = encodeURIComponent(
      JSON.stringify({ json: inputObj === undefined ? null : inputObj, meta: inputObj === undefined ? { values: ["undefined"] } : undefined })
    );
    var headers = { "content-type": "application/json" };
    var fp = getFingerprint();
    if (fp) {
      headers["x-visitor-fingerprint"] = fp;
    }
    return fetch("/api/trpc/" + procedure + "?input=" + input, {
      credentials: "include",
      headers: headers,
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        try { return data.result.data.json; } catch (e) { return null; }
      })
      .catch(function () { return null; });
  }

  function trpcPost(procedure, inputObj) {
    var headers = { "content-type": "application/json" };
    var fp = getFingerprint();
    if (fp) {
      headers["x-visitor-fingerprint"] = fp;
    }
    return fetch("/api/trpc/" + procedure, {
      method: "POST",
      credentials: "include",
      headers: headers,
      body: JSON.stringify({ json: inputObj }),
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        try { return data.result ? data.result.data.json : null; } catch (e) { return null; }
      })
      .catch(function () { return null; });
  }

  // ─── Styles ─────────────────────────────────────────────────────────────────

  function injectStyles() {
    var css = ""
      + "#sw-chat-root{position:fixed;bottom:24px;right:24px;z-index:2147483000;font-family:'Noto Kufi Arabic',sans-serif;direction:rtl;}"
      + "#sw-chat-root *{box-sizing:border-box;}"
      + ".sw-chat-toggle{display:flex;align-items:center;gap:8px;background:#0a2540;color:#fff;border:none;border-radius:50px;padding:12px 20px;cursor:pointer;box-shadow:0 6px 20px rgba(10,37,64,.35);font-size:15px;font-weight:600;font-family:inherit;transition:transform .16s cubic-bezier(.23,1,.32,1),box-shadow .2s;}"
      + ".sw-chat-toggle:hover{box-shadow:0 8px 26px rgba(10,37,64,.45);}"
      + ".sw-chat-toggle:active{transform:scale(.97);}"
      + ".sw-chat-toggle svg{width:22px;height:22px;flex-shrink:0;}"
      + ".sw-unread-badge{position:absolute;top:-6px;right:-6px;background:#ef4444;color:#fff;border-radius:50%;width:20px;height:20px;font-size:11px;display:flex;align-items:center;justify-content:center;font-weight:700;}"
      + ".sw-toggle-wrap{position:relative;display:inline-flex;}"
      + ".sw-chat-panel{position:absolute;bottom:70px;right:0;width:350px;max-width:calc(100vw - 48px);background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.18);overflow:hidden;display:flex;flex-direction:column;opacity:0;transform:scale(.95) translateY(10px);transform-origin:bottom right;pointer-events:none;transition:opacity .2s cubic-bezier(.23,1,.32,1),transform .2s cubic-bezier(.23,1,.32,1);}"
      + ".sw-chat-panel.open{opacity:1;transform:scale(1) translateY(0);pointer-events:auto;}"
      + ".sw-chat-header{background:#0a2540;color:#fff;padding:16px;display:flex;align-items:center;gap:12px;}"
      + ".sw-chat-avatar{width:42px;height:42px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;padding:4px;}"
      + ".sw-chat-avatar img{width:100%;height:100%;object-fit:contain;}"
      + ".sw-chat-hinfo{flex:1;min-width:0;}"
      + ".sw-chat-hname{font-size:15px;font-weight:700;}"
      + ".sw-chat-status{display:inline-flex;align-items:center;gap:5px;font-size:11px;opacity:.9;margin-top:2px;}"
      + ".sw-chat-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;display:inline-block;}"
      + ".sw-chat-close{background:none;border:none;color:#fff;cursor:pointer;opacity:.8;padding:4px;display:flex;}"
      + ".sw-chat-close:hover{opacity:1;}"
      + ".sw-chat-body{padding:16px;height:300px;overflow-y:auto;background:#f7f9fc;display:flex;flex-direction:column;gap:10px;}"
      + ".sw-msg{max-width:80%;padding:10px 14px;border-radius:14px;font-size:14px;line-height:1.5;white-space:pre-line;}"
      + ".sw-msg.agent{background:#fff;color:#1f2937;align-self:flex-start;border:1px solid #eef2f7;border-bottom-right-radius:4px;}"
      + ".sw-msg.user{background:#0a2540;color:#fff;align-self:flex-end;border-bottom-left-radius:4px;}"
      + ".sw-chat-quick{display:flex;flex-wrap:wrap;gap:8px;padding:0 16px 12px;background:#f7f9fc;}"
      + ".sw-quick-btn{background:#fff;border:1px solid #0a2540;color:#0a2540;border-radius:20px;padding:6px 14px;font-size:13px;cursor:pointer;font-family:inherit;transition:background .15s,color .15s;}"
      + ".sw-quick-btn:hover{background:#0a2540;color:#fff;}"
      + ".sw-chat-input{display:flex;align-items:center;gap:8px;padding:12px;border-top:1px solid #eef2f7;background:#fff;}"
      + ".sw-chat-input input{flex:1;border:1px solid #e2e8f0;border-radius:24px;padding:10px 16px;font-size:14px;font-family:inherit;outline:none;direction:rtl;}"
      + ".sw-chat-input input:focus{border-color:#0a2540;}"
      + ".sw-chat-send{background:#0a2540;color:#fff;border:none;border-radius:50%;width:40px;height:40px;display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;transition:transform .16s;}"
      + ".sw-chat-send:disabled{opacity:.5;cursor:not-allowed;}"
      + ".sw-chat-send:active:not(:disabled){transform:scale(.92);}"
      + ".sw-chat-footer{text-align:center;font-size:11px;color:#94a3b8;padding:0 0 10px;background:#fff;}"
      + "@media (max-width:480px){.sw-chat-panel{width:calc(100vw - 48px);} }";
    var style = document.createElement("style");
    style.id = "sw-chat-styles";
    style.textContent = css;
    document.head.appendChild(style);
  }

  // ─── Widget ──────────────────────────────────────────────────────────────────

  function buildWidget(agentName) {
    var root = document.createElement("div");
    root.id = "sw-chat-root";

    var sendIcon = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>';
    var chatIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>';
    var closeIcon = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';

    root.innerHTML =
      '<div class="sw-chat-panel" id="sw-chat-panel">'
      + '<div class="sw-chat-header">'
      + '<div class="sw-chat-avatar"><img src="' + LOGO_SRC + '" alt="logo" onerror="this.src=\'https://ui-avatars.com/api/?name=Support&background=0D8ABC&color=fff\'"/></div>'
      + '<div class="sw-chat-hinfo"><div class="sw-chat-hname">' + agentName + '</div>'
      + '<div class="sw-chat-status"><span class="sw-chat-dot"></span> متصل الآن</div></div>'
      + '<button class="sw-chat-close" id="sw-chat-close" aria-label="إغلاق">' + closeIcon + '</button>'
      + '</div>'
      + '<div class="sw-chat-body" id="sw-chat-body"></div>'
      + '<div class="sw-chat-quick" id="sw-chat-quick">'
      + '<button class="sw-quick-btn">الاستفسار عن خدمة</button>'
      + '<button class="sw-quick-btn">مشكلة في الدفع</button>'
      + '<button class="sw-quick-btn">التحدث مع موظف</button>'
      + '</div>'
      + '<div class="sw-chat-input">'
      + '<input type="text" id="sw-chat-text" placeholder="اكتب رسالتك هنا..." />'
      + '<button class="sw-chat-send" id="sw-chat-send" aria-label="إرسال">' + sendIcon + '</button>'
      + '</div>'
      + '<div class="sw-chat-footer">عادةً ما نرد خلال دقائق قليلة</div>'
      + '</div>'
      + '<div class="sw-toggle-wrap">'
      + '<button class="sw-chat-toggle" id="sw-chat-toggle">' + chatIcon + '<span>تحدث معنا</span></button>'
      + '</div>';

    document.body.appendChild(root);

    var panel = document.getElementById("sw-chat-panel");
    var toggle = document.getElementById("sw-chat-toggle");
    var closeBtn = document.getElementById("sw-chat-close");
    var body = document.getElementById("sw-chat-body");
    var input = document.getElementById("sw-chat-text");
    var sendBtn = document.getElementById("sw-chat-send");
    var quick = document.getElementById("sw-chat-quick");
    var isOpen = false;

    // ─── Render messages ───────────────────────────────────────────────────────

    function renderMessages(messages) {
      if (!messages || messages.length === 0) {
        body.innerHTML = '<div class="sw-msg agent">مرحباً بك! 👋\nكيف يمكنني مساعدتك اليوم؟</div>';
        return;
      }
      body.innerHTML = "";
      messages.forEach(function (msg) {
        var div = document.createElement("div");
        div.className = "sw-msg " + (msg.sender === "admin" ? "agent" : "user");
        div.textContent = msg.message;
        body.appendChild(div);
      });
      body.scrollTop = body.scrollHeight;
    }

    // ─── Unread badge ──────────────────────────────────────────────────────────

    function showBadge(count) {
      var existing = root.querySelector(".sw-unread-badge");
      if (count > 0) {
        if (!existing) {
          var badge = document.createElement("div");
          badge.className = "sw-unread-badge";
          badge.textContent = count > 9 ? "9+" : count;
          root.querySelector(".sw-toggle-wrap").appendChild(badge);
        } else {
          existing.textContent = count > 9 ? "9+" : count;
        }
      } else {
        if (existing) existing.remove();
      }
    }

    // ─── Poll messages ─────────────────────────────────────────────────────────

    function fetchAndRender() {
      trpcGet("chat.getMessages").then(function (messages) {
        if (!messages) return;
        renderMessages(messages);
        var unread = messages.filter(function (m) { return m.sender === "admin" && !m.isRead; });
        if (unread.length > 0) {
          showBadge(unread.length);
          if (!isOpen) {
            openPanel();
          }
        } else {
          showBadge(0);
        }
      });
    }

    function startPolling(interval) {
      var newInterval = interval || currentPollInterval;
      if (pollTimer && newInterval === currentPollInterval) return;
      if (pollTimer) clearInterval(pollTimer);
      currentPollInterval = newInterval;
      fetchAndRender();
      pollTimer = setInterval(fetchAndRender, currentPollInterval);
    }

    // ─── Panel open/close ──────────────────────────────────────────────────────

    function openPanel() {
      isOpen = true;
      panel.classList.add("open");
      showBadge(0);
      
      startPolling(POLL_INTERVAL_ACTIVE);
      
      setTimeout(function () { input.focus(); }, 220);
    }

    function closePanel() {
      isOpen = false;
      panel.classList.remove("open");
      startPolling(POLL_INTERVAL_IDLE);
    }

    // ─── Send message ──────────────────────────────────────────────────────────

    function sendMessage() {
      var val = input.value.trim();
      if (!val) return;
      input.value = "";
      sendBtn.disabled = true;

      trpcPost("chat.sendMessage", { message: val }).then(function (result) {
        sendBtn.disabled = false;
        fetchAndRender();
      }).catch(function () {
        sendBtn.disabled = false;
      });
    }

    // ─── Events ────────────────────────────────────────────────────────────────

    toggle.addEventListener("click", function () {
      if (isOpen) closePanel(); else openPanel();
    });
    closeBtn.addEventListener("click", closePanel);
    sendBtn.addEventListener("click", sendMessage);
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") sendMessage();
    });
    quick.addEventListener("click", function (e) {
      if (e.target && e.target.classList.contains("sw-quick-btn")) {
        input.value = e.target.textContent.trim();
        sendMessage();
      }
    });

    // Start polling with idle interval (15s) - speeds up to 3s when panel is opened
    startPolling(POLL_INTERVAL_IDLE);
  }

  // ─── Init ────────────────────────────────────────────────────────────────────

  function init() {
    trpcGet("chat.getSettings").then(function (settings) {
      if (!settings || settings.enabled !== true) return;
      var agentName = settings.agentName || AGENT_NAME;
      injectStyles();
      buildWidget(agentName);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
