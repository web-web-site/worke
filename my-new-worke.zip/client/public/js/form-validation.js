/******************************************************************************
 * (c) Copyright Gemalto, 2017                                                *
 * ALL RIGHTS RESERVED UNDER COPYRIGHT LAWS.                                  *
 * CONTAINS CONFIDENTIAL AND TRADE SECRET INFORMATION.                        *
 *                                                                            *
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF    *
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED         *
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A                *
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE              *
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,          *
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.                *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE     *
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE            *
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT      *
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE      *
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE          *
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE          *
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO         *
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR      *
 * HIGH RISK ACTIVITIES.                                                      *
 ******************************************************************************/
$(function () {

	/**
	 *
	 * Attribute definitions
	 *
	 */

	var attributePolicies = [];

	attributePolicies.push({name: "PhonePrefix", mandatory: true, validationExpression: new RegExp("^.*"), typingExpression: new RegExp("^.*$")});
	attributePolicies.push({name: "SmsOTP", mandatory: true, validationExpression: new RegExp("^([0-9]{4})$"), typingExpression: new RegExp("^([0-9]{0,4})$")});
	attributePolicies.push({name: "UserPassword", mandatory: true, validationExpression: new RegExp(".*"), typingExpression: new RegExp(".*")});

	var serverAttributePoliciesJson = NAS.getMetaContent("attribute-policies");

	if(serverAttributePoliciesJson !== undefined && serverAttributePoliciesJson !== "") {
		var serverAttributePolicies = JSON.parse(serverAttributePoliciesJson);

		var serverAttributePoliciesLength = serverAttributePolicies.length;
		for (var i = 0; i < serverAttributePoliciesLength; i++) {
			var serverAttributePolicy = serverAttributePolicies[i];
			attributePolicies.push(
				{
				name: serverAttributePolicy.attributeName,
				mandatory: serverAttributePolicy.mandatory,
				validationExpression: new RegExp(serverAttributePolicy.validationExpression === null ? "^.*$" : serverAttributePolicy.validationExpression),
				typingExpression: new RegExp(serverAttributePolicy.typingExpression === null ? ".*" : serverAttributePolicy.typingExpression)}
				);
		}
	}

	var validateAttribute = "data-validate";
	var validateSelector = "[data-validate]";
	var validateSelectorTemplate = "[data-validate='{usr_attr}']";
	var validateReenterAttribute = "data-validate-reenter";
	var parentGroupAttribute = "data-validate-parent-group";
	var userTypeAttribute = "data-user-type";
	var validateFullNameAttribute = "data-validate-full-name";
	var validateFullNameHighlightSelector = "[data-validate-full-name='highlight']";
	var validateFullNameHighlightHelpBlockSelector = "[data-validate-full-name='highlight-help-block']";
	var validateQidAddressAttribute = "data-validate-qid-address";
	var validateQidAddressHighlightSelector = "[data-validate-qid-address='highlight']";

	var submitButtonSelector = ".btn";
	var errorMessageSelector = "[data-error-message]";
	var serverErrorMessageSelector = "[data-error-message='server']";
	var mandatoryErrorMessageSelector = "[data-error-message='mandatory']";
	var expressionErrorMessageSelector = "[data-error-message='expression']";
	var reenterErrorMessageSelector = "[data-error-message='reenter']";
	var standaloneErrorMessageSelectorTemplate = "[data-error-message-for-input='{usr_attr}']";


	function getAttributePolicyForElement(element) {
		var policyName = element.getAttribute(validateAttribute);
		for(i = 0; i < attributePolicies.length; i++) {
			if(attributePolicies[i].name == policyName) {
				return attributePolicies[i];
			}
		}
		return null;
	}

	function validate(value, attributePolicy, eventType) {
		if(!attributePolicy) {
			return true;
		}
		var regExp;
		if(eventType == 'keypress' || eventType == 'paste') {
			regExp = attributePolicy.typingExpression;
		} else {
			regExp = attributePolicy.validationExpression;
		}
		return regExp.test(value);
	}

	function validateFullName(form) {
		var selector;
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserFirstNameAR");
		var userFirstNameAR = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserLastNameAR");
		var userLastNameAR = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserFirstNameEN");
		var userFirstNameEN = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserLastNameEN");
		var userLastNameEN = $(form).find(selector);
		if(userFirstNameAR.val() && userLastNameAR.val()) {
			return true;
		}
		if(userFirstNameEN.val() && userLastNameEN.val()) {
			return true;
		}
		return false;
	}

	function validateQidAddress(form) {
		var selector;
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserAddressBuildingNumber");
		var userAddressBuildingNumber = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserAddressStreetName");
		var userAddressStreetName = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserAddressZone");
		var userAddressZone = $(form).find(selector);

		if(userAddressBuildingNumber.val() && userAddressStreetName.val() && userAddressZone.val()) {
			return true;
		}
		return false;
	}

	function isPrintableCharCode(charCode) {
		if(charCode > 31) return true; // 0-31 => control characters ; everything else is printable
		if(charCode == 9 || charCode == 11) return true; // horizontal and vertical tab
		return false;
	}

	function getParentGroup(element) {
		var parent = $(element).parent();
		while(parent.parent()) {
			if(element.hasAttribute(parentGroupAttribute)) {
				if(parent.attr('id')==element.getAttribute(parentGroupAttribute)) {
					return parent;
				}
			} else {
				if(parent.hasClass("form-group")) {
					return parent;
				}
			}
			parent = parent.parent();
		}
		return null;
	}

	function showError(element, errorMessageSelector) {
		var parentFormGroup = getParentGroup(element);
		if(parentFormGroup) {
			parentFormGroup.addClass("has-error");
			parentFormGroup.find(errorMessageSelector).removeClass("hide");
		}
	}

	function showFullNameError(form) {
		$(validateFullNameHighlightSelector).addClass("has-error");
		$(validateFullNameHighlightHelpBlockSelector).addClass("help-block");
	}

	function showQidAddressError(form) {
		$(validateQidAddressHighlightSelector).addClass("has-error");

		var selector;
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserAddressBuildingNumber");
		var userAddressBuildingNumber = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserAddressStreetName");
		var userAddressStreetName = $(form).find(selector);
		selector = validateSelectorTemplate.replace("{usr_attr}", "UserAddressZone");
		var userAddressZone = $(form).find(selector);

		if(!userAddressBuildingNumber.val()) {
			selector = standaloneErrorMessageSelectorTemplate.replace("{usr_attr}", "UserAddressBuildingNumber");
			$(selector).removeClass("hide");
		}
		if(!userAddressStreetName.val()) {
			selector = standaloneErrorMessageSelectorTemplate.replace("{usr_attr}", "UserAddressStreetName");
			$(selector).removeClass("hide");
		}
		if(!userAddressZone.val()) {
			selector = standaloneErrorMessageSelectorTemplate.replace("{usr_attr}", "UserAddressZone");
			$(selector).removeClass("hide");
		}

	}


	function hideErrors(element) {

		var parentFormGroup = getParentGroup(element);
		if(parentFormGroup) {
			parentFormGroup.removeClass("has-error");
			parentFormGroup.find(errorMessageSelector).addClass("hide");
		}

	}

	function hideFullNameError(form) {
		$(validateFullNameHighlightSelector).removeClass("has-error");
	}

	function hideQidAddressError(form) {
		$(validateQidAddressHighlightSelector).removeClass("has-error");
		var selector;
		selector = standaloneErrorMessageSelectorTemplate.replace("{usr_attr}", "UserAddressBuildingNumber");
		$(form).find(selector).addClass("hide");
		selector = standaloneErrorMessageSelectorTemplate.replace("{usr_attr}", "UserAddressStreetName");
		$(form).find(selector).addClass("hide");
		selector = standaloneErrorMessageSelectorTemplate.replace("{usr_attr}", "UserAddressZone");
		$(form).find(selector).addClass("hide");
	}

	/**
	 *
	 * Attach listeners to required input elements
	 *
	 */

	/**
	 * typing control (forbidden characters)
	 */
	$(validateSelector).on('keypress', function(event) {
		var attributePolicy = getAttributePolicyForElement(event.target);
		var charCode = event.which;
		// ctrl+v is not checked (will be checked on paste event)
		if (event.ctrlKey && (charCode == 86 || charCode==118) ) {
			return true;
		}
		// non-printable characters are not checked
		if(!isPrintableCharCode(charCode)) {
			return true;
		}
		var element = event.target;
		var newValue = element.value + String.fromCharCode(charCode);
		return validate(newValue, attributePolicy, event.type);
	});

	/**
	 * paste control (forbidden characters)
	 */
	$(validateSelector).on('paste', function(event) {
		var attributePolicy = getAttributePolicyForElement(event.target);
		var element = event.target;
		var pastedData = event.originalEvent.clipboardData.getData('Text');
		var newValue = element.value + pastedData;
		return validate(newValue, attributePolicy, event.type);
	});

	/**
	 * change control (validate expression)
	 */
	$(validateSelector).on('change', function(event) {
		var attributePolicy = getAttributePolicyForElement(event.target);
		var element = event.target;

		// exception: date of birth triggeres on page load; and this hide would hide server errors
		if(attributePolicy === null || attributePolicy.name != "UserBirthdate") {
			hideErrors(element);
		}

		// mandatory validation
		if(!element.value) {
			if(attributePolicy !== null && attributePolicy.mandatory) {
				// exception: date of birth triggeres on page load
				if(attributePolicy.name != "UserBirthdate") {
					showError(element, mandatoryErrorMessageSelector);
				}
			}
		} else {

			// reenter validation
			if(element.hasAttribute(validateReenterAttribute)) {
				var originalElementId = $(element).attr(validateReenterAttribute);
				if(element.value != $('#'+originalElementId).val()) {
					showError(element, reenterErrorMessageSelector);
				}
			}

			// expression validation
			if(!validate(element.value, attributePolicy, event.type)) {
				showError(element, expressionErrorMessageSelector);
			}

			// at least one full name filled in validation
			var parentForm = $(element).closest("form");
			if(parentForm.get(0).hasAttribute(validateFullNameAttribute) && parentForm.get(0).getAttribute(validateFullNameAttribute)=="true") {
				if(validateFullName(parentForm)) {
					hideFullNameError(parentForm);
				}
			}

			// qid address check
			var parentForm = $(element).closest("form");
			if(parentForm.get(0).hasAttribute(validateQidAddressAttribute) && parentForm.get(0).getAttribute(validateQidAddressAttribute)=="true") {
				if(validateQidAddress(parentForm)) {
					hideQidAddressError(parentForm);
				}
			}
		}
	});


	/**
	 *
	 * Form submit control
	 *
	 */
	$("form").on('submit', function(event) {
		var allOk = true;
		for(i = 0; i < attributePolicies.length; i++) {
			var attributePolicy = attributePolicies[i];
			var selector = validateSelectorTemplate.replace("{usr_attr}", attributePolicy.name);
			$(event.target).find(selector).each(function() {
				var element = this;

				hideErrors(element);

				// mandatory validation
				var emptyValue = false;
				if(attributePolicy.name == "UserGender") {
					var name = element.getAttribute("name");
					if ($("input[name=\""+name+"\"]:checked").length == 0){
						emptyValue=true;
					}
				} else {
					emptyValue = !element.value;
				}

				if(emptyValue) {
					if(attributePolicy.mandatory) {
						showError(element, mandatoryErrorMessageSelector);
						allOk = false;
					}
				} else {

					// reenter validation
					if(element.hasAttribute(validateReenterAttribute)) {
						var originalElementId = $(element).attr(validateReenterAttribute);
						if(element.value != $('#'+originalElementId).val()) {
							showError(element, reenterErrorMessageSelector);
							allOk = false;
						}
					}

					// expression validation
					if(!validate(element.value, attributePolicy, event.type)) {
						showError(element, expressionErrorMessageSelector);
						allOk = false;
					}
				}
			});
		}

		// at least one full name filled in validation
		if(this.hasAttribute(validateFullNameAttribute) && this.getAttribute(validateFullNameAttribute)=="true") {
			hideFullNameError(this);
			if(!validateFullName(this)) {
				showFullNameError(this);
				allOk = false;
			}
		}

		// qid address check
		if(this.hasAttribute(validateQidAddressAttribute) && this.getAttribute(validateQidAddressAttribute)=="true") {
			hideQidAddressError(this);
			if(!validateQidAddress(this)) {
				showQidAddressError(this);
				allOk = false;
			}
		}

		// if submisson failed then unblock form for another submission
		if(!allOk) {
			$(submitButtonSelector).prop("disabled", false);
			$(event.target).data('submitted', false);
		}

		$(event.target).trigger('form_validation', allOk);
		return allOk;
	});

	/**
	 *
	 * Re-enter fields control
	 *
	 */
	$('['+validateReenterAttribute+']').on('paste', function(event) {
		return false;
	});

});

