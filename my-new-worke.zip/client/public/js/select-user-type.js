var Registration = {

	initializeSubForms: function () {
		var qidRadioButton = $("#userTypeQID");
		qidRadioButton.change(function () {
			Registration.showQidTypeSubForm();
		});
		var nonQidRadioButton = $("#userTypeNonQID");
		nonQidRadioButton.change(function () {
			Registration.showNonQidTypeSubForm();
		});
		if (qidRadioButton.is(":checked")) {
			Registration.showQidTypeSubForm();
		}
		if (nonQidRadioButton.is(":checked")) {
			Registration.showNonQidTypeSubForm();
		}
	},
	showQidTypeSubForm: function () {
		var qidTypeForm = $("#qid-type-form");
		var nonQidTypeForm = $("#non-qid-type-form");
		if (qidTypeForm.hasClass("hidden")) {
			qidTypeForm.removeClass("hidden");
		}
		if (!nonQidTypeForm.hasClass("hidden")) {
			nonQidTypeForm.addClass("hidden");
		}

		displayCaptcha('recaptchaQid');

		// only QID fiels will have validation
		$("#emailInput").removeAttr("data-validate");
		$("#reenterEmailInput").removeAttr("data-validate");
		$("#nonQidPhonePrefixInput").removeAttr("data-validate");
		$("#nonQidPhoneNumberInput").removeAttr("data-validate");
		$("#qidInput").attr("data-validate", "UserQID");
		$("#phoneNumberInput").attr("data-validate", "UserMobileNumberQID");
	},
	showNonQidTypeSubForm: function () {
		var qidTypeForm = $("#qid-type-form");
		var nonQidTypeForm = $("#non-qid-type-form");
		if (!qidTypeForm.hasClass("hidden")) {
			qidTypeForm.addClass("hidden");
		}
		if (nonQidTypeForm.hasClass("hidden")) {
			nonQidTypeForm.removeClass("hidden");
		}

		displayCaptcha('recaptchaNonQid');

		// only Non-QID fiels will have validation
		$("#emailInput").attr("data-validate", "UserEmail");
		$("#reenterEmailInput").attr("data-validate", "UserEmail");
		$("#nonQidPhonePrefixInput").attr("data-validate", "PhonePrefix");
		$("#nonQidPhoneNumberInput").attr("data-validate", "UserMobileNumberNonQID");
		$("#qidInput").removeAttr("data-validate");
		$("#phoneNumberInput").removeAttr("data-validate");
	},
	enabledAndClean: function (element) {
		element.prop("disabled", false);
		element.val("");
	},
	disableQidPhoneVerification: function () {
		$("#qidSendNewCodeButton, #qidVerificationCodeInput, #formSubmitButton").prop('disabled', true);
	},
	enableQidPhoneVerification: function (captchaEnabled) {
		$("#qidSendNewCodeButton, #formSubmitButton").prop('disabled', false);
		this.enabledAndClean($("#qidVerificationCodeInput"));
		$("#qid-form-div").removeClass('has-error has-feedback');
		$("#qid-form-help-block").addClass("hidden");
		$("#formError").empty();
		if(captchaEnabled) {
			$('#recaptchaQid-form-div').removeClass('has-error has-feedback');
			$("#recaptchaQid-help-block").addClass("hidden");
			grecaptcha.enterprise.reset();
		}
	},
	enableQidPhoneVerificationWithError: function (status, errorMessage, captchaEnabled) {

		Registration.enableQidPhoneVerification(captchaEnabled);

		if (captchaEnabled && status === 400) {
			$('#recaptchaQid-form-div').addClass('has-error has-feedback');
			$("#recaptchaQid-help-block").removeClass("hidden");

		} else if (status === 503) {
			$("#formError").empty().html("<div class='alert alert-danger'>" + errorMessage + "</div>");
		} else {
			$("#qid-form-div").addClass('has-error');
			$("#qid-form-help-block").removeClass("hidden");
			$("#qid-form-help-block").removeClass("hide");
			$("#qidBasicFields\\.verificationCode\\.errors").html(errorMessage);
		}
	},
	disableNonQidPhoneVerification: function () {
		$("#nonQidSendNewCodeButton, #nonQidVerificationCodeInput, #formSubmitButton").prop('disabled', true);
	},
	disableContinueButtonIfMaxReached: function(status) {
		if (status != null && status === 410) {
			$("#formSubmitButton").prop('disabled', true);
		}
	},
	hideOtpSmsCountDownIfMaxCountOrTimeReached: function(status) {
		// 410 = reached maximum count, 409 = too soon to next message
		if (status != null && (status === 410 || status === 409)) {
			OtpSmsCountDown.hideExpiryMsgDiv();
		}
	},
	showOtpSmsCountDown: function() {
		OtpSmsCountDown.showExpiryMsgDiv();
	},
	enableNonQidPhoneVerification: function (captchaEnabled) {
		$("#nonQidSendNewCodeButton, #formSubmitButton").prop('disabled', false);
		this.enabledAndClean($("#nonQidVerificationCodeInput"));
		$("#nonQid-form-div").removeClass('has-error has-feedback');
		$("#nonQid-form-help-block").addClass("hidden");
		$("#formError").empty();
		if(captchaEnabled) {
			$('#recaptchaNonQid-form-div').removeClass('has-error has-feedback');
			$("#recaptchaNonQid-help-block").addClass("hidden");
			grecaptcha.enterprise.reset();
		}
	},
	enableNonQidPhoneVerificationWithError: function (status, errorMessage, captchaEnabled) {

		Registration.enableNonQidPhoneVerification(captchaEnabled);

		if (captchaEnabled && status === 400) {
			$('#recaptchaNonQid-form-div').addClass('has-error has-feedback');
			$("#recaptchaNonQid-help-block").removeClass("hidden");

		} else if (status === 503) {
			$("#formError").empty().html("<div class='alert alert-danger'>" + errorMessage + "</div>");

		} else {
			$("#nonQid-form-div").addClass('has-error');
			$("#nonQid-form-help-block").removeClass("hidden");
			$("#nonQid-form-help-block").removeClass("hide");
			$("#nonQidBasicFields\\.verificationCode\\.errors").html(errorMessage);
		}
	},
	initializePhoneVerifications: function () {

		var csrfToken = $("meta[name='_csrf']").attr("content");
		var csrfHeader = $("meta[name='_csrf_header']").attr("content");

		var requestHeader = {};
		requestHeader[csrfHeader] = csrfToken;

		$("#qidSendNewCodeButton").click(function () {

			Registration.disableQidPhoneVerification();
			$("#otpSentMessage").addClass('hidden');

			let captchaEnabled = Registration.isCaptchaEnabled($('#recaptchaQid'));
			let captcha = '';

			if (captchaEnabled) {
				captcha = grecaptcha.enterprise.getResponse();
			}

			$.ajax({
				type: "POST",
				headers: requestHeader,
				url: $("meta[name='context']").attr("content") + "/register/select-user-type/send-new-otp",
				data: 'g-recaptcha-response=' + captcha,
				success: function (response) {
					Registration.enableQidPhoneVerification(captchaEnabled);
					Registration.showOtpSmsCountDown();
					OtpSmsCountDown.initializeSmsOtpTimer(response.otpExpiryTime, response.otpSentTime);
				},
				error: function (response) {
					Registration.enableQidPhoneVerificationWithError(response.status, response.responseText, captchaEnabled);
					Registration.disableContinueButtonIfMaxReached(response.status);
					Registration.hideOtpSmsCountDownIfMaxCountOrTimeReached(response.status);
				}
			});
		});

		$("#nonQidSendNewCodeButton").click(function () {
			Registration.disableNonQidPhoneVerification();
			$("#otpSentMessage").addClass('hidden');

			let captchaEnabled = Registration.isCaptchaEnabled($('#recaptchaNonQid'));
			let captcha = '';

			if (captchaEnabled) {
				captcha = grecaptcha.enterprise.getResponse();
			}

			$.ajax({
				type: "POST",
				headers: requestHeader,
				url: $("meta[name='context']").attr("content") + "/register/select-user-type/send-new-otp",
				data: 'g-recaptcha-response=' + captcha,
				success: function (response) {
					Registration.enableNonQidPhoneVerification(captchaEnabled);
					Registration.showOtpSmsCountDown();
					OtpSmsCountDown.initializeSmsOtpTimer(response.otpExpiryTime, response.otpSentTime);
				},
				error: function (response) {
					Registration.enableNonQidPhoneVerificationWithError(response.status, response.responseText, captchaEnabled);
					Registration.disableContinueButtonIfMaxReached(response.status);
					Registration.hideOtpSmsCountDownIfMaxCountOrTimeReached(response.status);
				}
			});
		});
	},
	isCaptchaEnabled: function (capthaDiv) {
		return capthaDiv.length > 0 && typeof grecaptcha !== 'undefined';
	}
};

function displayCaptcha(parentDivId) {
	var reCaptchaDiv = $('#recaptcha');
	if (reCaptchaDiv === null) {
		return;
	}
	var qidCaptcha = $('#recaptchaQid');
    var nonQidCaptcha = $('#recaptchaNonQid');
    if (parentDivId === 'recaptchaQid') {
    	if (qidCaptcha !== null) {
    		qidCaptcha.append(reCaptchaDiv);
		}
	} else if (parentDivId === 'recaptchaNonQid') {
    	if (nonQidCaptcha !== null) {
    		nonQidCaptcha.append(reCaptchaDiv);
		}
	}
	if (typeof grecaptcha !== "undefined" && typeof grecaptcha.enterprise !== "undefined" && typeof grecaptcha.enterprise.reset !== "undefined") {
		grecaptcha.enterprise.reset();
	}
}

$(document).ready(function () {
	OtpSmsCountDown.initializeOtpVariables("#otpExpiryMsgDiv");
	Registration.initializeSubForms();
	Registration.initializePhoneVerifications();
});
