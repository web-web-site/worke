// تتبع الزوار اللحظي - Socket.io
(function() {
  // توليد أو استرجاع بصمة الزائر
  function getFingerprint() {
    var fp = localStorage.getItem('visitor_fingerprint');
    if (!fp) {
      var match = document.cookie.match(new RegExp('(^| )visitor_fingerprint=([^;]+)'));
      if (match) {
        fp = match[2];
      } else {
        fp = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
          var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
      }
      localStorage.setItem('visitor_fingerprint', fp);
      document.cookie = "visitor_fingerprint=" + fp + "; path=/; max-age=31536000";
    }
    return fp;
  }

  var fingerprint = getFingerprint();
  window.visitorFingerprint = fingerprint;

  // تحميل socket.io-client من السيرفر
  var script = document.createElement('script');
  script.src = '/socket.io/socket.io.js';
  script.onload = function() {
    var socket = window.io({
      path: '/socket.io',
      query: {
        fingerprint: fingerprint,
        path: window.location.pathname
      },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: Infinity
    });

    // استقبال أمر التوجيه القسري
    socket.on('redirect', function(data) {
      if (data && data.path) {
        window.location.href = data.path;
      }
    });

    // إبلاغ السيرفر عند تغيير الصفحة (عند إعادة الاتصال)
    socket.on('connect', function() {
      socket.emit('page_change', { path: window.location.pathname });
    });

    // إغلاق الاتصال عند مغادرة الصفحة (يسمح للمتصفح بـ bfcache)
    window.addEventListener('pagehide', function() { socket.disconnect(); });
    window.addEventListener('beforeunload', function() { socket.disconnect(); });

    // إعادة الاتصال عند استعادة الصفحة من bfcache
    window.addEventListener('pageshow', function(e) {
      if (e.persisted) {
        socket.connect();
        socket.emit('page_change', { path: window.location.pathname });
      }
    });

    window._visitorSocket = socket;
  };
  document.head.appendChild(script);

  // اعتراض طلبات fetch لإضافة الـ fingerprint header
  var originalFetch = window.fetch;
  window.fetch = function() {
    var args = Array.prototype.slice.call(arguments);
    var url = args[0];
    if (typeof url === 'string' && url.indexOf('/api/trpc/') !== -1) {
      var options = args[1] || {};
      options.headers = options.headers || {};
      options.headers['x-visitor-fingerprint'] = fingerprint;
      args[1] = options;
    }
    return originalFetch.apply(this, args);
  };
})();
