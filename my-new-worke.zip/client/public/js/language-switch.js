$(document).ready(function() {
    // Inject Language Toggle Button into pages if not present, or bind to existing English links
    var currentLang = localStorage.getItem('site_lang') || 'ar';
    
    // Function to load translations and apply them to the page
    function applyLanguage(lang) {
        // Update local storage
        localStorage.setItem('site_lang', lang);
        
        // Load the translation JSON file
        $.getJSON('js/ar_to_en.json', function(translations) {
            if (lang === 'en') {
                // Change page direction and lang attribute
                $('html').attr('lang', 'en').attr('dir', 'ltr');
                $('body').attr('dir', 'ltr').css('font-family', "'Montserrat', sans-serif");
                
                // Swap bootstrap stylesheet if NAS pages are active
                var bootstrapLink = $('link[href*="bootstrap-nas-gray.min.rtl.css"]');
                if (bootstrapLink.length) {
                    bootstrapLink.attr('href', 'css/bootstrap-3.4.1.ltr.min.css');
                }
                
                // Swap main bootstrap for index.html if active
                var mainBootstrap = $('link[href*="bootstrap.rtl.min.css"]');
                if (mainBootstrap.length) {
                    mainBootstrap.attr('href', 'css/bootstrap-5.2.3.ltr.min.css');
                }

                // Add English font local link to head if not present
                if (!$('#eng-font-link').length) {
                    $('head').append('<link id="eng-font-link" href="css/montserrat.css" rel="stylesheet">');
                }

                // Adjust some specific layout components for LTR
                $('.pull-left').removeClass('pull-left').addClass('pull-right-en');
                $('.navbar-toggle').css('float', 'right');
                $('.fixed-text').css('float', 'left').css('margin-left', '15px');
                $('.fixed-logo').css('float', 'right').css('margin-right', '15px');
                
                // Walk through all text nodes and translate them
                translateElements(translations, 'en');
                
                // Update language button text and icon
                updateLangButtons('en');
            } else {
                // Restore Arabic
                $('html').attr('lang', 'ar').attr('dir', 'rtl');
                $('body').attr('dir', 'rtl').css('font-family', "'Noto Kufi Arabic', sans-serif");
                
                // Restore RTL Bootstrap
                var bootstrapLink = $('link[href*="bootstrap.min.css"]');
                if (bootstrapLink.length && bootstrapLink.attr('href').indexOf('bootstrap@3.4.1') !== -1) {
                    bootstrapLink.attr('href', 'css/bootstrap-nas-gray.min.rtl.css');
                }
                
                var mainBootstrap = $('link[href*="bootstrap.min.css"]');
                if (mainBootstrap.length && mainBootstrap.attr('href').indexOf('bootstrap@5.2.3') !== -1) {
                    mainBootstrap.attr('href', 'css/bootstrap-5.2.3.rtl.min.css');
                }

                // Restore floats
                $('.pull-right-en').removeClass('pull-right-en').addClass('pull-left');
                $('.navbar-toggle').css('float', 'left');
                $('.fixed-text').css('float', 'right').css('margin-right', '15px');
                $('.fixed-logo').css('float', 'left').css('margin-left', '15px');

                // Reload page to restore original Arabic text cleanly without complicated reverse mapping
                // but only if we are switching back to Arabic from English to ensure clean state
                if (window.lastLang === 'en') {
                    localStorage.setItem('site_lang', 'ar');
                    window.location.reload();
                }
            }
            window.lastLang = lang;
        });
    }

    // Function to translate all texts and placeholders on the page
    function translateElements(translations, targetLang) {
        // Translate standard elements
        $('*').each(function() {
            var element = $(this);
            
            // Avoid scripts, styles, and elements that shouldn't be translated
            if (element.is('script, style, iframe, link, meta, noscript, img')) return;

            // Translate placeholder attributes
            var placeholder = element.attr('placeholder');
            if (placeholder && translations[placeholder]) {
                element.attr('placeholder', translations[placeholder]);
            }

            // Translate title attributes
            var title = element.attr('title');
            if (title && translations[title]) {
                element.attr('title', translations[title]);
            }

            // Translate direct text nodes
            var nodes = element.contents();
            nodes.each(function() {
                if (this.nodeType === 3) { // Text node
                    var text = this.nodeValue.trim();
                    if (text && translations[text]) {
                        this.nodeValue = this.nodeValue.replace(text, translations[text]);
                    }
                }
            });
        });
    }

    // Function to update language buttons text
    function updateLangButtons(lang) {
        // Find English toggle links
        $('a:contains("English"), a:contains("العربية"), a[href*="lang="]').each(function() {
            var btn = $(this);
            if (lang === 'en') {
                btn.html('العربية');
                // If it contains an image (like index.html)
                var siblingDiv = btn.find('div');
                if (siblingDiv.length) {
                    siblingDiv.text('العربية');
                }
                var siblingImg = btn.find('img');
                if (siblingImg.length) {
                    siblingImg.attr('alt', 'العربية');
                }
            } else {
                btn.html('English');
                var siblingDiv = btn.find('div');
                if (siblingDiv.length) {
                    siblingDiv.text('English');
                }
            }
        });
    }

    // Intercept clicks on language switch buttons
    $(document).on('click', 'a:contains("English"), a:contains("العربية"), a[href*="lang="], .actions-header-list-item-link:has(img[alt="English"])', function(e) {
        e.preventDefault();
        var targetLang = (localStorage.getItem('site_lang') || 'ar') === 'ar' ? 'en' : 'ar';
        applyLanguage(targetLang);
    });

    // Apply the language on page load
    applyLanguage(currentLang);
});
