
// jQuery plugin to prevent double submission of forms
jQuery.fn.preventDoubleSubmission = function() {
	$(this).on('submit',function(e){
		var $form = $(this);

		if ($form.data('submitted') === true) {
			// Previously submitted - don't submit again
			e.preventDefault();
		} else {
			// Mark it so that the next submit can be ignored
			$form.data('submitted', true);
			$('.btn').attr("disabled", "disabled");
		}
	});

	// Keep chainability
	return this;
};

/**
 * Created by rjun on 2017-05-22.
 */
var NAS = {
	Event: {
		LOGGER: "nas-logger-event"
	},
	Configuration: {
		consoleLog: true
	},

	/**
	 * Reads the meta tag with the provided name and returns its content.
	 *
	 * @param name meta tag name
	 * @returns tag value
	 */
	getMetaContent: function (name) {
		return $('meta[name=' + name + ']').attr("content");
	},

	/**
	 * Detects mobile browser or device using the TouchEvent creation - https://stackoverflow.com/questions/6262584/how-to-determine-if-the-client-is-a-touch-device/15481500#15481500.
	 * @return true if mobile device detected; false otherwise
	 */
	isMobileDevice: function () {
		try {
			document.createEvent("TouchEvent");
			return true;
		} catch (e) {
			return false;
		}
	},

	/**
	 * Creates new virtual keyboard instance within the document read jQuery callback.
	 *
	 * @param keyboardElement jQuery-style element name for which to render keyboard
	 * @param buttonElement jQuery-style element name which is showing/hiding keyboard
	 * @param scrambleNumbers random number position; true/false; enabled by default
	 */
	createVirtualKeyboard: function (keyboardElement, buttonElement, scrambleNumbers) {
		var that = this;
		$(document).ready(function () {
			if (!that.isMobileDevice()) {
				var keyboard = $(keyboardElement).keyboard({
					layout: 'custom',
					customLayout: {
						'normal': [
							'{c} ` 1 2 3 4 5 6 7 8 9 0 - = {bksp}',
							'q w e r t y u i o p [ ] \\',
							'a s d f g h j k l ; \'',
							'{shift} z x c v b n m , . / {shift}',
							'{space}'
						],
						'shift': [
							'{c} ~ ! @ # $ % ^ & * ( ) _ + {bksp}',
							'Q W E R T Y U I O P { } |',
							'A S D F G H J K L : "',
							'{shift} Z X C V B N M < > ? {shift}',
							'{space}'
						]
					},
					autoAccept: true,
					autoAcceptOnEsc: true,
					openOn: '',
					closeByClickEvent: false,
					css: {
						input: 'form-control input',
						container: 'center-block dropdown-menu', // jumbotron
						buttonDefault: 'btn btn-default',
						buttonHover: 'active',
						buttonAction: 'btn btn-primary',
						buttonDisabled: 'disabled'
					},
					display: {
						c: 'Esc:Close (Esc)'
					},
					usePreview: false
				});

				if (scrambleNumbers === undefined || scrambleNumbers === true) {
					keyboard.addScramble({targetKeys: /[0-9]/i, randomizeOnce: false});
				}

				$(buttonElement).click(function (event) {
					$(keyboardElement).getkeyboard().reveal();
				});
			} else {
				$(buttonElement).prop('disabled', true);
			}
		});
	}
};