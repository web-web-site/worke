let OtpSmsCountDown = {
	
	smsOtpExpiryInterval: 0,
	expiryMsgDiv: 0,
	otpExpiryMessage: '',
	otpExpiredMessage: '',
	otpSentTime: '',
	otpExpiryDate: 0,
	otpSentTimeFormat: '',

	initializeOtpVariables: function (selector) {
		OtpSmsCountDown.expiryMsgDiv = $(selector);
		if(OtpSmsCountDown.expiryMsgDiv.length > 0) {
			OtpSmsCountDown.otpExpiryMessage = OtpSmsCountDown.expiryMsgDiv.data("expiry-message");
			OtpSmsCountDown.otpExpiredMessage = OtpSmsCountDown.expiryMsgDiv.data("expired-message");
			OtpSmsCountDown.expiryDate = OtpSmsCountDown.expiryMsgDiv.data("otp-expiry");
			OtpSmsCountDown.otpSentTime = OtpSmsCountDown.expiryMsgDiv.data("otp-sent-time");
			OtpSmsCountDown.otpSentTimeFormat = OtpSmsCountDown.expiryMsgDiv.data("time-format");
			OtpSmsCountDown.initializeSmsOtpTimer(OtpSmsCountDown.expiryDate, OtpSmsCountDown.otpSentTime);

			$("form").on('form_validation', function( event, validationResult ) {
				if(validationResult) {
					OtpSmsCountDown.stopTimer();
				}
			});
		}

	},

	initializeSmsOtpTimer: function (otpExpiryTime, otpSentTime) {
		OtpSmsCountDown.stopTimer();
		OtpSmsCountDown.otpSentTime = moment(otpSentTime).format(OtpSmsCountDown.otpSentTimeFormat);
		OtpSmsCountDown.otpExpiryDate = otpExpiryTime;
		OtpSmsCountDown.startTimer();
		OtpSmsCountDown.smsOtpExpiryTimer();
	},
	startTimer: function() {
		OtpSmsCountDown.smsOtpExpiryInterval = setInterval(OtpSmsCountDown.smsOtpExpiryTimer, 1000);
	},
	smsOtpExpiryTimer: function() {

		const totalSeconds = Math.ceil((OtpSmsCountDown.otpExpiryDate - Date.now()) / 1000);

		if (totalSeconds > 0) {
			const minutes = Math.floor(totalSeconds / 60)
			const seconds = totalSeconds % 60;
			const expiryText = minutes.toString().padStart(2, '0') + ":" + seconds.toString().padStart(2, '0');

			OtpSmsCountDown.expiryMsgDiv.text(Mustache.render(OtpSmsCountDown.otpExpiryMessage, {
				time: OtpSmsCountDown.otpSentTime,
				otpExpiry: expiryText
			}));

		} else {
			clearInterval(OtpSmsCountDown.smsOtpExpiryInterval);
			OtpSmsCountDown.expiryMsgDiv.text(Mustache.render(OtpSmsCountDown.otpExpiredMessage, {
				time: OtpSmsCountDown.otpSentTime
			}));
		}

		OtpSmsCountDown.expiryMsgDiv.removeClass('hidden');
	},

	stopTimer : function() {
		if(OtpSmsCountDown.smsOtpExpiryInterval !== 0) {
			clearInterval(OtpSmsCountDown.smsOtpExpiryInterval);
		}
	},

	hideExpiryMsgDiv : function () {
		if(OtpSmsCountDown.expiryMsgDiv.length > 0) {
			OtpSmsCountDown.expiryMsgDiv.hide();
		}
	},

	showExpiryMsgDiv : function () {
		if(OtpSmsCountDown.expiryMsgDiv.length > 0) {
			OtpSmsCountDown.expiryMsgDiv.show();
		}
	}
}